import discord
import logging

from logging.handlers import RotatingFileHandler


# setting up loggers
d_logger = logging.getLogger('deleted_messages_logger')
d_logger.setLevel(logging.INFO)

e_logger = logging.getLogger('edited_messages_logger')
e_logger.setLevel(logging.INFO)

app_com_logger = logging.getLogger('application_commands_logger')
app_com_logger.setLevel(logging.INFO)

txt_com_logger = logging.getLogger('text_commands_logger')
txt_com_logger.setLevel(logging.INFO)



# setting up file handlers

d_message_file_handler = RotatingFileHandler(
    'src/logs/deleted_messages_log.txt', 
    maxBytes=5*1024*1024,  # 5 MB limit
    backupCount=5  # Keep 5 backups
)
d_message_file_handler.setFormatter(logging.Formatter('%(asctime)s - %(message)s', datefmt='%Y-%m-%d %H:%M:%S'))
d_logger.addHandler(d_message_file_handler)


e_message_file_handler = RotatingFileHandler(
    'src/logs/edited_messages_log.txt', 
    maxBytes=5*1024*1024,  
    backupCount=5  
)
e_message_file_handler.setFormatter(logging.Formatter('%(asctime)s - %(message)s', datefmt='%Y-%m-%d %H:%M:%S'))
e_logger.addHandler(e_message_file_handler)


command_file_handler = RotatingFileHandler(
    'src/logs/command_usage_log.txt', 
    maxBytes=20*1024*1024,  # 20 MB limit
    backupCount=5 
)
command_file_handler.setFormatter(logging.Formatter('%(asctime)s - %(message)s', datefmt='%Y-%m-%d %H:%M:%S'))
app_com_logger.addHandler(command_file_handler)
txt_com_logger.addHandler(command_file_handler)



# setting up console handlers

d_message_console_handler = logging.StreamHandler()
d_message_console_handler.setFormatter(logging.Formatter(
    '\x1b[30;1m%(asctime)s\x1b[0m \x1b[31mDELETED MESSAGE\x1b[0m %(message)s', datefmt='%Y-%m-%d %H:%M:%S'))
d_logger.addHandler(d_message_console_handler)

e_message_console_handler = logging.StreamHandler()
e_message_console_handler.setFormatter(logging.Formatter(
    '\x1b[30;1m%(asctime)s\x1b[0m \x1b[33mEDITED MESSAGE\x1b[0m %(message)s', datefmt='%Y-%m-%d %H:%M:%S'))
e_logger.addHandler(e_message_console_handler)

command_console_handler = logging.StreamHandler()
command_console_handler.setFormatter(logging.Formatter(
    '\x1b[30;1m%(asctime)s\x1b[0m \x1b[32mCOMMAND USAGE\x1b[0m %(message)s', datefmt='%Y-%m-%d %H:%M:%S'))
app_com_logger.addHandler(command_console_handler)
txt_com_logger.addHandler(command_console_handler)




##########################################################################################
#                               LOGGING COMMANDS START HERE                              #
##########################################################################################


async def log_deleted_message(message):
    log_message = f'[{message.guild.name}] [# {message.channel.name}] {message.author.display_name} ({message.author}): {message.content}'
    d_logger.info(log_message)


async def log_edited_message(message_before, message_after):
    log_message = f'[{message_before.guild.name}] [# {message_before.channel.name}] {message_before.author.display_name} ({message_before.author}): {message_before.content} --> {message_after.content}'
    e_logger.info(log_message)


async def log_app_command_usage(interaction, command):
    command_arguments = interaction.data.get("options", [])
    arguments_str = ', '.join(f"{arg['name']}={arg['value']}" for arg in command_arguments)

    if interaction.channel.type == discord.ChannelType.private:
        log_message = f'{interaction.user.display_name} ({interaction.user}) used command in DMs: "/{command.name}" with arguments "{arguments_str}"'   
    else:
        log_message = f'[{interaction.guild.name}] [# {interaction.channel.name}] {interaction.user.display_name} ({interaction.user}) used command: "/{command.name}" with arguments "{arguments_str}"'

    app_com_logger.info(log_message)


async def log_text_command(message, command_name):
    if message.channel.type == discord.ChannelType.private:
        log_message = f'{message.author.display_name} ({message.author}) used command in DMs: "/{command_name}" with message "{message.content}"'
    else:
        log_message = f'[{message.guild.name}] [# {message.channel.name}] {message.author.display_name} ({message.author}) used text command "{command_name}" with message "{message.content}"'
    app_com_logger.info(log_message)