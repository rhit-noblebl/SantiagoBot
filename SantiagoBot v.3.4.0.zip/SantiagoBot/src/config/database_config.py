import sqlite3
import json

from src.config.main_config import bot

DATABASE_PATH = "src/db_files/santiago_database.db"
JSON_FILE_PATH = 'src/data/user_data.json'
conn = sqlite3.connect(DATABASE_PATH)
cursor = conn.cursor()


# Connect to the database
conn = sqlite3.connect(DATABASE_PATH)
cursor = conn.cursor()

# Create the guilds table
cursor.execute('''
CREATE TABLE IF NOT EXISTS guilds (
    guild_id INTEGER PRIMARY KEY,
    guild_name TEXT
)
''')

# Update the VoiceClients table to reference the guilds table
cursor.execute('''
CREATE TABLE IF NOT EXISTS voice_clients (
    guild_id INTEGER PRIMARY KEY,
    voice_client_info TEXT,
    FOREIGN KEY (guild_id) REFERENCES guilds (guild_id)
)
''')

# Update the ai_message_history table to reference the guilds table
cursor.execute('''
CREATE TABLE IF NOT EXISTS ai_message_history (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    guild_id INTEGER,
    role TEXT,
    content TEXT,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (guild_id) REFERENCES guilds (guild_id)
)
''')

cursor.execute('''
CREATE TABLE IF NOT EXISTS guild_settings (
    guild_id INTEGER PRIMARY KEY,
    volume_multiplier REAL DEFAULT 1.0,
    chat_replies_enabled BOOLEAN DEFAULT 1,
    loop_queue_enabled BOOLEAN DEFAULT 0,
    gpt_model TEXT DEFAULT 'gpt-4o-mini',
    FOREIGN KEY (guild_id) REFERENCES guilds (guild_id)
)
''')

cursor.execute('''
CREATE TABLE IF NOT EXISTS video_queue (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    guild_id INTEGER,
    video_url TEXT,
    title TEXT,
    uploader TEXT,
    position INTEGER,
    FOREIGN KEY (guild_id) REFERENCES guilds (guild_id)
)
''')

cursor.execute('''
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY,
    user_name TEXT,
    currency INTEGER DEFAULT 0
)
''')

cursor.execute('''
CREATE TABLE IF NOT EXISTS user_stats (
    user_id INTEGER PRIMARY KEY,
    slash_commands_used INTEGER DEFAULT 0,
    amount_worked INTEGER DEFAULT 0,
    amount_gambled INTEGER DEFAULT 0,
    amount_shot INTEGER DEFAULT 0,
    amount_exploded INTEGER DEFAULT 0,
    FOREIGN KEY (user_id) REFERENCES users (id)
)
''')

cursor.execute('''
CREATE TABLE IF NOT EXISTS inventory (
    user_id INTEGER,
    item_name TEXT,
    quantity INTEGER,
    PRIMARY KEY (user_id, item_name),
    FOREIGN KEY (user_id) REFERENCES users (id)
)
''')

# Create a junction table to link users and guilds
cursor.execute('''
CREATE TABLE IF NOT EXISTS user_guilds (
    user_id INTEGER,
    guild_id INTEGER,
    PRIMARY KEY (user_id, guild_id),
    FOREIGN KEY (user_id) REFERENCES users (user_id),
    FOREIGN KEY (guild_id) REFERENCES guilds (guild_id)
)
''')


conn.commit()
conn.close()




##########################################################################################
#                                 Population Methods                                     #
##########################################################################################

async def populate_db(bot):
    await populate_guilds(bot)
    await populate_users(bot)
    await populate_user_guilds()
    await populate_user_stats()

async def populate_user_guilds():
    conn = sqlite3.connect(DATABASE_PATH)
    cursor = conn.cursor()

    # Iterate over each guild the bot is in
    for guild in bot.guilds:
        guild_id = guild.id
        for member in guild.members:
            if not member.bot:  # Ignore bots
                user_id = member.id

                # Insert the user-guild association into the table
                cursor.execute('''
                    INSERT OR IGNORE INTO user_guilds (user_id, guild_id)
                    VALUES (?, ?)
                ''', (user_id, guild_id))
    
    conn.commit()
    conn.close()

async def populate_guilds(bot):
    try:
        conn = sqlite3.connect(DATABASE_PATH)
        cursor = conn.cursor()

        guilds = bot.guilds

        for guild in guilds:
            cursor.execute('''
            INSERT OR REPLACE INTO guilds (guild_id, guild_name)
            VALUES (?, ?)
            ''', (guild.id, guild.name))

        conn.commit()
    except sqlite3.Error as e:
        print(f"An error occurred: {e}")
    finally:
        conn.close()

async def populate_users(bot):
    conn = sqlite3.connect(DATABASE_PATH)
    cursor = conn.cursor()

    # Iterate over each guild the bot is in
    for guild in bot.guilds:
        for member in guild.members:
            if not member.bot:  # Ignore bots
                user_id = member.id
                user_name = str(member)  # Username#Discriminator

                # Insert the user into the users table
                cursor.execute('''
                    INSERT OR IGNORE INTO users (id, user_name, currency)
                    VALUES (?, ?, ?)
                ''', (user_id, user_name, 0))
    conn.commit()
    conn.close()

async def populate_user_stats():
    conn = sqlite3.connect(DATABASE_PATH)
    cursor = conn.cursor()

    try:
        # Fetch all user IDs from the users table
        cursor.execute('SELECT id FROM users')
        user_ids = cursor.fetchall()
        
        # Insert default stats for each user
        for (user_id,) in user_ids:
            cursor.execute('''
                INSERT OR IGNORE INTO user_stats (user_id, slash_commands_used, amount_worked, amount_gambled, amount_shot, amount_exploded)
                VALUES (?, 0, 0, 0, 0, 0)
            ''', (user_id,))
        
        conn.commit()
    except sqlite3.Error as e:
        print(f"An error occurred: {e}")
    finally:
        conn.close()
    

##########################################################################################
#                     Exporting and importing user data from JSON                        #
##########################################################################################

def export_user_data_to_json(json_file_path=JSON_FILE_PATH, db_path=DATABASE_PATH):
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()

    cursor.execute('''
        SELECT users.id, users.user_name, users.currency, inventory.item_name, inventory.quantity
        FROM users
        LEFT JOIN inventory ON users.id = inventory.user_id
    ''')

    # Organize the data into the desired structure
    user_data = {}
    for row in cursor.fetchall():
        user_id = str(row[0])
        user_name = row[1]
        currency = row[2]
        item_name = row[3]
        quantity = row[4]

        if user_id not in user_data:
            user_data[user_id] = {
                "user_name": user_name,
                "currency": currency,
                "inventory": {}
            }

        if item_name:
            user_data[user_id]["inventory"][item_name] = {
                "quantity": quantity
            }

    with open(json_file_path, 'w') as file:
        json.dump(user_data, file, indent=4)

    conn.close()


def import_user_data_from_json(json_file_path=JSON_FILE_PATH, db_path=DATABASE_PATH):

    with open(json_file_path, 'r') as file:
        user_data = json.load(file)

    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()

    # Insert user data into the database
    for user_id, details in user_data.items():
        cursor.execute('''
            INSERT OR REPLACE INTO users (id, user_name, currency)
            VALUES (?, ?, ?)
        ''', (int(user_id), details['user_name'], details['currency']))

        # Insert inventory data for each user
        for item_name, item_details in details['inventory'].items():
            cursor.execute('''
                INSERT OR REPLACE INTO inventory (user_id, item_name, quantity)
                VALUES (?, ?, ?)
            ''', (int(user_id), item_name, item_details['quantity']))

    conn.commit()
    conn.close()


# dumps user data into json
export_user_data_to_json()


# stores json data into database
# import_user_data_from_json()