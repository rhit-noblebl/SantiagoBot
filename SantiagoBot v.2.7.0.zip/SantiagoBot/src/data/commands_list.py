NON_SLASH_COMMANDS = [
    "santiago",
    "asciify",
    "pdf",
    "yttranscribe",
]

TEXT_COMMANDS = [
    "ping",
    "mock",
    "kill",
    "suicide",
    "ant_colony",
    "dbd-randomizer",
    "asciify (for text)",
    "rng",
    "wikipedia",
    "bible",
    "define",
]

AUDIO_COMMANDS = [
    "pause_or_resume",
    "stop_sound",
    "oblivion_moment",
    "ltg_speech",
    "clown",
    "gigachad",
]

YOUTUBE_COMMANDS = [
    "youtube-play",
    "clear_queue",
    "view_queue",
    "toggle_loop",
    "remove_from_queue",
    "skip_to",
]

AI_COMMANDS = [
    "talk",
    "speak",
    "gpt_model",
    "record_and_respond",
    "fast_record_and_respond",
    "transcribe"
]

CONFIG_COMMANDS = [
    "join_call",
    "leave_call",
    "set_volume",
    "toggle_chat_replies"
]
