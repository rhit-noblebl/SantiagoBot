import discord
import asyncio
import random
import wikipediaapi
import urllib.request
import json
import re
import io
import aiohttp
import img2pdf

from random import randint
from art import *
from ascii_magic import AsciiArt
from io import BytesIO

from src.config import bot
from src.data.commands_list import *
from src.data.reactions_lists import INSULT_TEMPLATES, KILL_EXCLAMATION_TEMPLATES, KILL_MESSAGES, SUICIDE_MESSAGES
from src.data.gif_and_image_lists import KILL_GIFS, KILL_THUMBNAILS, SUICIDE_GIFS
from src.data.dbd_lists import *

async def create_help_embed(interaction: discord.Interaction):
    help_embed = discord.Embed(colour=discord.Colour.brand_green())
    help_embed.set_author(name="you need help eh...? here's all the goods i got")
    help_embed.title = "Santiago Command List"

    all_text_commands = ""
    for text_command in TEXT_COMMANDS:
        all_text_commands += f"```{text_command}```"
    help_embed.add_field(name="Text Commands  💬", value=all_text_commands)
    
    all_audio_commands = ""
    for audio_command in AUDIO_COMMANDS:
        all_audio_commands += f"```{audio_command}```"
    help_embed.add_field(name="Audio Commands  📣", value=all_audio_commands)
    
    all_youtube_commands = ""
    for youtube_command in YOUTUBE_COMMANDS:
        all_youtube_commands += f"```{youtube_command}```"
    help_embed.add_field(name="YouTube Commands  ▶️", value=all_youtube_commands)

    all_ai_commands = ""
    for ai_command in AI_COMMANDS:
        all_ai_commands += f"```{ai_command}```"
    help_embed.add_field(name="AI Commands  🤖", value=all_ai_commands)

    all_non_slash_commands = ""
    for non_slash_command in NON_SLASH_COMMANDS:
        all_non_slash_commands += f"```{non_slash_command}```"
    help_embed.add_field(name="Non-Slash  ⌨️\n(Type ONLY these words in chat for more help)", value=all_non_slash_commands)

    all_config_commands = ""
    for general_command in CONFIG_COMMANDS:
        all_config_commands += f"```{general_command}```"
    help_embed.add_field(name="Configuration  ⚙️", value=all_config_commands)

    await interaction.response.send_message(embed=help_embed, ephemeral=True)


async def ping_spam(interaction: discord.Interaction, person_to_ping: discord.Member):
    if(person_to_ping == bot.user):
        await interaction.response.send_message(content='no', ephemeral=True)
    else:
        await interaction.response.send_message(content='lol ok', ephemeral=True)
        for _ in range(8):
          await interaction.channel.send(f"{person_to_ping.mention}")
          await asyncio.sleep(0.5)


async def mock_user(interaction: discord.Interaction, person_to_mock: discord.Member):
    insults = [template.format(insulter=interaction.user.mention, insultee=person_to_mock.mention) for template in INSULT_TEMPLATES]
    if person_to_mock == interaction.user:
      await interaction.response.send_message("What, you got a humiliation fetish or something?", ephemeral=True)
    elif person_to_mock == bot.user:
      await interaction.response.send_message("What the fuck did you just fucking say about me, you little shit? Ill have you know I graduated top of my class in the Navy Seals, and Ive been involved in numerous secret raids on Al-Quaeda, and I have over 300 confirmed kills. I am trained in gorilla warfare and Im the top sniper in the entire US armed forces. You are nothing to me but just another target. I will wipe you the fuck out with precision the likes of which has never been seen before on this Earth, mark my fucking words. You think you can get away with saying that shit to me over the Internet? Think again, fucker. As we speak I am contacting my secret network of spies across the USA and your IP is being traced right now so you better prepare for the storm, maggot. The storm that wipes out the pathetic little thing you call your life. Youre fucking dead, kid. I can be anywhere, anytime, and I can kill you in over seven hundred ways, and thats just with my bare hands. Not only am I extensively trained in unarmed combat, but I have access to the entire arsenal of the United States Marine Corps and I will use it to its full extent to wipe your miserable ass off the face of the continent, you little shit. If only you could have known what unholy retribution your little clever comment was about to bring down upon you, maybe you would have held your fucking tongue. But you couldnt, you didnt, and now youre paying the price, you goddamn idiot. I will shit fury all over you and you will drown in it. Youre fucking dead, kiddo. ", ephemeral=True)
    else:
      await interaction.response.send_message(random.choice(insults))


async def create_suicide_embed(suicide_user: discord.Member):
    suicide_embed = discord.Embed()
    suicide_embed.set_image(url=random.choice(SUICIDE_GIFS))
    suicide_embed.set_footer(text=random.choice(SUICIDE_MESSAGES))
    suicide_embed.set_author(name=f"{suicide_user} killed themself!")
    return suicide_embed


async def kill_user(interaction, person_to_kill):
    kill_embed = discord.Embed()
  
    if person_to_kill == interaction.user:
        await suicide(interaction)

    elif person_to_kill == bot.user:
        await interaction.response.send_message("https://media.tenor.com/C8MpzwDxl40AAAAM/ltg-low-tier-god.gif", ephemeral=True)
        await interaction.channel.send(f"A message for {interaction.user.mention}! :)")
        await asyncio.sleep(2)
        await interaction.channel.send("https://tenor.com/view/kys-keep-yourself-safe-low-tier-god-gif-24664025")
      
    else:
        kill_embed.set_image(url=random.choice(KILL_GIFS))
        kill_embed.set_footer(text=random.choice(KILL_MESSAGES))
        kill_exclamations = [template.format(killer=interaction.user.display_name, killed=person_to_kill.display_name) for template in KILL_EXCLAMATION_TEMPLATES]
        kill_embed.set_author(name=random.choice(kill_exclamations))
        kill_embed.set_thumbnail(url=random.choice(KILL_THUMBNAILS))
        await interaction.channel.send(f"{person_to_kill.mention}, you have been killed!")
        await interaction.response.send_message(embed=kill_embed)


async def suicide(interaction: discord.Interaction):
    suicide_embed = await create_suicide_embed(interaction.user.display_name)
    await interaction.response.send_message(embed=suicide_embed)


async def ant_colony_spam(interaction: discord.Interaction):
    await interaction.response.send_message("ant colony", ephemeral=True)
    for _ in range(5):
      await interaction.channel.send("ant colony")
      await asyncio.sleep(.50)
    await interaction.channel.send("https://media1.tenor.com/m/a3TKcL6T7isAAAAC/indiana-jones.gif")
    await asyncio.sleep(1)
    for _ in range(5):
      await interaction.channel.send("ant colony")
      await asyncio.sleep(.50)


ascii_style = "4x4_offr"
async def asciify(interaction: discord.Interaction, text_prompt: str, style: str):
    text_prompt = text_prompt.replace(' ', '\n')
    art = text2art(text_prompt, font=str(style))
    if len(art) > 2000:
        await interaction.response.send_message("slow down there buckaroo, that generation ends up too long. try changing the font or shorten your message")
    else:
        await interaction.response.send_message("```" + art + "```")


async def dbd_randomizer(interaction: discord.Interaction, role: str):
    dbd_embed = discord.Embed()
    random_number_1 = randint(1, 20)
    random_number_2 = randint(1, 20)
    while random_number_2 == random_number_1:
        random_number_2 = randint(1,20)

    if role == "s":
        dbd_embed.set_image(url=random.choice(SURVIVOR_ICON_LIST))
        dbd_embed.set_thumbnail(url="https://i.redd.it/h5qh26afvepc1.png")
        dbd_embed.set_author(name = "Your survivor and their perks:")

        perks = random.sample(SURVIVOR_PERK_LIST, 4)
        for i, perk in enumerate(perks, 1):
            dbd_embed.add_field(name=f"Perk {i}: ", value=perk, inline=False)

        base_item = random.choice(SURVIVOR_ITEM_LIST)        

        if base_item == "Medkit":
            item = random.choice(MEDKIT_RARITIES)
        elif base_item == "Toolbox":
            item = random.choice(TOOLBOX_RARITIES)
        elif base_item == "Flashlight":
            item = random.choice(FLASHLIGHT_RARITIES)
        elif base_item == "Map":
            item = random.choice(MAP_RARITIES)
        elif base_item == "Key":
            item = random.choice(KEY_RARITIES)
        else:
            item = base_item

        dbd_embed.add_field(name=f"Item: ", value=item, inline=True)

        addons = []

        if base_item == "Medkit":
            addons = random.sample(MEDKIT_ADDONS, 2)
            for i, addon in enumerate(addons, 1):
                dbd_embed.add_field(name=f"Addon {i}: ", value=addon, inline=True)
        elif base_item == "Toolbox":
            addons = random.sample(TOOLBOX_ADDONS, 2)
            for i, addon in enumerate(addons, 1):
                dbd_embed.add_field(name=f"Addon {i}: ", value=addon, inline=True)
        elif base_item == "Flashlight":
            addons = random.sample(FLASHLIGHT_ADDONS, 2)
            for i, addon in enumerate(addons, 1):
                dbd_embed.add_field(name=f"Addon {i}: ", value=addon, inline=True)
        elif base_item == "Map":
            addons = random.sample(MAP_ADDONS, 2)
            for i, addon in enumerate(addons, 1):
                dbd_embed.add_field(name=f"Addon {i}: ", value=addon, inline=True)
        elif base_item == "Key":
            addons = random.sample(KEY_ADDONS, 2)
            for i, addon in enumerate(addons, 1):
                dbd_embed.add_field(name=f"Addon {i}: ", value=addon, inline=True)

        dbd_embed.add_field(name="Offering: ", value=randint(1,43), inline=True)

        await interaction.response.send_message(embed=dbd_embed, ephemeral=True)

    elif role == "k":
        dbd_embed.set_image(url=random.choice(KILLER_ICON_LIST))
        dbd_embed.set_thumbnail(url="https://deadbydaylight.com/static/killer-icon-e4752058d3ae94a6d5838774a7a4162c.png")
        dbd_embed.set_author(name = "Your killer and their perks:")

        perks = random.sample(KILLER_PERK_LIST, 4)
        for i, perk in enumerate(perks, 1):
            dbd_embed.add_field(name=f"Perk {i}: ", value=perk, inline=False)

        dbd_embed.add_field(name=f"Addon 1: ", value=random_number_1, inline=True)
        dbd_embed.add_field(name=f"Addon 2: ", value=random_number_2, inline=True)

        dbd_embed.add_field(name="Offering: ", value=randint(1,43), inline=True)

        await interaction.response.send_message(embed=dbd_embed, ephemeral=True)
        
    else:
        await interaction.response.send_message("i literally have zero clue how this happened. like this genuinely should not be possible. if it gets to this point, dont even call braydon, call jesus, because were gonna need him.")


async def generate_random_numbers(interaction: discord.Interaction, number_bound: int, number_amount: int):
    random_number_string = ""
    for _ in range(number_amount):
        random_number_string += str(randint(1, number_bound)) + "  "
    if len(random_number_string) < 2000:
        await interaction.response.send_message(random_number_string)
    else:
        await interaction.response.send_message("There is no way you need that many random numbers that large. Try again with less.", ephemeral=True)


async def search_wikipedia(interaction: discord.Interaction, wiki_search: str):
    await interaction.response.defer()
    wiki_wiki = wikipediaapi.Wikipedia(
        user_agent='MyProjectName (merlin@example.com)',
        language='en'
    )
    try:
        wiki_page = wiki_wiki.page(wiki_search)
        
        if not wiki_page.exists():
            await interaction.followup.send(f"no results found for '{wiki_search}'. please try another search term.")
            return
        
        # Send the page URL
        await interaction.followup.send(wiki_page.fullurl)
    except Exception as e:
        await interaction.followup.send(f"An error occurred while searching Wikipedia: {str(e)}")


async def get_bible_verse(interaction: discord.Interaction):
    await interaction.response.defer()
    url = 'https://labs.bible.org/api/?passage=random'
    req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
    with urllib.request.urlopen(req) as response:
        data = response.read()
    data = data.decode('utf-8')
    data = data.replace('<b>', '**').replace('</b>', '**')
    data = data.replace('\xe2\x80\x9c', "'")
    data = data.replace('\xe2\x80\x9d', "'")
    data = data.replace("b'", "")
    await interaction.followup.send(data)


async def get_definition(interaction: discord.Interaction, word_to_define: str):
    await interaction.response.defer()

    word_to_define = re.sub(r'\W+', '', word_to_define)

    url = f'https://api.dictionaryapi.dev/api/v2/entries/en/{word_to_define}'
    req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})

    try:
        with urllib.request.urlopen(req) as response:
            data = response.read()
        entries = json.loads(data)
    except urllib.error.HTTPError as e:
        await interaction.followup.send(f"HTTP Error: {e.code} - {e.reason}. most likely this means you tried to look up a nonsense or non-existent word. check if a '**{word_to_define}**' really exists, then get back to me.")

    entry = entries[0]

    d_embed = discord.Embed()
    d_embed.title = entry['word'].capitalize()
    d_embed.add_field(name="----------------------------------------------", value="Definitions for the word:")

    for meaning in entry['meanings']:
        part_of_speech = meaning['partOfSpeech']
        for definition_entry in meaning['definitions']:
            definition = definition_entry['definition']
            example = definition_entry.get('example')
            
            d_embed.add_field(name=part_of_speech, value=definition, inline=False)
            if example:
                d_embed.set_footer(text=f"Example: {example}")

    await interaction.followup.send(embed=d_embed)


async def check_and_upload_ascii(message: discord.Message):
    if "asciify" in message.content.lower():
        if message.attachments:
            attachment = message.attachments[0]
            if attachment.content_type.startswith("image/"):
                try:
                    async with aiohttp.ClientSession() as session:
                        async with session.get(attachment.url) as resp:
                            if resp.status != 200:
                                await message.reply(f"Failed to download image: {resp.status}")
                                return
                            data = await resp.read()
                            image = io.BytesIO(data)
                            art_data = AsciiArt.from_image(image)
                            ascii_art = art_data.to_ascii(monochrome=True)
                            ascii_art.replace("`", "'")
                            with io.StringIO() as ascii_file:
                                ascii_file.write(ascii_art)
                                ascii_file.seek(0)
                                await message.reply(file=discord.File(ascii_file, "ascii_art.txt"))
                except OSError as e:
                    await message.reply(f'could not load the image, server said: {e}')
            else:
                await message.reply("that attachment isnt an image. try again buddy")
        else:
            await message.reply("post an image with the message 'asciify' and ill asciify it")
        return True


async def convert_to_pdf(message: discord.Message):
    if "pdf" in message.content.lower():
        if message.attachments:
            images = []
            for attachment in message.attachments:
                if attachment.content_type.startswith("image/"):
                    try:
                        async with aiohttp.ClientSession() as session:
                            async with session.get(attachment.url) as resp:
                                if resp.status != 200:
                                    await message.reply(f"Failed to download image: {resp.status}")
                                    return
                                data = await resp.read()
                                images.append(data)
                    except OSError as e:
                        await message.reply(f"could not load the image, server said: {e}")
                        return
                else:
                    await message.reply("i can only make images pdfs, not videos or something. try again")
                    return

            if images:
                try:
                    # Convert all images to a single PDF
                    pdf_bytes = img2pdf.convert(images)

                    # Prepare the PDF to be sent back as a Discord file
                    pdf_file = discord.File(BytesIO(pdf_bytes), filename="hw.pdf")
                    await message.reply("here you go:", file=pdf_file)
                except Exception as e:
                    await message.reply(f"well chief, i messed up the conversion. heres what the error says: {e}")
            else:
                await message.reply("bruh there aint no images")
        else:
            await message.reply("upload images with the word 'pdf' and ill convert them all into one pdf")
        return True

