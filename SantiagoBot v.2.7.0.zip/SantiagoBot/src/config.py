import discord
import os

from discord.ext import commands
from openai import OpenAI
from elevenlabs.client import ElevenLabs

# api keys and bot token

BOT_TOKEN = os.getenv("BOT_TOKEN")
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
ELEVENLABS_API_KEY = os.getenv("ELEVENLABS_API_KEY")

# discord bot and openai/elevenlabs client initialization
bot = commands.Bot(command_prefix='s ', intents=discord.Intents.all())
OpenAIClient = OpenAI(api_key=OPENAI_API_KEY)
ElevenLabsClient = ElevenLabs(api_key=ELEVENLABS_API_KEY)

# handles voice clients for the bot
voice_clients = {}

# stores each guild's (server's) video queue for youtube-play
video_queue = {}

# holds ai context memory
# TODO: make this local to each channel, or atleast to each server. As of now, it remembers everything it hears from any server which is dumb
ai_message_history = []
MAX_HISTORY_LENGTH = 2500

# variables for youtube-play. self explanatory.
loop_current_video = False
volume_multiplier = 1

async def get_volume_multiplier():
    return volume_multiplier

async def set_volume_multiplier(number):
    global volume_multiplier
    volume_multiplier = number