import discord
import logging

from random import randint
from logging.handlers import RotatingFileHandler


# setting up loggers
d_logger = logging.getLogger('deleted_messages_logger')
d_logger.setLevel(logging.INFO)

e_logger = logging.getLogger('edited_messages_logger')
e_logger.setLevel(logging.INFO)

app_com_logger = logging.getLogger('application_commands_logger')
app_com_logger.setLevel(logging.INFO)

txt_com_logger = logging.getLogger('slash_commands_logger')
txt_com_logger.setLevel(logging.INFO)

vc_logger = logging.getLogger('voice_channels_logger')
vc_logger.setLevel(logging.INFO)

work_logger = logging.getLogger('work_logger')
work_logger.setLevel(logging.INFO)



# setting up file handlers

d_message_file_handler = RotatingFileHandler(
    'src/data/logs/deleted_messages_log.txt', 
    maxBytes=2*1024*1024,  # 2 MB limit
    backupCount=5  # Keep 5 backups
)
d_message_file_handler.setFormatter(logging.Formatter('%(asctime)s - %(message)s', datefmt='%Y-%m-%d %H:%M:%S'))
d_logger.addHandler(d_message_file_handler)


e_message_file_handler = RotatingFileHandler(
    'src/data/logs/edited_messages_log.txt', 
    maxBytes=2*1024*1024, # 2 MB limit
    backupCount=5  
)
e_message_file_handler.setFormatter(logging.Formatter('%(asctime)s - %(message)s', datefmt='%Y-%m-%d %H:%M:%S'))
e_logger.addHandler(e_message_file_handler)


command_file_handler = RotatingFileHandler(
    'src/data/logs/command_usage_log.txt', 
    maxBytes=2*1024*1024,  # 2 MB limit
    backupCount=5 
)
command_file_handler.setFormatter(logging.Formatter('%(asctime)s - %(message)s', datefmt='%Y-%m-%d %H:%M:%S'))
app_com_logger.addHandler(command_file_handler)
txt_com_logger.addHandler(command_file_handler)


vc_file_handler = RotatingFileHandler(
    'src/data/logs/voice_channel_log.txt', 
    maxBytes=2*1024*1024,  # 2 MB limit
    backupCount=5 
)
vc_file_handler.setFormatter(logging.Formatter('%(asctime)s - %(message)s', datefmt='%Y-%m-%d %H:%M:%S'))
vc_logger.addHandler(vc_file_handler)


work_file_handler = RotatingFileHandler(
    'src/data/logs/work_log.txt', 
    maxBytes=2*1024*1024,  # 2 MB limit
    backupCount=5 
)
work_file_handler.setFormatter(logging.Formatter('%(asctime)s - %(message)s', datefmt='%Y-%m-%d %H:%M:%S'))
work_logger.addHandler(work_file_handler)


# setting up console handlers

d_message_console_handler = logging.StreamHandler()
d_message_console_handler.setFormatter(logging.Formatter(
    '\x1b[30;1m%(asctime)s\x1b[0m \x1b[31mDELETED MESSAGE\x1b[0m %(message)s', datefmt='%Y-%m-%d %H:%M:%S'))
d_logger.addHandler(d_message_console_handler)

e_message_console_handler = logging.StreamHandler()
e_message_console_handler.setFormatter(logging.Formatter(
    '\x1b[30;1m%(asctime)s\x1b[0m \x1b[33mEDITED MESSAGE\x1b[0m %(message)s', datefmt='%Y-%m-%d %H:%M:%S'))
e_logger.addHandler(e_message_console_handler)

command_console_handler = logging.StreamHandler()
command_console_handler.setFormatter(logging.Formatter(
    '\x1b[30;1m%(asctime)s\x1b[0m \x1b[32mCOMMAND USAGE\x1b[0m %(message)s', datefmt='%Y-%m-%d %H:%M:%S'))
app_com_logger.addHandler(command_console_handler)
txt_com_logger.addHandler(command_console_handler)

vc_console_handler = logging.StreamHandler()
vc_console_handler.setFormatter(logging.Formatter(
    '\x1b[30;1m%(asctime)s\x1b[0m \x1b[36mVC UPDATE\x1b[0m %(message)s', datefmt='%Y-%m-%d %H:%M:%S'))
vc_logger.addHandler(vc_console_handler)

work_console_handler = logging.StreamHandler()
work_console_handler.setFormatter(logging.Formatter(
    '\x1b[30;1m%(asctime)s\x1b[0m \x1b[30mWORK\x1b[0m %(message)s', datefmt='%Y-%m-%d %H:%M:%S'))
work_logger.addHandler(work_console_handler)



##########################################################################################
#                               LOGGING COMMANDS START HERE                              #
##########################################################################################


async def log_deleted_message(message):
    log_message = f'[{message.guild.name}] [# {message.channel.name}] {message.author.display_name} ({message.author}): {message.content}'
    d_logger.info(log_message)


async def log_edited_message(message_before, message_after):
    log_message = f'[{message_before.guild.name}] [# {message_before.channel.name}] {message_before.author.display_name} ({message_before.author}): {message_before.content} --> {message_after.content}'
    e_logger.info(log_message)


async def log_app_command_usage(interaction, command):
    command_arguments = interaction.data.get("options", [])
    arguments_str = ', '.join(f"{arg['name']}={arg['value']}" for arg in command_arguments) if command_arguments else ''

    if interaction.channel.type == discord.ChannelType.private:
        if arguments_str:
            log_message = f'{interaction.user.display_name} ({interaction.user}) used command in DMs: "/{command.name}" with arguments "{arguments_str}"'
        else:
            log_message = f'{interaction.user.display_name} ({interaction.user}) used command in DMs: "/{command.name}"'
    else:
        if arguments_str:
            log_message = f'[{interaction.guild.name}] [# {interaction.channel.name}] {interaction.user.display_name} ({interaction.user}) used command: "/{command.name}" with arguments "{arguments_str}"'
        else:
            log_message = f'[{interaction.guild.name}] [# {interaction.channel.name}] {interaction.user.display_name} ({interaction.user}) used command: "/{command.name}"'
    
    app_com_logger.info(log_message)


async def log_text_command(message, command_name):
    if message.channel.type == discord.ChannelType.private:
        log_message = f'{message.author.display_name} ({message.author}) used text command in DMs: "{command_name}"'
    else:
        log_message = f'[{message.guild.name}] [# {message.channel.name}] {message.author.display_name} ({message.author}) used text command "{command_name}"'
    app_com_logger.info(log_message)


async def log_voice_state_updates(user, voice_before, voice_after):
    if voice_before.channel and not voice_after.channel:
        log_message = f'{user.display_name} ({user}) just left voice channel "{voice_before.channel.name}" in guild "{voice_before.channel.guild}"'
        vc_logger.info(log_message)
    elif voice_after.channel is not voice_before.channel and voice_before.channel is None:
        log_message = f'{user.display_name} ({user}) just joined voice channel "{voice_after.channel.name}" in guild "{voice_after.channel.guild}"'
        vc_logger.info(log_message)
    elif voice_after.channel is not voice_before.channel and voice_before.channel is not None:
        log_message = f'{user.display_name} ({user}) just changed voice channel from "{voice_before.channel.name}" to "{voice_after.channel.name}" in guild "{voice_after.channel.guild}"'
        vc_logger.info(log_message)
    elif voice_before.self_stream is not voice_after.self_stream and voice_after.self_stream is True:
        log_message = f'{user.display_name} ({user}) just started streaming in "{voice_after.channel.name}" in guild "{voice_after.channel.guild}"'
        vc_logger.info(log_message)
    elif voice_before.self_stream is not voice_after.self_stream and voice_after.self_stream is not True:
        log_message = f'{user.display_name} ({user}) just stopped streaming in "{voice_before.channel.name}" in guild "{voice_before.channel.guild}"'
        vc_logger.info(log_message)


async def log_work(message, awards_list):
    if message.channel.type == discord.ChannelType.private:
        log_message = f'{message.author.display_name} ({message.author}) worked in DMs'
    else:
        log_message = f'{message.author.display_name} ({message.author}) worked in [{message.guild.name}] [# {message.channel.name}]'
    if awards_list:
        log_message += " and unlocked the following:"
        log_message += " " + ", ".join(awards_list)
    work_logger.info(log_message)