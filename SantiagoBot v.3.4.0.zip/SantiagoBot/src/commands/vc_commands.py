import discord
import random
import asyncio

from discord.ext import commands
from random import randint

from src.config.main_config import bot
from src.data.reactions_lists import STOP_QUIP_TEMPLATES, PAUSE_QUIP_TEMPLATES, RESUME_QUIP_TEMPLATES, KILL_EXCLAMATION_TEMPLATES
from src.data.gif_and_image_lists import GIGACHAD_GIFS
from src.utils.inventory_utils import *
from src.utils.vc_utils import *
from src.utils.generic_utils import get_volume_multiplier, set_volume_multiplier, increment_amount_shot, increment_amount_gambled, increment_amount_exploded

class VolumePromptModal(discord.ui.Modal, title="Set a multiplier for Santiago's volume"):
    
    number = discord.ui.TextInput(label="Volume", placeholder="Enter a number between 0.01 and 20. 1 is default.", min_length=1, max_length=5)
    async def on_submit(self, interaction: discord.Interaction):
        try:
            number = float(self.number.value)
            if 0.01 <= number <= 20:
                set_volume_multiplier(interaction.guild.id, number)
                await interaction.response.send_message(f"big heads up to my homies in VC: {interaction.user.mention} just set the volume multiplier to {get_volume_multiplier(interaction.guild.id)}")
            else:
                await interaction.response.send_message("read the number range my guy and/or gal", ephemeral=True)
        except ValueError:
            await interaction.response.send_message("you shouldnt get this error. if you did, it means either i broke or you were screwing around. read the limits", ephemeral=True)


async def join_call_manual(interaction: discord.Interaction):
    vc = await join_call(interaction.user.voice.channel)
    if vc != None:
        await interaction.response.send_message("hi")
    elif vc == interaction.user.voice.channel:
        await interaction.response.send_message("are you stupid", emphemeral=True)
    else:
        await interaction.response.send_message(f"buddy, the command is for me to join call, not you. what, you think i can force you to join calls?", ephemeral=True)


async def leave_call(interaction: discord.Interaction):
    bot_voice_client = discord.utils.get(bot.voice_clients, guild=interaction.guild)
    if bot_voice_client is None:
        await interaction.response.send_message("are you stupid")
    else:
        voice_state = interaction.user.voice
        if voice_state is not None:
            if voice_state.channel != bot_voice_client.channel:
                await interaction.response.send_message("listen pal, i know youre jealous that im not in your channel, but i cant just leave here... that is, unless you used /join_call... then, well... i might be swayed ;)", ephemeral=True)
            else:
                await interaction.response.send_message("bye")
                await bot_voice_client.disconnect()
        else:
            await interaction.response.send_message("hold up buddy, i aint gonna let some non-caller tell me what to do... if you want me to leave, tell that to my face. join my call, then maybe we'll talk", ephemeral=True)


async def stop_sound(interaction: discord.Interaction):
    stop_quips = [template.format(stopper=interaction.user.mention) for template in STOP_QUIP_TEMPLATES]

    bot_voice_channel = discord.utils.get(bot.voice_clients, guild=interaction.guild)
    if bot_voice_channel is None:
        await interaction.response.send_message("are you stupid", ephemeral=True)
    else:
        if not bot_voice_channel.is_playing():
            await interaction.response.send_message("nothing is playing. check your ears, you might have tinnitus", ephemeral=True)
        else:
            voice_state = interaction.user.voice
            if voice_state is None:
                await interaction.response.send_message("bruh you aren't even in a vc", ephemeral=True)
            elif voice_state.channel != bot_voice_channel.channel:
                await interaction.response.send_message("you're just jealous this vc has better music than yours", ephemeral=True)
            else:
                bot_voice_channel.stop()
                await interaction.response.send_message(random.choice(stop_quips))


async def toggle_pause_state(interaction: discord.Interaction):
    user_voice_channel = interaction.user.voice.channel
    bot_voice_client = discord.utils.get(bot.voice_clients, guild=interaction.guild)

    if bot_voice_client is None:
        await interaction.response.send_message("brother or sister in christ, i'm not capable of pausing or playing that youtube video you've got queued up in the background... or whatever sound you're hearing. whatever you're hearing, you're not hearing it in call, that's for sure. get in call.", ephemeral=True)
        return
    if bot_voice_client.channel != user_voice_channel:
        await interaction.response.send_message("yeah, very funny. i'm not letting you pause or resume a sound i may or may not be playing from outside the call im actually in", ephemeral=True)
        return
    if bot_voice_client.is_playing():
        bot_voice_client.pause()
        pause_quips = [template.format(pauser=interaction.user.mention) for template in PAUSE_QUIP_TEMPLATES]
        await interaction.response.send_message(random.choice(pause_quips))    
    elif bot_voice_client.is_paused():
        bot_voice_client.resume()
        resume_quips = [template.format(resumer=interaction.user.mention) for template in RESUME_QUIP_TEMPLATES]
        await interaction.response.send_message(random.choice(resume_quips))
    else:
        await interaction.response.send_message("im sorry. im not capable of pausing the voices in your head. good luck.")


async def play_oblivion_music(interaction: discord.Interaction):

    voice_state = interaction.user.voice
    if voice_state is None:
        await interaction.response.send_message("the only oblivion moment is you for not being in call", ephemeral=True)
        return
    user_voice_channel = interaction.user.voice.channel
    if user_voice_channel is not None:
        await join_and_play_sound(interaction.user.voice.channel, "src/data/sound_files/oblivion.mp3", 0.35)
        await interaction.response.send_message(f"oblivion", ephemeral=True)
    else:
        await interaction.response.send_message(f"you're not in a voice channel. get in there", ephemeral=True)


async def play_ltg_speech(interaction: discord.Interaction, person_to_ltg: discord.Member):
    
    if(person_to_ltg == bot.user):
        await interaction.response.defer()
        await interaction.followup.send(f"{interaction.user.mention} thinks they're pretty funny")
        for k in range(5):
          await interaction.followup.send("https://media.tenor.com/C8MpzwDxl40AAAAM/ltg-low-tier-god.gif")

    
    if(person_to_ltg == interaction.user):
        await interaction.response.defer()
        await interaction.response.send_message(f"why are you telling yourself to kill yourself? are you alright buddy?", ephemeral=True)
        return

    
    voice_state = person_to_ltg.voice
    if voice_state is None:
        await interaction.response.send_message("someone in __vc.__ not the aether", ephemeral=True)
        return
    
    
    else:
        user_voice_channel = person_to_ltg.voice.channel
        if user_voice_channel is not None:
            vc = await join_and_play_sound(user_voice_channel, "src/data/sound_files/ltgspeech.mp3", 0.4)
            await interaction.response.send_message("give it a sec...", ephemeral=True)
            await asyncio.sleep(34)
            if vc.is_playing():
                await interaction.channel.send(f"{person_to_ltg.mention}")
                await interaction.channel.send(f"https://media.tenor.com/C8MpzwDxl40AAAAM/ltg-low-tier-god.gif") 
        else:
            await interaction.response.send_message("this error should literally never be reached. if it was, yell for braydon", ephemeral=True)


async def play_clown_sound(interaction: discord.Interaction, person_to_clown: discord.Member):
    
    await interaction.response.defer(ephemeral=True)

    if(person_to_clown == bot.user):
        await interaction.followup.send(f"oh yeah? https://media.tenor.com/C8MpzwDxl40AAAAM/ltg-low-tier-god.gif")
    
    if(person_to_clown == interaction.user):
        await interaction.followup.send(f"no. i just feel bad for you", ephemeral=True)
        return

    voice_state = person_to_clown.voice
    if voice_state is None:
        await interaction.followup.send("the only clown here is you for not reading the 3rd through 5th words of this command's description", ephemeral=True)
        return
    
    else:
        await interaction.followup.send("gotcha. here's where the fun begins...", ephemeral=True)
        await impart_clown_judgement(interaction, person_to_clown)


async def play_gigachad_music(interaction: discord.Interaction, person_to_giga: discord.Member):

    if(person_to_giga.id == 948588784893714462):
        await interaction.response.send_message(f"{interaction.user.mention} thinks they're pretty funny... and they're right! Love ya ;)")
        return
    
    voice_state = person_to_giga.voice
    if voice_state is None:
        await interaction.response.send_message("its very nice you like them so much you think they deserve a gigachad, but they should be in call. theyre not in call", ephemeral=True)
        return
    
    else:
        user_voice_channel = person_to_giga.voice.channel
        if user_voice_channel is not None:

            if(person_to_giga == interaction.user):
                await interaction.response.send_message("nice try buddy. ive got a better music choice for you instead.", ephemeral=True)
                await asyncio.sleep(1)
                await impart_clown_judgement(interaction, person_to_giga)
                
            else:
                await join_and_play_sound(interaction.user.voice.channel, "src/data/sound_files/gigachad.mp3", 0.5)
                await interaction.response.send_message(f"{person_to_giga.mention} {random.choice(GIGACHAD_GIFS)}")

        else:
            await interaction.response.send_message("this error should literally never be reached. if it was, yell for braydon")


async def russian_roulette(interaction: discord.Interaction):
    user_id = interaction.user.id
    
    await interaction.response.defer()
    await increment_amount_gambled(user_id)

    if interaction.user.voice is None:
        await interaction.followup.send("get in a VC if you want to play russian roulette", ephemeral=True)
    else:
        random_number = randint(1, 1000)
        if random_number in range(1, 167):
            await shoot_and_play_gunshot(interaction.user)
            await interaction.followup.send(interaction.user.display_name + " was not lucky. They lost 500**SB**...")
            await update_user_currency(user_id, -500)
            await increment_amount_shot(user_id)
        else:
            await interaction.followup.send(interaction.user.display_name + ", you were lucky this time. You earned 100**SB**!")
            await update_user_currency(user_id, 100)


async def shoot_user(interaction: discord.Interaction, victim: discord.Member):
    user_id = interaction.user.id

    await interaction.response.defer(ephemeral=True)
    if victim.voice is None:
        await interaction.followup.send("i can't shoot someone who isn't in a vc")
    elif victim.id == bot.user.id:
        await interaction.followup.send("that's it. im taking all your bullets for that. go check your inventory. do better next time.")
        old_bullet_count = await get_item_amount(user_id, Item.BULLET)
        await set_item_amount(user_id, Item.BULLET, 0)
        await asyncio.sleep(10)
        await set_item_amount(user_id, Item.BULLET, old_bullet_count)
        await interaction.followup.send("i'm kidding. i'll give your bullets back. but seriously, do better next time.")
    else:
        if await get_item_amount(user_id, Item.BULLET) > 0:
            await shoot_and_play_gunshot(victim)
            if victim.id == interaction.user.id:
                await interaction.channel.send(interaction.user.mention + " just shot themself")
                await interaction.followup.send("that was funny so i'm giving you a free bullet")
            else:
                await update_item_amount(user_id, Item.BULLET, -1)
                kill_exclamations = [template.format(killer=interaction.user.mention, killed=victim.mention) for template in KILL_EXCLAMATION_TEMPLATES]
                await interaction.channel.send(random.choice(kill_exclamations))
                await interaction.followup.send("the deed is done.")
        else:
            await interaction.followup.send("you don't have enough bullets to shoot anyone. use 's inv' to check your inventory.")
    

async def blind_fire(interaction: discord.Interaction, vc: discord.Member):
    user_id = interaction.user.id

    potential_victims = [member for member in vc.members if not member.bot]

    if len(potential_victims) > 0:

        if await get_item_amount(user_id, Item.BULLET) > 0:

            await update_item_amount(user_id, Item.BULLET, -1)

            await interaction.response.send_message(f"everyone in VC, get ready... {interaction.user.mention}'s firing blind...")
            await join_and_play_sound(vc, "src/data/sound_files/random_select.mp3", 1)
            await asyncio.sleep(4.2)
            await shoot_and_play_gunshot(random.choice(potential_victims))

        else:
            await interaction.response.send_message("you don't have enough bullets to shoot. use 's inv' to check your inventory.", ephemeral=True)
    else:
        await interaction.response.send_message("woah there partner, no one is in that call! saved you a bullet", ephemeral=True)


async def nuke_vc(interaction: discord.Interaction, victim_channel: discord.VoiceChannel):
    user_id = interaction.user.id

    if not victim_channel.members:
        await interaction.response.send_message("point me to a VC with people in it", ephemeral=True)

    else:
        if await get_item_amount(user_id, Item.NUKE) > 0:

            await update_item_amount(user_id, Item.NUKE, -1)
            await interaction.response.defer()

            await join_and_play_sound(victim_channel, "src/data/sound_files/nuke.mp3", 10)
            await asyncio.sleep(14)

            nuked_users = [member for member in victim_channel.members]
            nuke_elegy = ""
            for nuke_victim in nuked_users:
                if nuke_victim.voice:
                    await nuke_victim.move_to(None)
                    await increment_amount_exploded(nuke_victim.id)
                    nuke_elegy += nuke_victim.mention + " "
            
            if nuke_elegy:
                await interaction.followup.send(f"{interaction.user.mention} just nuked '{victim_channel}', including the following victims: {nuke_elegy}")
            else:
                await interaction.followup.send(F"{interaction.user.mention} attempted a nuke on '{victim_channel}', but everyone had been evacuated!")

        else:
            await interaction.response.send_message("you need a nuke to nuke people. use 's inv' to check your inventory", ephemeral=True)


async def unleash_whirlwind(interaction: discord.Interaction, victim_channel: discord.VoiceChannel):
    user_id = interaction.user.id

    if not victim_channel.members:
        await interaction.response.send_message("point me to a VC with people in it", ephemeral=True)

    else:
        if await get_item_amount(user_id, Item.ELEMENTAL_GEM) > 0:

            await update_item_amount(user_id, Item.ELEMENTAL_GEM, -1)
            await interaction.response.defer()

            whirled_users = [member for member in victim_channel.members]
            for _ in range(3):  
                for whirl_victim in whirled_users:
                    if whirl_victim.voice and whirl_victim is not bot.user:
                        available_channels = [channel for channel in victim_channel.guild.voice_channels if channel != victim_channel]
                        if available_channels:
                            random_channel = random.choice(available_channels)
                            await whirl_victim.move_to(random_channel)
                await asyncio.sleep(1)

            await interaction.followup.send(f"{interaction.user.mention} just unleashed a whirlwind on VC! everyone's channels were scrambled!")
        else:
            await interaction.response.send_message("you don't have anything capable of conjuring a tornado... maybe if you spun your hands in a circle really fast. use 's inv' to check your inventory", ephemeral=True)


async def plant_landmine(interaction: discord.Interaction, voice_channel: discord.VoiceChannel):
    user_id = interaction.user.id

    if await get_item_amount(user_id, Item.LANDMINE) > 0:
        await update_item_amount(user_id, Item.LANDMINE, -1)

        await interaction.response.send_message("i wonder who the unlucky sap is gonna be", ephemeral=True)

        interaction_channel = interaction.channel
        interaction_user = interaction.user

        # To store the user who triggered the event
        def check_voice_state(user, before, after):
            if after.channel == voice_channel:
                return user, after
            return False

        async def voice_state_update_event():
            while True:
                user, before, after = await bot.wait_for('voice_state_update', timeout=21600, check=check_voice_state)
                if user:
                    await asyncio.sleep(0.5)
                    await join_and_play_sound(after.channel, "src/data/sound_files/landmine.mp3", 2)
                    await asyncio.sleep(0.5)
                    if user.voice.channel == after.channel:
                        await user.move_to(None)
                        await increment_amount_exploded(user.id)
                        if user != interaction_user:
                            await interaction_channel.send(f"{user.mention} just triggered {interaction_user.mention}'s landmine!")
                        else:
                            await interaction_channel.send(f"{interaction_user.mention} good job dingus")
                    else:
                        if user != interaction_user:
                            await interaction_channel.send(f"{user.mention} deftly dodged {interaction_user.mention}'s landmine!")
                        else:
                            await interaction_channel.send(f"{user.mention} dodged their own landmine... cool...?")
                    break

        voice_state_task = asyncio.create_task(voice_state_update_event())

        try:
            done, pending = await asyncio.wait(
                [voice_state_task],
                return_when=asyncio.FIRST_COMPLETED
            )

            for task in done:
                task.result() 

            for task in pending:
                task.cancel()

        except asyncio.CancelledError:
            pass
        except asyncio.TimeoutError:
            await interaction_channel.send(f"A landmine just timed out in {voice_channel}!")
    else:
        await interaction.response.send_message("i would consider buying a landmine before using the landmine command that says you need a landmine in order to plant a landmine.", ephemeral=True)


async def missile_target(interaction: discord.Interaction, victim: discord.Member):

    user_id = interaction.user.id

    if victim.id == bot.user.id:
        if interaction.user.voice:
            await join_and_play_sound(interaction.user.voice.channel, "src/data/sound_files/landmine.mp3", 2)
            await asyncio.sleep(0.5)
            if interaction.user.voice:
                await interaction.user.move_to(None)
            await increment_amount_exploded(interaction.user.id)
            await interaction.response.send_message("no", ephemeral=True)
        else:
            await interaction.response.send_message("don't make me take away your missiles.", ephemeral=True)
        return
    
    else:

        await interaction.response.send_message(f"your missile has been deployed. it will watch closely for signs of {victim.mention} in VC", ephemeral=True)

        interaction_channel = interaction.channel
        interaction_user = interaction.user

        if await get_item_amount(user_id, Item.HEAT_SEEKING_MISSILE) > 0:

            await update_item_amount(user_id, Item.HEAT_SEEKING_MISSILE, -1)


            # Define the check functions
            def check_typing(channel, user, when):
                return user == victim and victim.voice

            def check_message(message):
                return message.author == victim and victim.voice
            
            def check_command_completion(interaction):
                return interaction.user == victim and victim.voice
            
            def check_voice_state(before, after, channel):
                return victim.voice

            # Create tasks for waiting for events
            typing_task = asyncio.create_task(bot.wait_for('typing', timeout=21600, check=check_typing))
            message_task = asyncio.create_task(bot.wait_for('message', timeout=21600, check=check_message))
            command_completion_task = asyncio.create_task(bot.wait_for('interaction', timeout=21600, check=check_command_completion))
            voice_state_task = asyncio.create_task(bot.wait_for('voice_state_update', timeout=21600, check=check_voice_state))

            try:
                # Wait for one of the tasks to completee
                done, pending = await asyncio.wait(
                    [typing_task, message_task, command_completion_task, voice_state_task],
                    return_when=asyncio.FIRST_COMPLETED
                )

                for task in done:

                    victim_vc = victim.voice.channel if victim.voice else None

                    await join_and_play_sound(victim_vc, "src/data/sound_files/landmine.mp3", 1.75)
                    await asyncio.sleep(0.5)

                    if victim.voice is not None and victim.voice.channel == victim_vc:
                        await victim.move_to(None)
                        await increment_amount_exploded(victim.id)
                        if victim != interaction_user:
                            if task == typing_task:
                                await interaction_channel.send(f"the friction heat of {victim.mention}'s typing attracted {interaction_user.mention}'s missile!")
                            elif task == message_task:
                                await interaction_channel.send(f"the arrival of {victim.mention}'s posted messsage gave {interaction_user.mention}'s missile a pinpointed location!")
                            elif task == command_completion_task:
                                await interaction_channel.send(f"{victim.mention} used a command, unknowingly notifying {interaction_user.mention}'s missile!")
                            elif task == voice_state_task:
                                await interaction_channel.send(f"{victim.mention}'s movements were picked up by {interaction_user.mention}'s missile!")
                        else:
                            await interaction_channel.send(f"well, {victim.mention} inexplicably blew themselves up with their own missile")
                    else:
                        if victim != interaction_user:
                            await interaction_channel.send(f"{victim.mention} had crazy reflexes and dodged {interaction_user.mention}'s missile")
                    
                        else:
                            print("it claims the vc after the check was none")
                            await interaction_channel.send(f"for some reason, {victim.mention} decided to target themselves with a missile only to dodge it...?")
                
                for task in pending:
                    task.cancel()

            except asyncio.CancelledError:
                pass
            except asyncio.TimeoutError:
                await interaction_channel.send(f"A Heat-seeking Missile targetting {victim.mention} just returned to base!")
        else:
            await interaction.response.send_message("i would recommend getting a missile before targeting someone with a missile. and make sure it isn't a cheap one.", ephemeral=True)   


async def emergency_evac(interaction: discord.Interaction, victim_channel: discord.VoiceChannel):
    user_id = interaction.user.id
    if interaction.user.voice is not None:
        if interaction.user.voice.channel != victim_channel:

            if await get_item_amount(user_id, Item.FLARE) > 0:

                await update_item_amount(user_id, Item.FLARE, -1)
                await interaction.response.send_message(f"{interaction.user.mention} just initiated an evacuation! to all those in VC, be prepared to be delivered to '{victim_channel}'!")

                await join_and_play_sound(interaction.user.voice.channel, "src/data/sound_files/helicopter.mp3", 1)
                await asyncio.sleep(5)

                evac_users = [member for member in interaction.user.voice.channel.members if not member.bot]

                for user in evac_users:
                    if user.voice:
                        await user.move_to(victim_channel)
                        await asyncio.sleep(1) 

                await join_call(victim_channel)

            else:
                await interaction.response.send_message("helicopters aren't gonna see just you. and no, arranging stones into 'HELP' isn't going to do anything either. you need a flare. type 's inv' to see your inventory.", ephemeral=True)
        else: 
            await interaction.response.send_message("you want the chopper to rescue you... by dropping you exactly where you came from...?", ephemeral=True)
    else: 
        await interaction.response.send_message("you have to drop your flare where the choppers can see you. visibility is clearest in a VC", ephemeral=True)


async def shotgun_blast(interaction: discord.Interaction, victim_channel: discord.VoiceChannel):
    user_id = interaction.user.id

    potential_victims = [member for member in victim_channel.members if not member.bot]
    random.shuffle(potential_victims)

    if len(potential_victims) > 0:

        if await get_item_amount(user_id, Item.SHOTGUN_SHELL) > 0:
            await update_item_amount(user_id, Item.SHOTGUN_SHELL, -1)

            await join_and_play_sound(victim_channel, "src/data/sound_files/load_shell.mp3", 1)

            real_victims = []
            for victim in potential_victims:
                if victim.voice:
                    if not real_victims:
                        real_victims.append(victim)
                    else:
                        if random.randint(1, 24) < 8:
                            real_victims.append(victim)

            await interaction.response.send_message(f"{interaction.user.mention}'s aimed their shotgun at VC!")
            await asyncio.sleep(3)

            await join_and_play_sound(victim_channel, "src/data/sound_files/shotgun.mp3", 1)
            await asyncio.sleep(.4)

            for user in real_victims:
                if user.voice:
                    await user.move_to(None)
                    await increment_amount_shot(user.id)

        else:
            await interaction.response.send_message("you don't have enough shells to shoot. use 's inv' to check your inventory.", ephemeral=True)
    else:
        await interaction.response.send_message("woah there partner, no one is in that call! saved you a bullet", ephemeral=True)


async def jam_user(interaction: discord.Interaction, victim: discord.Member):

    user_id = interaction.user.id

    if victim.id == bot.user.id:
        if interaction.user.voice:
            await interaction.response.defer(ephemeral=True)
            await join_and_play_sound(interaction.user.voice.channel, "src/data/sound_files/load_shell.mp3", 1)
            await asyncio.sleep(3)
            await join_and_play_sound(interaction.user.voice.channel, "src/data/sound_files/shotgun.mp3", 1)
            await asyncio.sleep(.38)
            if interaction.user.voice:
                await interaction.user.move_to(None)
            await increment_amount_shot(interaction.user.id)
            await interaction.followup.send("no")
        else:
            await interaction.response.send_message("signal jammer? im going to jam this signal up your ass.", ephemeral=True)

    elif victim.id == interaction.user.id:
        if interaction.user.voice:
            await interaction.response.send_message("hey, if you wanted muted, you could've just asked. its on the house! no jammer required.", ephemeral=True)
            await mute_user(victim)
            await asyncio.sleep(30)
            await unmute_user(victim)
        else:
            await interaction.response.send_message("come in a call real quick, then we'll see.", ephemeral=True)
    
    else:
        if await get_item_amount(user_id, Item.SIGNAL_JAMMER) > 0:
            if victim.voice:
                await update_item_amount(user_id, Item.SIGNAL_JAMMER, -1)
                await interaction.response.send_message(f"{interaction.user.mention} deployed a signal jammer on {victim.mention}!")
                await join_and_play_sound(victim.voice.channel, "src/data/sound_files/jammer.mp3", 0.1)
                await mute_user(victim)
                await asyncio.sleep(12)
                await unmute_user(victim)
            else:
                await interaction.response.send_message("they aren't in range for you to deploy a jammer on them. wait until they're in the vicinity of a VC", ephemeral=True)
        else:
            await interaction.response.send_message("what, are you gonna jam their signal with your mind? go buy or craft a signal jammer. type 's inv' to check your inventory", ephemeral=True)


async def throw_flashbang(interaction: discord.Interaction, victim: discord.Member):

    user_id = interaction.user.id

    if victim.id == bot.user.id:
        if interaction.user.voice:
            await interaction.response.defer(ephemeral=True)
            await join_and_play_sound(interaction.user.voice.channel, "src/data/sound_files/load_shell.mp3", 1)
            await asyncio.sleep(3)
            await join_and_play_sound(interaction.user.voice.channel, "src/data/sound_files/shotgun.mp3", 1)
            await asyncio.sleep(.38)
            if interaction.user.voice:
                await interaction.user.move_to(None)
            await increment_amount_shot(interaction.user.id)
            await interaction.followup.send("no")
        else:
            await interaction.response.send_message("flash bang? how about you flash and then bang a bitch instead? (consensually)", ephemeral=True)

    elif victim.id == interaction.user.id:
        if interaction.user.voice:
            await interaction.response.send_message("hey, if you wanted deafened, you could've just asked. its on the house! no flashbang required.", ephemeral=True)
            await deafen_user(victim)
            await asyncio.sleep(15)
            await undeafen_user(victim)
        else:
            await interaction.response.send_message("come in a call real quick, then we'll see.", ephemeral=True)
    
    else:
        if await get_item_amount(user_id, Item.FLASHBANG) > 0:
            if victim.voice:
                await update_item_amount(user_id, Item.FLASHBANG, -1)
                await interaction.response.send_message(f"{interaction.user.mention} deployed a signal jammer on {victim.mention}!")
                await flashbang_user(victim)
            else:
                await interaction.response.send_message("they aren't in flashbang throwing range. wait until they're in a VC", ephemeral=True)
        else:
            await interaction.response.send_message("i hope by flashbanging them, you don't actually mean you are going to flash and then bang them in the metaphorical sense.  "
                                                    "at least, that's the only thing it could be, because you don't have a flashbang to flashbang them. use 's inv' to check your inventory.", ephemeral=True)
            


async def emp_vc(interaction: discord.Interaction, victim_channel: discord.VoiceChannel):
    user_id = interaction.user.id

    if not victim_channel.members:
        await interaction.response.send_message("point me to a VC with people in it", ephemeral=True)

    else:
        if await get_item_amount(user_id, Item.EMP) > 0:

            await update_item_amount(user_id, Item.EMP, -1)
            await interaction.response.defer()

            await join_and_play_sound(victim_channel, "src/data/sound_files/emp.mp3", 1.2)
            await asyncio.sleep(2)

            emped_users = [member for member in victim_channel.members if not member.bot]
            emp_elegy = ""
            for emp_victim in emped_users:
                if emp_victim.voice:
                    await mute_user(emp_victim)
                    emp_elegy += emp_victim.mention + " "
            
            await asyncio.sleep(20)

            for emp_victim in emped_users:
                if emp_victim.voice:
                    await unmute_user(emp_victim)

            if emp_elegy:
                await interaction.followup.send(f"{interaction.user.mention} just EMPed '{victim_channel}'!")
            else:
                await interaction.followup.send(F"{interaction.user.mention} attempted an EMP on '{victim_channel}', but everyone had been evacuated!")

        else:
            await interaction.response.send_message("you can't just send your brainwaves at VC and expect something to happen. you need a proper EMP emitter. type 's inv' to check your inventory.", ephemeral=True)


async def warp_cast(interaction: discord.Interaction, victim: discord.Member):
    user_id = interaction.user.id

    await interaction.response.defer(ephemeral=True)

    if victim.id == bot.user.id:
        await flashbang_user(interaction.user)
        await interaction.followup.send("no", ephemeral=True)
        return

    if not victim.voice:
        await interaction.response.send_message("the warp staff doesn't reach that far. try casting it when they're in a VC.", ephemeral=True)
        return

    if await get_item_amount(user_id, Item.WARP_STAFF) > 0:
        await update_item_amount(user_id, Item.WARP_STAFF, -1)
            
        if victim.id == interaction.user.id:
            await interaction.followup.send("want to go for a ride, eh? i don't blame you.")
        else: 
            await interaction.followup.send(f"{interaction.user.mention} began casting a Warp Staff on {victim.mention}! Hold on tight!")

        for _ in range(10):  
            if victim.voice:
                available_channels = [channel for channel in victim.guild.voice_channels if channel != victim.voice.channel]
                if available_channels:
                    random_channel = random.choice(available_channels)
                    await victim.move_to(random_channel)
            await asyncio.sleep(0.5)

    else:
        await interaction.response.send_message("i don't think you're advanced enough in the art of sorcery to do this with just your hands. you'll need a staff. type 's inv' to check your inventory.", ephemeral=True)
