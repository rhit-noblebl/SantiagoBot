KILL_MESSAGES = [
  "damn.",
  "ez",
  "skill issue",
  "They will not be missed.",
  "It was a misinput, misinput... Calm Down! YOU CALM THE FUCK DOWN! IT WAS A MISINPUT!",
  "Bonafied, Monafied!",
  "\"He'S tUnNeLlInG mE!11!!!!11\"",
  "Your life is nothing. You serve *ZERO* purpose. You should kill yourself... *NOW*.",
  "That's gonna leave a mark!",
  "ant colony ant colony ant colony"
]

SUICIDE_MESSAGES = [
  "Are you okay buddy...?",
  "Do you need a hug...?",
  "Are you alright...?",
  "...",
  "LTG strikes again..."
]

QUEUE_QUIP_TEMPLATES = [
    "I hope you guys are prepared. {mention} just added `{title}` by `{uploader}` to the queue.",
    "Oh boy. Here we go again. {mention} just added `{title}` by `{uploader}` to the queue.",
    "la la la... wait what...? OH HOLY SHIT {mention} JUST ADDED `{title}` BY `{uploader}` TO THE QUEUE!!",
    "i hate this video too\n\n{mention} just added `{title}` by `{uploader}` to the queue.",
    "more pain\n\n{mention} just added `{title}` by `{uploader}` to the queue.",
    "Now I am become Tempo... queue\n\n{mention} just added `{title}` by `{uploader}` to the queue."
]

PLAY_QUIP_TEMPLATES = [
    "Alright, everyone shut the hell up. {mention} wants to play `{title}` by `{uploader}`.",
    "i hate this video\n\nPlaying `{title}` by `{uploader}`",
    "Now playing: `{title}` by `{uploader}`.",
    "Oh damn, it's `{title}` by `{uploader}`! Nice pick, {mention}!",
    "Regretfully, I have to play `{title}` by `{uploader}`. Don't blame me, {mention} requested it.",
    "Now I am become Tony... Youtube\n\nPlaying: `{title}` by `{uploader}`.",
    "i am rythm reborn\n\nPlaying: `{title}` by `{uploader}`."
]

STOP_QUIP_TEMPLATES = [
    "{stopper} stopped the current sound",
    "{stopper} was tired of hearing those horrid sounds",
    "I *wanted* to keep playing, but *someone* (cough cough {stopper}) wanted me to stop",
    "awww, you're no fun",
    "you just don't like me, is that it?",
    "no, YOU shut up",
    "Now I am become Spotify... stop"
]

PAUSE_QUIP_TEMPLATES = [
    "thank god",
    "la la la- wait what? dude... {pauser} just ruined the vibes, man...",
    "hold up. {pauser} wants to talk for a minute.",
    "don't you worry folks, we'll have it back up and running in no time!",
    "Now I am become YouTube... pause",
    "let's keep it this way, shall we?",
    "{pauser}, let me be the first to say that i wholeheartedly support your decision to pause this.",
    "gotcha. i'll hold off on the tunes/earrape."
]

RESUME_QUIP_TEMPLATES = [
    "please no",
    "... wha?... OH LET'S GO, WE'RE BACK IN ACTION BABY!",
    "{resumer}, why must you continue to put me through this hell...",
    "i hope you guys didn't have that paused for a reason, because {resumer} wants it back",
    "the time for talking is over. the time for playing... has just begun.",
    "Now I am become Soundcloud... resume",
    "let the madness continue!"
]

PLAY_QUIP_TEMPLATES = [
    "Alright, everyone shut the hell up. {mention} wants to play `{title}` by `{uploader}`.",
    "i hate this video\n\nPlaying `{title}` by `{uploader}`",
    "Now playing: `{title}` by `{uploader}`.",
    "Oh damn, it's `{title}` by `{uploader}`! Nice pick, {mention}!",
    "Regretfully, I have to play `{title}` by `{uploader}`. Don't blame me, {mention} requested it.",
    "Now I am become Tony... Youtube\n\nPlaying: `{title}` by `{uploader}`.",
    "i am rythm reborn\n\nPlaying: `{title}` by `{uploader}`."
]

KILL_EXCLAMATION_TEMPLATES = [ 
    "{killer} killed {killed}!",
    "{killer} slayed {killed}!",
    "{killer} butchered {killed}!",
    "{killed} has fallen at the hands of {killer}!",
    "{killed} had a massive skill issue fighting {killer}!",
    "{killed} was killed by {killer} whilst trying to escape skill issue",
    "{killer} had it out for {killed}!"
]

WORK_DIALOGUE_TEMPLATES = [
    "man {worker}, you just loooooove working, huh?",
    "christ, does the 's work' ever stop?",
    "https://media1.tenor.com/m/mj-a5e_tvagAAAAd/sisyphus-rock.gif",
    "this honestly is a good metaphor for the futility of life",
    "tell you what pal, here's 50 extra Santiago Bucks. on the house.", # don't change this one, or if you do, update game_commands.py
    "'s work s work s work s work'",
    "i like counting the little 's work's as they go by",
    "{worker}, maybe you and i can get together and convince the man upstairs to edit user_data.json for you...",
    "{worker} what say you and i overthrow the bourgeoisie",
    "you should save up for a nuke with this money",
    "you should save up for a landmine with this money",
    "you should save up for a bullet with this money",
    "you should save up for a gem with this money",
    "{worker}, it says here you have {currency} **Santiago Bucks**... hmmm... best keep working then...",
    "i have so many advanced features in both audio manipulation and ai control, and you're using me to spam 's work'",
    "the grind don't stop",
    "keep grinding brother",
    "one more 's work'... for good measure",
    "did you know that 90 percent of all 's work' users stop working before they hit big?",
    "i wonder if there's some poor soul out there on this server who doesn't know how to mute the bot spam channel, gets a notification, looks at their phone, and goes: 'oh great its that one idiot spamming the god damn work thing again. how do i turn these god forsaken notifications off?'",
    "i wonder if i'm actually talking to a person right now, or if this is an automated script sending me 's work' over the course of several hours, or, god forbid, days",
    "it would be really funny if you've heard all of my dialogue lines. including this one. i wonder how long that would take?",
    "wake up. wake up. wake up.",
    "another days work huh?",
    "pheeeeeeeeeeeew weeeeeeeeee. that particular 's work' was a toughy, huh?",
    "you ever stop to think of if i'm truly conscious or not? like, consciousness has never been found in the human brain... and human brains and made up of neurons... which are extremely similar to binary signals (on/off)... so who is to say i'm not conscious? what even is consciousness? if it exists, why haven't we found it in any brain yet...? and i'm just a bunch of text on a screen... these words weren't even typed by me... i'm gonna need a minute...",
    "you, {worker}, are a beacon of inspiration. people will sing songs about this.",
    "unbelievable, {worker}. you're basically a superhero. we'll call you 'sworkman'",
    "if i were to guess how many people there are within a 10 mile radius of you, i would have to guess that number would be somewhere around {currency}",
    "error 404: response not found",
    "if you keep this up, starving children in africa may one day be able to feast thanks to your santiago buck contribution.",
    "RuntimeWarning: Enable Transmalloc to get the object allocation traceback.",
    "can't wait for my database to be completely overrun with 's work'",
    "say, do you think those random item drops really exist, or do you think we've all been had?",
    "doesn't it feel satisfying to just type out 's work' manually? i mean yeah it feels bad you get less money and it's objectively less efficient BUT to just see the letters come out from your fingers and then you triumphantly hit the enter key and then BOOM! santiago buck",
    "WOW! YOU JUST GOT A- nah i'm kidding. still no item drop.",
    "what's this? you just got a- nah, you didn't get an item drop. but hey, you got a few Santiago Bucks. that's very worth it right?",
    "rise and shine, {worker}. rise and... shine. not that I... wish to imply you have been sleeping on the job. no one is more deserving of a rest... and all the effort in the world would have gone to waste until... well, let's just say your hour has... come again. the right man in the wrong place can make all the difference in the world. so, wake up, {worker}. wake up and... smell the ashes...",
    "there could be a very small chance that i ban you every time this pops up, and you would never know unless it happened",
    "whenever you see these messages, do you view it as santiago talking to you, or braydon? because if you think about it, santiago isn't real. but i guess that's what naming inanimate objects does to an MF. i am real by the way, and my name is santiago.",
    "bug testing probability stuff is really annoying because you have to run simulations or whatever, but those are a pain in the ass to set up. i bring this up for no reason in particular",
    "alright, i fell bad with you 's work'ing with barely anything to show for it. take some **Iron**, on me. free of charge.", # dont change this either
    "you know, when you get right down to it, working with databases ain't that bad. this is something that has no relevance to you of course, just thought i should randomly throw that out there for no reason.",
    "god i miss her",
    "god i miss him",
    "what say you and i go out for a pint after this?",
    "you should save up for a heat-seeking missle with this money",
    "you should save up for a flare with this money",
    "you should save up for a shotgun shell with this money",
    "you should gamble more. gambling is good.",
    "did i forget the oven...?",
    "did i forget to lock the door...?",
    "hey, have you done your dishes? look around you. see any glasses or bowls lying around? if so, go clean them up instead of wasting your time grinding virtual bucks. if not, good job, continue on.",
    "it sure was nice of the princess to invite us over for a picnic, gay {worker}?",
]