import discord

from discord import app_commands
from discord.ext import commands

# set up configuration variables, including secret keys and loggers
from src.config import *

# import all of the actual commands so this stuff works. stuff below just sets up the slash commands in discord, these files hold the logic
from src.commands.vc_commands import *
from src.commands.ai_commands import *
from src.commands.yt_commands import *
from src.commands.text_commands import *
from src.logging_config import *


#TODO: make settings server specific (hard and will take a while so save this for a long time from now)


##########################################################################################
#                                    Event Commands                                      #
##########################################################################################



# runs on startup
@bot.event
async def on_ready():
  try: 
    #this line here is extremely important: it's the thing that actually lets you use slash commands
    synced = await bot.tree.sync()
    print(f"Synced {len(synced)} commands")
  except Exception as e:
    print(e)


@bot.command(name="")
async def hello(ctx):
    await ctx.send('hi i just wanted to let you know that your message started with a lone s okay thats all bye (tell braydon if you got this)')


# runs on errors
@bot.event 
async def on_command_error(ctx, error):
    if isinstance(error, commands.CommandNotFound):
        return
    else:
        print(f"Error occurred: {error}")


# runs whenever a message is sent
@bot.event
async def on_message(message):

    if random.randint(1, 100000) == 1:
        await message.reply("IT HAPPENED! This message had a 1 in 100000 chance of triggering. "
                            "You know it's serious when I'm talking in all caps. I don't even know "
                            "if anyone sees or cares about this message but god damn, this was *very* "
                            "unlikely to have actually occurred. Consider treating yourself today or something.")
    
    # this method is in ai_commands.py. it logs the message to the history for the ai, and responds if the criteria is met
    if await ai_message_logging_and_response(message):
        await log_text_command(message, "santiago")

    # this prevents him from getting in a feedback loop with himself
    if message.author == bot.user:
        return
    
    if bot.user.mentioned_in(message):
        await message.channel.send('https://media1.tenor.com/m/fZDk8YeVc0kAAAAd/annoying-who-pinged-me.gif')
    
    # all text based commands will be below here

    # text_commands
    if await check_and_upload_ascii(message):
        await log_text_command(message, "asciify (image)")
    
    if await convert_to_pdf(message):
        await log_text_command(message, "pdf")

    # yt_commands
    if await transcribe_yt_audio(message):
        await log_text_command(message, "youtube transcription")

        
    await bot.process_commands(message)


# runs on message deletions
@bot.event
async def on_message_delete(message):
    await log_deleted_message(message)


# runs on message edits
@bot.event
async def on_message_edit(message_before, message_after):
    if message_before.content != message_after.content and not message_before.author.bot:
        await log_edited_message(message_before, message_after)


# runs on slash commands
@bot.event
async def on_app_command_completion(interaction, command):
    await log_app_command_usage(interaction, command)



##########################################################################################
#                          Text Commands (text_commands.py)                              #
##########################################################################################



@bot.tree.command(name="help", description="shows a list of all current commands")
async def help_command(interaction: discord.Interaction):
    await create_help_embed(interaction)

@bot.tree.command(name="ping", description="use this if you really need to get someone's attention")
@app_commands.describe(person_to_ping = "Who should I ping?")
async def ping_command(interaction: discord.Interaction, person_to_ping: discord.Member):
    await ping_spam(interaction, person_to_ping)

@bot.tree.command(name="mock", description="what an idiot")
@app_commands.describe(person_to_mock = "Who should I mock?")
async def mock_command(interaction: discord.Interaction, person_to_mock: discord.Member):
    await mock_user(interaction, person_to_mock)

@bot.tree.command(name="kill", description="kill someone")
@app_commands.describe(person_to_kill = "Whose blood shall be spilt?")
async def kill_command(interaction: discord.Interaction, person_to_kill: discord.Member):
    await kill_user(interaction, person_to_kill)

@bot.tree.command(name="suicide", description="your life literally is as valuable as a summer ant")
async def suicide_command(interaction: discord.Interaction):    
    await suicide(interaction)

@bot.tree.command(name="ant_colony", description="ant colony")
async def ant_colony_command(interaction: discord.Interaction):    
    await ant_colony_spam(interaction)

@bot.tree.command(name="asciify", description="turns text into ascii")
@app_commands.describe(text_prompt = "Enter text")
@app_commands.choices(style=[app_commands.Choice(name="simple", value="4x4_offr"), app_commands.Choice(name="hollow", value="big"), 
                             app_commands.Choice(name="lines", value="cyberlarge"), app_commands.Choice(name="3d-simple", value="banner3-d"), 
                             app_commands.Choice(name="dudes", value="dancingfont"), app_commands.Choice(name="ye olden", value="fraktur"),
                             app_commands.Choice(name="3d-complex", value="isometric1"), app_commands.Choice(name="japanese", value="katakana"),
                             app_commands.Choice(name="tarty", value="tarty1"), app_commands.Choice(name="checkerboard", value="tarty9"),
                             app_commands.Choice(name="clean", value="univers"),])
async def asciify_command(interaction: discord.Interaction, text_prompt: str, style: str):   
    await asciify(interaction, text_prompt, style)

@bot.tree.command(name="dbd-randomizer", description="randomize yourself a dbd loadout")
@app_commands.choices(role=[app_commands.Choice(name="Survivor", value="s"), app_commands.Choice(name="Killer", value="k")])
async def dbd_randomizer_command(interaction: discord.Interaction, role: str):   
    await dbd_randomizer(interaction, role)

@bot.tree.command(name="rng", description="generate a random number from 1 to whatever number you enter")
@app_commands.describe(to_what = "What number are you generating to?")
@app_commands.describe(how_many = "How many would you like to generate?")
async def generate_random_number_command(interaction: discord.Interaction, to_what: app_commands.Range[int, 2, 1000000], how_many: app_commands.Range[int, 1, 100]):   
    await generate_random_numbers(interaction, to_what, how_many)

@bot.tree.command(name="wikipedia", description="look up something on wikipedia")
@app_commands.describe(wiki_search = "What would you like to search for?")
async def wikipedia_command(interaction: discord.Interaction, wiki_search: str):    
    await search_wikipedia(interaction, wiki_search)

@bot.tree.command(name="bible", description="reads a random bible verse")
async def bible_command(interaction: discord.Interaction):    
    await get_bible_verse(interaction)

@bot.tree.command(name="define", description="define a word")
@app_commands.describe(word = "What word would you like to define?")
async def define_command(interaction: discord.Interaction, word: str):    
    await get_definition(interaction, word)

##########################################################################################
#                        VC and Audio Commands (vc_commands.py)                          #
##########################################################################################



@bot.tree.command(name="join_call", description="hi")
async def join_call_command(interaction: discord.Interaction): 
    vc = await join_call(interaction)
    if vc != None:
        await interaction.response.send_message("hi")

@bot.tree.command(name="leave_call", description="leaves the current vc")
async def leave_call_command(interaction: discord.Interaction):
    await leave_call(interaction)

@bot.tree.command(name="set_volume", description="Sets a volume multiplier for all future sounds Santiago plays")
async def set_volume_command(interaction: discord.Interaction):
    await interaction.response.send_modal(VolumePromptModal())

@bot.tree.command(name="pause_or_resume", description="Pauses or resumes the current sound")
async def toggle_pause_command(interaction: discord.Interaction):
    await toggle_pause_state(interaction)

@bot.tree.command(name="stop_sound", description="stops any sound currently playing")
async def stop_sound_command(interaction: discord.Interaction):
    await stop_sound(interaction)

@bot.tree.command(name="oblivion_moment", description="Use when the vc really feels like TES_IV")
async def oblivion_command(interaction: discord.Interaction):
    await play_oblivion_music(interaction)

@bot.tree.command(name="ltg_speech", description="Use when someone in VC starts acting a little too sussy for your tastes")
@app_commands.describe(person_to_ltg = "Alright, who deserves this one?")
async def ltg_command(interaction: discord.Interaction, person_to_ltg: discord.Member):
    await play_ltg_speech(interaction, person_to_ltg)

@bot.tree.command(name="clown", description="Use when someone in VC needs to be revealed for the clown they are")
@app_commands.describe(person_to_clown = "Alright, who deserves this one?")
async def clown_command(interaction: discord.Interaction, person_to_clown: discord.Member):
    await play_clown_sound(interaction, person_to_clown)

@bot.tree.command(name="gigachad", description="Use when someone in VC is truly a sigma")
@app_commands.describe(person_to_giga = "Alright, who deserves this one?")
async def gigachad_command(interaction: discord.Interaction, person_to_giga: discord.Member):
    await play_gigachad_music(interaction, person_to_giga)
    


##########################################################################################
#                      Youtube and Queue Commands (yt-commands.py)                       #
##########################################################################################



@bot.tree.command(name="youtube-play", description="play any youtube video's audio")
@app_commands.describe(video="Please enter a valid YouTube video title or provide a valid URL")
async def youtube_play_command(interaction: discord.Interaction, video: str):
    await youtube_play(interaction, video)

@bot.tree.command(name="clear_queue", description="clears the current video queue in the server")
async def clear_queue_command(interaction: discord.Interaction):
    await clear_queue(interaction)

@bot.tree.command(name="view_queue", description="check what videos are queued up to play")
async def view_queue_command(interaction: discord.Interaction):
    guild_id = interaction.guild.id
    if guild_id in video_queue and len(video_queue[guild_id]) > 0:
        await interaction.response.send_message("here you go:")
        await send_view_queue(interaction)
    else:
        await interaction.response.send_message("No one has anything queued... you could be the first.", ephemeral=True)

@bot.tree.command(name="toggle_loop", description="will loop or stop looping the youtube video currently playing or next to play")
async def toggle_loop_command(interaction: discord.Interaction):
    await toggle_loop(interaction)

@bot.tree.command(name="remove_from_queue", description="Remove a song from the queue")
async def remove_from_queue_command(interaction: discord.Interaction):
    await remove_video_from_queue(interaction)

@bot.tree.command(name="skip_to", description="skips to a specific song in the queue")
async def skip_to_command(interaction: discord.Interaction):
    await skip_queue_to(interaction)



##########################################################################################
#                             AI Commands (ai_commands.py)                               #
##########################################################################################



@bot.tree.command(name="talk", description="have santiago talk to you in vc")
@app_commands.describe(user_message="what do you want to say to santiago?")
async def talk_command(interaction: discord.Interaction, user_message: str):
    await generate_text_and_audio(interaction, user_message)

@bot.tree.command(name="gpt_model", description="switch the chat model between 'gpt-3.5' and 'gpt-4'")
@app_commands.choices(model=[app_commands.Choice(name="gpt-4o", value="gpt-4o"), app_commands.Choice(name="gpt-4o-mini", value="gpt-4o-mini")])
async def set_gpt_model_command(interaction: discord.Interaction, model: str):
    await set_gpt_model(interaction, model)

@bot.tree.command(name="speak", description="make santiago say something in vc in a custom voice")
@app_commands.describe(what_to_say = "What should I say?")
@app_commands.choices(voice=[app_commands.Choice(name="braydon", value=VOICE_MAP["braydon"]), app_commands.Choice(name="wil", value=VOICE_MAP["wil"]),
                             app_commands.Choice(name="cyclops", value=VOICE_MAP["cyclops"]), app_commands.Choice(name="scorch (titanfall)", value=VOICE_MAP["scorch"]),
                             app_commands.Choice(name="vinny mario", value=VOICE_MAP["vinny mario"]), app_commands.Choice(name="phone guy", value=VOICE_MAP["phone guy"]),
                             app_commands.Choice(name="josh", value=VOICE_MAP["josh"]), app_commands.Choice(name="akechi", value=VOICE_MAP["akechi"]),])
async def speak_command(interaction: discord.Interaction, voice: str, what_to_say: str):
    await speak(interaction, what_to_say, voice)

@bot.tree.command(name="toggle_chat_replies", description="turns santiago's ai responses in chat on or off")
async def toggle_chat_replies_command(interaction: discord.Interaction):   
    await toggle_ai_chat_replies(interaction)

@bot.tree.command(name="record_and_respond", description="listens to your voice and responds to you")
@app_commands.describe(how_long = "How many seconds (between 3-20) would you like to talk to me?")
async def respond_to_user_voice_command(interaction: discord.Interaction, how_long: app_commands.Range[int, 3, 30]):   
    await record_user_voice_and_respond(interaction, how_long)

@bot.tree.command(name="fast_record_and_respond", description="listens to your voice and responds to you, defaults for 10 seconds")
async def fast_respond_to_user_voice_command(interaction: discord.Interaction):   
    await record_user_voice_and_respond(interaction, 10)

@bot.tree.command(name="transcribe", description="transcribes your voice into text")
@app_commands.describe(how_long = "How many seconds (between 3-20) would you like to speak?")
async def transcribe_command(interaction: discord.Interaction, how_long: app_commands.Range[int, 3, 30]):   
    await transcribe(interaction, how_long)







#guess what this does.
bot.run(BOT_TOKEN)

