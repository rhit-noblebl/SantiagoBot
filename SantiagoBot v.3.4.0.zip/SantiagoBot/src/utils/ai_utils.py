import sqlite3

from src.config.database_config import *

MAX_HISTORY_LENGTH = 2500



def fetch_message_history(guild_id, max_history_length):
    conn = sqlite3.connect(DATABASE_PATH)
    cursor = conn.cursor()

    # Fetch the most recent messages up to MAX_HISTORY_LENGTH
    cursor.execute('''
    SELECT role, content FROM ai_message_history
    WHERE guild_id = ?
    ORDER BY timestamp ASC
    LIMIT ?
    ''', (guild_id, max_history_length))

    rows = cursor.fetchall()

    conn.close()
    return rows


def build_full_context(guild_id, startup_prompt, max_history_length):
    # Fetch message history from the database
    ai_message_history = fetch_message_history(guild_id, max_history_length)

    # Construct the context for the AI
    full_context = [{"role": "system", "content": startup_prompt}] + [
        {"role": msg[0], "content": msg[1]} for msg in ai_message_history
    ]
    
    return full_context


async def add_message_to_history(guild_id: int, role: str, content: str):
    conn = sqlite3.connect(DATABASE_PATH)
    cursor = conn.cursor()
    cursor.execute('''
        INSERT INTO ai_message_history (guild_id, role, content)
        VALUES (?, ?, ?)
        ''', (guild_id, role, content))
    
    # if it exceeds max history length, fix that
    cursor.execute('''
        SELECT COUNT(*) FROM ai_message_history
        WHERE guild_id = ?
    ''', (guild_id,))
    count = cursor.fetchone()[0]

    if count >= MAX_HISTORY_LENGTH:
        # Delete the oldest entry for the specified guild
        cursor.execute('''
            DELETE FROM ai_message_history
            WHERE id IN (
                SELECT id
                FROM ai_message_history
                WHERE guild_id = ?
                ORDER BY timestamp ASC
                LIMIT 1
            )
        ''', (guild_id,))
        print(f"{guild_id} has reached it's memory limit.")


    conn.commit()
    conn.close()
    

async def format_transcription(text, line_length):
    lines = [text[i:i + line_length] for i in range(0, len(text), line_length)]
    return "\n".join(lines)


