how to set up santiago:

1. make sure python is added to your path with vs code and everything

2. run pip -r requirements.txt

3. make sure you have a proper virtual environment set up (god i fucking hate how long that took to fix jesus christ)

4. make sure you have ffmpeg set up, then specify its path in the code with all the things that play sound. 

5. also set computer environmental variables for all of the keys