import discord
import asyncio

from discord.ext import voice_recv
from elevenlabs import Voice, VoiceSettings, save
from pydub import AudioSegment

from src.config.main_config import OpenAIClient, ElevenLabsClient, bot
from src.data.ai_prompts import *
from src.utils.vc_utils import join_and_play_sound
from src.utils.ai_utils import *
from src.utils.generic_utils import get_gpt_model, get_chat_replies_enabled, set_gpt_model, set_chat_replies_enabled, truncate_message, upsert_guild_settings



#call this to generate text based on the last message sent, passing in who wrote it for startup_prompt context
async def generate_text(user):
    startup_prompt = SANTIAGO_STARTUP_PROMPT

    if user.id == 426867397400592424:
        startup_prompt = FATHER_PROMPT

    # Fetch the message history from the database
    ai_message_history = fetch_message_history(user.guild.id, MAX_HISTORY_LENGTH)
    
    ## for debugging
    # print(ai_message_history)

    full_context = [{"role": "system", "content": startup_prompt}] + [
        {"role": msg[0], "content": msg[1]} for msg in ai_message_history
    ]

    chat_completion_response = OpenAIClient.chat.completions.create(
        model=get_gpt_model(user.guild.id),
        messages=full_context,
        stream=False
    )

    response = chat_completion_response.choices[0].message.content

    return truncate_message(response)


#generates audio based on the passed prompt
async def generate_audio(prompt, voice):
    speech_file_path = "src/data/sound_files/speech.mp3"

    response = ElevenLabsClient.generate(
        text=prompt,
        voice=Voice(
            voice_id=voice,
            settings=VoiceSettings(stability=0.71, similarity_boost=0.5, style=0.0, use_speaker_boost=True),
            model="eleven_multilingual_v1"
        )
    )

    # saves the speech to the mp3
    save(response, speech_file_path)


    # --IMPORTANT--
    # this is OPEN AI voice synthesis if ElevenLabs stops working for whatever reason
    #
    # voice_response = OpenAIClient.audio.speech.create(
    #     model="tts-1",
    #     voice="onyx",
    #     input=prompt
    # )
    #
    # voice_response.stream_to_file(speech_file_path)


async def generate_text_and_audio(interaction: discord.Interaction, user_message: str):
    await add_message_to_history(interaction.guild.id, "user", str(interaction.user.display_name) + ": " + user_message)
    await interaction.response.defer() 

    voice_state = interaction.user.voice
    if voice_state is None:
        await interaction.followup.send("to use this command, get into a call. alternatively, if you just want to talk to me outside of vc, put 'santiago' somewhere in your message.", ephemeral=True)
        return

    user_voice_channel = interaction.user.voice.channel
    if user_voice_channel is not None:
        

        #generates the text response
        text_response = await generate_text(interaction.user)

        #generates the audio file
        await generate_audio(text_response, VOICE_MAP["braydon"])

        #joins call
        await join_and_play_sound(user_voice_channel, "src/data/sound_files/speech.mp3", 2)
        await interaction.followup.send(text_response)

        #append both the users input and ai response to the history
        await add_message_to_history(interaction.guild.id, "assistant", text_response)
    else:
        await interaction.followup.send(f"you're not in a valid voice channel.", ephemeral=True)


async def set_gpt_model_manually(interaction: discord.Interaction, model: str):
    set_gpt_model(interaction.guild.id, model)
    current_model = model
    if current_model == "gpt-4o-mini":
        await interaction.response.send_message("i are no longer brain")
    elif current_model == "gpt-4o":
        await interaction.response.send_message("brain")


async def toggle_ai_chat_replies(interaction: discord.Interaction):
    if get_chat_replies_enabled(interaction.guild.id):
        await interaction.response.send_message("ill stop blabbering. its really annoying.")
    else:
        await interaction.response.send_message("...can i come out of the quiet corner now? :(")
    set_chat_replies_enabled(interaction.guild.id, not get_chat_replies_enabled(interaction.guild.id))


async def narrate(interaction: discord.Interaction, text_prompt: str, voice: str):

    await interaction.response.defer() 

    user_voice_channel = interaction.user.voice.channel
    if user_voice_channel is not None:
        
        #generates the audio file
        await generate_audio(text_prompt, voice)

        #joins call
        await join_and_play_sound(user_voice_channel, "src/data/sound_files/speech.mp3", 2)
        await interaction.followup.send(text_prompt)

    else:
        await interaction.followup.send(f"you're not in a valid voice channel.", ephemeral=True)


# called in on_message in main.py, this does what it says on the tin
async def ai_message_logging_and_response(message: discord.Message):
    if not message.content or message.guild is None or message.content == "s work" or message.content == "s w":
        return

    guild_id = message.guild.id
    role = "assistant" if message.author == bot.user else "user"
    content = message.content if message.author == bot.user else f"{message.author.display_name}: {message.content}"

    await add_message_to_history(guild_id, role, content)

    if not get_chat_replies_enabled(message.guild.id) or message.author == bot.user:
        return
    else:
        if message.content.lower() == "santiago":
            await message.reply("if the word 'santiago' is present in any message you send, ill talk to you")
            return True
        elif "santiago" in message.content.lower():
            response = await generate_text(message.author)
            await message.reply(response)
            return True
    


# this is the code that writes noises in VC to the user_speech.mp3 sound file
# important thing to note: this uses a different vc.connect than the base one, so it's important to disconnect it at the end. otherwise,
# it breaks other commands. keep that in mind when designing or editing this thing. 
async def record_user_voice(interaction: discord.Interaction, seconds: int):

    if not interaction.user.voice:
        await interaction.response.send_message("i can't record you if you're not in a vc.")
        return

    vc = interaction.guild.voice_client
    if vc:
        await vc.disconnect(force=True)

    audio_data = bytearray()

    def callback(user, packet: voice_recv.VoiceData):
        if packet.pcm:  # If PCM data is available, use it
            audio_data.extend(packet.pcm)
        else:  # Otherwise, use Opus data
            audio_data.extend(packet.opus)  # Correctly access the raw Opus audio data


    # Connect to the voice channel
    vc = await interaction.user.voice.channel.connect(cls=voice_recv.VoiceRecvClient)

    # Start listening and recording
    vc.listen(voice_recv.BasicSink(callback))

    # Record for however many seconds
    await asyncio.sleep(seconds)

    # Convert and save the audio data as an MP3 file
    audio_segment = AudioSegment(
        data=bytes(audio_data),
        sample_width=2,  # Assuming 16-bit samples
        frame_rate=100000,  # Standard Discord voice channel sample rate
        channels=1  # Mono audio
    )

    user_speech_file_path = "src/data/sound_files/user_speech.mp3"
    audio_segment.export(user_speech_file_path, format="mp3")  # Export directly to MP3 file

    await vc.disconnect(force=True)


async def record_user_voice_and_respond(interaction: discord.Interaction, seconds: int):

    await interaction.response.defer()
    await record_user_voice(interaction, seconds)

    user_speech_file_path = "src/data/sound_files/user_speech.mp3"
    audio_file = open(user_speech_file_path, "rb")
    transcript = OpenAIClient.audio.transcriptions.create(
        model="whisper-1",
        file=audio_file
    )

    print(transcript.text)

    await add_message_to_history(interaction.guild.id, "user", str(interaction.user.display_name) + ": " + transcript.text)

    voice_state = interaction.user.voice
    if voice_state is None:
        await interaction.followup.send("to use this command, get into a call. alternatively, if you just want to talk to me outside of vc, put 'santiago' somewhere in your message.", ephemeral=True)
        return

    user_voice_channel = interaction.user.voice.channel
    if user_voice_channel is not None:
        
        #generates the text response
        text_response = await generate_text(interaction.user)

        #generates the audio file
        await generate_audio(text_response, VOICE_MAP["braydon"])

        await join_and_play_sound(user_voice_channel, "src/data/sound_files/speech.mp3", 2)
        await interaction.followup.send(text_response)
        
        await add_message_to_history(interaction.guild.id, "assistant", text_response)

    else:
        await interaction.followup.send(f"you're not in a valid voice channel.", ephemeral=True)


async def transcribe(interaction: discord.Interaction, seconds: int):
    await interaction.response.defer()

    await record_user_voice(interaction, seconds)

    user_speech_file_path = "src/data/sound_files/user_speech.mp3"
    audio_file = open(user_speech_file_path, "rb")
    transcript = OpenAIClient.audio.transcriptions.create(
        model="whisper-1",
        file=audio_file
    )

    await add_message_to_history(interaction.guild.id, "user", str(interaction.user.display_name) + ": " + transcript.text + " Please transcribe this text, Santiago.")
    add_message_to_history(interaction.guild.id, "assistant", "you just said: " + transcript.text)

    await interaction.followup.send("you just said: \n\n" + transcript.text)


async def transcribe_file(file_path):
    transcript = OpenAIClient.audio.transcriptions.create(
        model="whisper-1",
        file=file_path
    )

    final_transcription = await format_transcription(transcript.text, 80)

    return final_transcription


async def wipe_memory(interaction: discord.Interaction):
    conn = sqlite3.connect(DATABASE_PATH)
    cursor = conn.cursor()

    cursor.execute('''
    DELETE FROM ai_message_history WHERE guild_id = ?
    ''', (interaction.guild.id,))
    
    conn.commit()
    conn.close()
    await interaction.response.send_message("https://qph.cf2.quoracdn.net/main-qimg-8714818b115bc0d0307659a2a84da6e8")


async def reset_to_server_default(interaction: discord.Interaction):
    conn = sqlite3.connect(DATABASE_PATH)
    cursor = conn.cursor()
    
    cursor.execute('''
    DELETE FROM ai_message_history WHERE guild_id = ?
    ''', (interaction.guild.id,))
    cursor.execute('''
    DELETE FROM video_queue WHERE guild_id = ?
    ''', (interaction.guild.id,))
    
    conn.commit()
    conn.close()
    upsert_guild_settings(interaction.guild.id)

    await interaction.response.send_message("https://media1.tenor.com/m/AHXAi-8kG00AAAAC/please-i-dont-want.gif")
