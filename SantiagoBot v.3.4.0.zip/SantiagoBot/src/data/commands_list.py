TEXT_COMMANDS = [
    "/ping",
    "/kill",
    "/suicide",
    "/dbd-randomizer",
    "/asciify (for text)",
    "s asciify (for images)",
    "/rng",
    "/wikipedia",
    "/bible",
    "/define",
    "s pdf",
]

VC_AND_AUDIO_COMMANDS = [
    "/stop_sound",
    "/oblivion_moment",
    "/ltg_speech",
    "/clown",
    "/gigachad",
    "/russian_roulette",
    "/shoot",
    "/blind_fire",
    "/nuke",
    "/landmine",
    "/missile_target",
    "/emergency_evac",
    "/shotgun_blast",
    "/jammer_deploy",
    "/flashbang",
    "/emp",
    "warp_cast"
]

YOUTUBE_COMMANDS = [
    "/yt-play",
    "/pause_or_resume",
    "/clear_queue",
    "/view_queue",
    "/remove_from_queue",
    "/skip_to",
]

AI_COMMANDS = [
    "s yttranscribe",
    "/talk",
    "/narrate",
    "/record_and_respond",
    "/fast_record_and_respond",
    "/transcribe",
]

GAME_COMMANDS = [
    "s work",
    "s currency",
    "/gamble",
    "/buy_items",
    "/sell_items",
    "/give_items",
    "/craft_items",
    "s inventory",
]

CONFIG_COMMANDS = [
    "/join_call",
    "/leave_call",
    "/set_volume",
    "/gpt_model",
    "/toggle_loop",
    "/toggle_chat_replies",
    "/wipe_memory",
    "/reset_to_server_default"
]

