import discord

from discord import app_commands
from discord.ext import commands

# set up configuration variables, including secret keys and loggers
from src.config.main_config import *
from src.config.logging_config import *
from src.config.database_config import *

# import all of the actual commands so this stuff works. stuff below just sets up the slash commands in discord, these files hold the logic
from src.commands.vc_commands import *
from src.commands.ai_commands import *
from src.commands.yt_commands import *
from src.commands.slash_commands import *
from src.commands.game_commands import *

from src.utils.generic_utils import increment_slash_commands_used
from src.utils.inventory_utils import Item



# idea: permanent upgrades (s work (maybe partially automate?), s inv)
#TODO: make 's craft' actually make an embed

##########################################################################################
#                                    Event Commands                                      #
##########################################################################################


@bot.event
async def on_ready():
  try: 
    synced = await bot.tree.sync()

    await bot.add_cog(Utility_Commands(bot))
    await bot.add_cog(Game_Commands(bot))
    await bot.add_cog(Media_Commands(bot))
    await bot.add_cog(Admin_Commands(bot))

    await populate_db(bot)

    print(f"Synced {len(synced)} commands")

  except Exception as e:
    print(e)


@bot.event 
async def on_command_error(ctx, error):
    if isinstance(error, commands.CommandNotFound):
        return
    else:
        print(f"Error occurred: {error}")


@bot.event
async def on_message(message):

    # this method is in ai_commands.py. it logs the message to the history for the ai, and responds if the criteria is met
    await ai_message_logging_and_response(message)

    if not message.author.bot: 
        await game_events_check_and_log(message)

    # this prevents him from getting in a feedback loop with himself
    if message.author == bot.user:
        return
        
    await bot.process_commands(message)


@bot.event
async def on_message_delete(message):
    if not message.author.bot and message.content.lower() not in ["s w", "s work"]:
        await log_deleted_message(message)
        


@bot.event
async def on_message_edit(message_before, message_after):
    if message_before.content != message_after.content and not message_before.author.bot:
        await log_edited_message(message_before, message_after)


@bot.event
async def on_app_command_completion(interaction, command):
    await update_user_currency(interaction.user.id, 5)
    await increment_slash_commands_used(interaction.user.id)
    await log_app_command_usage(interaction, command)


@bot.event
async def on_voice_state_update(user, voice_before, voice_after):
    await log_voice_state_updates(user, voice_before, voice_after)



##########################################################################################
#                                   Prefix Commands                                      #
##########################################################################################


@bot.command(name="hello", help="this is a command i use for debugging mostly. but hey, if you use it, he'll say hi to you")
async def hello(ctx):
    await ctx.send('hi')


class Utility_Commands(commands.Cog, name="Utility Commands"):
    def __init__(self, bot):
        self.bot = bot

    @commands.command(name="pdf", help="Upload images with this command, and Santiago will convert them to PDFs.")
    async def pdf_command(self, ctx):
        await convert_to_pdf(ctx.message)
        await log_text_command(ctx.message, "pdf")

    @commands.command(name="asciify", help="Upload images with this command, and Santiago will convert it into an ASCII rendition.")
    async def asciify_image_command(self, ctx):
        await asciify_image(ctx.message)
        await log_text_command(ctx.message, "asciify")
        

class Game_Commands(commands.Cog, name="Game Commands"):
    def __init__(self, bot):
        self.bot = bot

    @commands.command(name="work", aliases=["w"], help="Type this to earn 10 Santiago Bucks. Try not to spam important channels, or use DMs.")
    async def work_command(self, ctx):
        await work(ctx)

    @commands.command(name="currency", aliases=["money", "bucks"], help="Use to display your current Santiago Buck balance.")
    async def view_currency_command(self, ctx):
        await view_currency(ctx)
        await log_text_command(ctx.message, "view currency")

    @commands.command(name="inventory", aliases=["inv"], help="Use this to view your Santiago inventory. You can buy items with /buy if you can afford them with Santiago Bucks.")
    async def view_inventory_command(self, ctx):
        await view_inventory(ctx)
        await log_text_command(ctx.message, "view inventory")

    @commands.command(name="leaderboard", aliases=["lb"], help="Use this to view the Santiago leaderboard for the server. Ordered by how rich each person is, shows your position and the top 5")
    async def view_leaderboard_command(self, ctx):
        await view_leaderboard(ctx)
        await log_text_command(ctx.message, "view leaderboard")
    
    @commands.command(name="stats", aliases=["stat"], help="Use this to view some various statistics Santiago collects about the game")
    async def view_stats_command(self, ctx):
        await view_stats(ctx)
        await log_text_command(ctx.message, "view stats")
    
    @commands.command(name="crafting", aliases=["craft"], help="Use this to view crafting recipes")
    async def crafting_command(self, ctx):
        await crafting_table(ctx)
        await log_text_command(ctx.message, "crafting table")


class Media_Commands(commands.Cog, name="Media Commands"):
    def __init__(self, bot):
        self.bot = bot

    @commands.command(name="yttranscribe", help="Transcribes a YouTube video (note: this is relatively pricey, so only do a video >4 minutes only if you really need it)")
    async def yttranscribe_command(self, ctx):
        await transcribe_yt_audio(ctx.message)
        await log_text_command(ctx.message, "youtube transcription")


class Admin_Commands(commands.Cog, name="Admin Commands"):
    def __init__(self, bot):
        self.bot = bot

    @commands.command(name="import", help="lets me import data from my json into santiago's database")
    async def import_json_command(self, ctx):
        if ctx.author.id == 426867397400592424:
            import_user_data_from_json()
        else:
            await ctx.send("ah, ah, ah. braydon only.")

    @commands.command(name="export", help="lets me export data from santiago's database into json")
    async def export_json_command(self, ctx):
        if ctx.author.id == 426867397400592424:
            export_user_data_to_json()
        else:
            await ctx.send("ah, ah, ah. braydon only.")


##########################################################################################
#                    Non-Specific Slash Commands (slash_commands.py)                     #
##########################################################################################



@bot.tree.command(name="help", description="shows a list of all current commands")
async def help_command(interaction: discord.Interaction):
    await create_help_embed(interaction)

@bot.tree.command(name="ping", description="use this if you really need to get someone's attention")
@app_commands.describe(person_to_ping = "Who should I ping?")
async def ping_command(interaction: discord.Interaction, person_to_ping: discord.Member):
    await ping_spam(interaction, person_to_ping)

@bot.tree.command(name="kill", description="kill someone")
@app_commands.describe(person_to_kill = "Whose blood shall be spilt?")
async def kill_command(interaction: discord.Interaction, person_to_kill: discord.Member):
    await kill_user(interaction, person_to_kill)

@bot.tree.command(name="suicide", description="your life literally is as valuable as a summer ant")
async def suicide_command(interaction: discord.Interaction):    
    await suicide(interaction)

@bot.tree.command(name="ant_colony", description="ant colony")
async def ant_colony_command(interaction: discord.Interaction):    
    await ant_colony_spam(interaction)

@bot.tree.command(name="asciify", description="turns text into ascii")
@app_commands.describe(text_prompt = "Enter text")
@app_commands.choices(style=[app_commands.Choice(name="simple", value="4x4_offr"), app_commands.Choice(name="hollow", value="big"), 
                             app_commands.Choice(name="lines", value="cyberlarge"), app_commands.Choice(name="3d-simple", value="banner3-d"), 
                             app_commands.Choice(name="dudes", value="dancingfont"), app_commands.Choice(name="ye olden", value="fraktur"),
                             app_commands.Choice(name="3d-complex", value="isometric1"), app_commands.Choice(name="japanese", value="katakana"),
                             app_commands.Choice(name="tarty", value="tarty1"), app_commands.Choice(name="checkerboard", value="tarty9"),
                             app_commands.Choice(name="clean", value="univers"),])
async def asciify_command(interaction: discord.Interaction, text_prompt: str, style: str):   
    await asciify(interaction, text_prompt, style)

@bot.tree.command(name="dbd-randomizer", description="randomize yourself a dbd loadout")
@app_commands.choices(role=[app_commands.Choice(name="Survivor", value="s"), app_commands.Choice(name="Killer", value="k")])
async def dbd_randomizer_command(interaction: discord.Interaction, role: str):   
    await dbd_randomizer(interaction, role)

@bot.tree.command(name="rng", description="generate a random number from 1 to whatever number you enter")
@app_commands.describe(to_what = "What number are you generating to?")
@app_commands.describe(how_many = "How many would you like to generate?")
async def generate_random_number_command(interaction: discord.Interaction, to_what: app_commands.Range[int, 2, 1000000], how_many: app_commands.Range[int, 1, 100]):   
    await generate_random_numbers(interaction, to_what, how_many)

@bot.tree.command(name="wikipedia", description="look up something on wikipedia")
@app_commands.describe(wiki_search = "What would you like to search for?")
async def wikipedia_command(interaction: discord.Interaction, wiki_search: str):    
    await search_wikipedia(interaction, wiki_search)

@bot.tree.command(name="bible", description="reads a random bible verse")
async def bible_command(interaction: discord.Interaction):    
    await get_bible_verse(interaction)

@bot.tree.command(name="define", description="define a word")
@app_commands.describe(word = "What word would you like to define?")
async def define_command(interaction: discord.Interaction, word: str):    
    await get_definition(interaction, word)

@bot.tree.command(name="gamble", description="Guess the rolled number from 1-100. Within 10=1.5x, 5=4x, 1=50x")
@app_commands.describe(
    number_guess="Your guess (between 1 and 100)",
    currency_bet="Amount of currency to bet (between 10 and 2500)")
async def gamble_command(interaction: discord.Interaction, number_guess: app_commands.Range[int, 1, 100], currency_bet: app_commands.Range[int, 10, 2500]):
    await gamble(interaction, number_guess, currency_bet)

@bot.tree.command(name="buy_items", description="use santiago bucks (sb) to buy items")
@app_commands.choices(item_to_buy=[app_commands.Choice(name=f"Landmine ({Item.get_value(Item.LANDMINE)} SB)", value=Item.LANDMINE),
                                   app_commands.Choice(name=f"Bullet ({Item.get_value(Item.BULLET)} SB)", value=Item.BULLET), 
                                   app_commands.Choice(name=f"Shotgun Shell ({Item.get_value(Item.SHOTGUN_SHELL)} SB)", value=Item.SHOTGUN_SHELL),
                                   app_commands.Choice(name=f"Heat-Seeking Missile ({Item.get_value(Item.HEAT_SEEKING_MISSILE)} SB)", value=Item.HEAT_SEEKING_MISSILE),
                                   app_commands.Choice(name=f"Signal Jammer ({Item.get_value(Item.SIGNAL_JAMMER)} SB)", value=Item.SIGNAL_JAMMER),
                                   app_commands.Choice(name=f"Flashbang ({Item.get_value(Item.FLASHBANG)} SB)", value=Item.FLASHBANG),
                                   app_commands.Choice(name=f"Warp Staff ({Item.get_value(Item.WARP_STAFF)} SB)", value=Item.WARP_STAFF),
                                   app_commands.Choice(name=f"Flare ({Item.get_value(Item.FLARE)} SB)", value=Item.FLARE),
                                   app_commands.Choice(name=f"Elemental Gem ({Item.get_value(Item.ELEMENTAL_GEM)} SB)", value=Item.ELEMENTAL_GEM),
                                   app_commands.Choice(name=f"Nuke ({Item.get_value(Item.NUKE)} SB)", value=Item.NUKE),
                                   app_commands.Choice(name=f"EMP ({Item.get_value(Item.EMP)} SB)", value=Item.EMP),
                                   ])
@app_commands.describe(how_many = "How many would you like to buy?")
async def buy_item_command(interaction: discord.Interaction, item_to_buy: str, how_many: app_commands.Range[int, 1, 1000]):   
    await buy_items(interaction, item_to_buy, how_many)

@bot.tree.command(name="sell_items", description="sell your items for santiago bucks (sb)")
@app_commands.choices(item_to_sell=[app_commands.Choice(name=f"Gunpowder ({round(Item.get_value(Item.GUNPOWDER) * 0.85)} SB)", value=Item.GUNPOWDER),
                                    app_commands.Choice(name=f"Pixie Dust ({round(Item.get_value(Item.PIXIE_DUST) * 0.85)} SB)", value=Item.PIXIE_DUST),
                                    app_commands.Choice(name=f"Iron ({round(Item.get_value(Item.IRON) * 0.85)} SB)", value=Item.IRON),
                                    app_commands.Choice(name=f"Landmine ({round(Item.get_value(Item.LANDMINE) * 0.85)} SB)", value=Item.LANDMINE),
                                    app_commands.Choice(name=f"Bullet ({round(Item.get_value(Item.BULLET) * 0.85)} SB)", value=Item.BULLET),
                                    app_commands.Choice(name=f"Gold ({round(Item.get_value(Item.GOLD) * 0.85)} SB)", value=Item.GOLD),
                                    app_commands.Choice(name=f"Shotgun Shell ({round(Item.get_value(Item.SHOTGUN_SHELL) * 0.85)} SB)", value=Item.SHOTGUN_SHELL),
                                    app_commands.Choice(name=f"Heat-Seeking Missile ({round(Item.get_value(Item.HEAT_SEEKING_MISSILE) * 0.85)} SB)", value=Item.HEAT_SEEKING_MISSILE),
                                    app_commands.Choice(name=f"Signal Jammer ({round(Item.get_value(Item.SIGNAL_JAMMER) * 0.85)} SB)", value=Item.SIGNAL_JAMMER),
                                    app_commands.Choice(name=f"Flashbang ({round(Item.get_value(Item.FLASHBANG) * 0.85)} SB)", value=Item.FLASHBANG),
                                    app_commands.Choice(name=f"Warp Staff ({round(Item.get_value(Item.WARP_STAFF) * 0.85)} SB)", value=Item.WARP_STAFF),
                                    app_commands.Choice(name=f"Flare ({round(Item.get_value(Item.FLARE) * 0.85)} SB)", value=Item.FLARE),
                                    app_commands.Choice(name=f"Diamond ({round(Item.get_value(Item.DIAMOND) * 0.85)} SB)", value=Item.DIAMOND),
                                    app_commands.Choice(name=f"Elemental Gem ({round(Item.get_value(Item.ELEMENTAL_GEM) * 0.85)} SB)", value=Item.ELEMENTAL_GEM),
                                    app_commands.Choice(name=f"Nuke ({round(Item.get_value(Item.NUKE) * 0.85)} SB)", value=Item.NUKE),
                                    app_commands.Choice(name=f"EMP ({round(Item.get_value(Item.EMP) * 0.85)} SB)", value=Item.EMP),
                                   ])
@app_commands.describe(how_many = "How many would you like to sell?")
async def sell_item_command(interaction: discord.Interaction, item_to_sell: str, how_many: app_commands.Range[int, 1, 1000]):   
    await sell_items(interaction, item_to_sell, how_many)

@bot.tree.command(name="give_items", description="give another user some of your items")
@app_commands.describe(recipient = "How many would you like to buy?")
@app_commands.choices(item_to_give=[app_commands.Choice(name=f"Landmine", value=Item.LANDMINE),
                                    app_commands.Choice(name=f"Bullet", value=Item.BULLET), 
                                    app_commands.Choice(name=f"Shotgun Shell", value=Item.BULLET), 
                                    app_commands.Choice(name=f"Heat-Seeking Missile", value=Item.HEAT_SEEKING_MISSILE),
                                    app_commands.Choice(name=f"Signal Jammer", value=Item.SIGNAL_JAMMER),
                                    app_commands.Choice(name=f"Flashbang", value=Item.FLASHBANG),
                                    app_commands.Choice(name=f"Flashbang", value=Item.WARP_STAFF),
                                    app_commands.Choice(name=f"Flare", value=Item.FLARE),
                                    app_commands.Choice(name=f"Elemental Gem", value=Item.ELEMENTAL_GEM),
                                    app_commands.Choice(name=f"Nuke", value=Item.NUKE),
                                    app_commands.Choice(name=f"EMP", value=Item.EMP),
                                    app_commands.Choice(name=f"Gunpowder", value=Item.GUNPOWDER),
                                    app_commands.Choice(name=f"Pixie Dust", value=Item.PIXIE_DUST),
                                    app_commands.Choice(name=f"Iron", value=Item.IRON),
                                    app_commands.Choice(name=f"Gold", value=Item.GOLD),
                                    app_commands.Choice(name=f"Diamond", value=Item.DIAMOND),
                                   ])
@app_commands.describe(how_many = "How many would you like to give?")
async def give_item_command(interaction: discord.Interaction, recipient: discord.Member, item_to_give: str, how_many: app_commands.Range[int, 1, 1000]):   
    await give_items(interaction, recipient, item_to_give, how_many)

@bot.tree.command(name="craft_items", description="craft items from materials: type 's crafting' to view recipes")
@app_commands.choices(item_to_craft=[app_commands.Choice(name=f"Landmine", value=Item.LANDMINE),
                                    app_commands.Choice(name=f"Bullet", value=Item.BULLET), 
                                    app_commands.Choice(name=f"Shotgun Shell", value=Item.BULLET), 
                                    app_commands.Choice(name=f"Heat-Seeking Missile", value=Item.HEAT_SEEKING_MISSILE),
                                    app_commands.Choice(name=f"Signal Jammer", value=Item.SIGNAL_JAMMER),
                                    app_commands.Choice(name=f"Flashbang", value=Item.FLASHBANG),
                                    app_commands.Choice(name=f"Warp Staff", value=Item.WARP_STAFF),
                                    app_commands.Choice(name=f"Flare", value=Item.FLARE),
                                    app_commands.Choice(name=f"Elemental Gem", value=Item.ELEMENTAL_GEM),
                                    app_commands.Choice(name=f"Nuke", value=Item.NUKE),
                                    app_commands.Choice(name=f"EMP", value=Item.EMP),
                                   ])
@app_commands.describe(how_many = "How many would you like to craft?")
async def craft_item_command(interaction: discord.Interaction, item_to_craft: str, how_many: app_commands.Range[int, 1, 1000]):   
    await craft_items(interaction, item_to_craft, how_many)


##########################################################################################
#                        VC and Audio Commands (vc_commands.py)                          #
##########################################################################################



@bot.tree.command(name="join_call", description="hi")
async def join_call_command(interaction: discord.Interaction): 
    await join_call_manual(interaction)

@bot.tree.command(name="leave_call", description="leaves the current vc")
async def leave_call_command(interaction: discord.Interaction):
    await leave_call(interaction)

@bot.tree.command(name="set_volume", description="Sets a volume multiplier for all future sounds Santiago plays")
async def set_volume_command(interaction: discord.Interaction):
    await interaction.response.send_modal(VolumePromptModal())

@bot.tree.command(name="pause_or_resume", description="Pauses or resumes the current sound")
async def toggle_pause_command(interaction: discord.Interaction):
    await toggle_pause_state(interaction)

@bot.tree.command(name="stop_sound", description="stops any sound currently playing")
async def stop_sound_command(interaction: discord.Interaction):
    await stop_sound(interaction)

@bot.tree.command(name="oblivion_moment", description="Use when the vc really feels like TES_IV")
async def oblivion_command(interaction: discord.Interaction):
    await play_oblivion_music(interaction)

@bot.tree.command(name="ltg_speech", description="Use when someone in VC starts acting a little too sussy for your tastes")
@app_commands.describe(person_to_ltg = "Alright, who deserves this one?")
async def ltg_command(interaction: discord.Interaction, person_to_ltg: discord.Member):
    await play_ltg_speech(interaction, person_to_ltg)

@bot.tree.command(name="clown", description="Use when someone in VC needs to be revealed for the clown they are")
@app_commands.describe(person_to_clown = "Alright, who deserves this one?")
async def clown_command(interaction: discord.Interaction, person_to_clown: discord.Member):
    await play_clown_sound(interaction, person_to_clown)

@bot.tree.command(name="gigachad", description="Use when someone in VC is truly a sigma")
@app_commands.describe(person_to_giga = "Alright, who deserves this one?")
async def gigachad_command(interaction: discord.Interaction, person_to_giga: discord.Member):
    await play_gigachad_music(interaction, person_to_giga)

@bot.tree.command(name="russian_roulette", description="Try your hand to win some money! Are you feeling lucky...?")
async def russian_roulette_command(interaction: discord.Interaction):
    await russian_roulette(interaction)

@bot.tree.command(name="shoot", description="If you have bullets in your inventory, use them to shoot someone in VC")
@app_commands.describe(person_to_shoot = "who's being shot today?")
async def shoot_command(interaction: discord.Interaction, person_to_shoot: discord.Member):
    await shoot_user(interaction, person_to_shoot)
    
@bot.tree.command(name="nuke", description="If you have a nuke in your inventory, use it to nuke VC")
@app_commands.describe(vc_to_nuke = "what VC is being nuked today?")
async def nuke_command(interaction: discord.Interaction, vc_to_nuke: discord.VoiceChannel):
    await nuke_vc(interaction, vc_to_nuke)

@bot.tree.command(name="whirlwind", description="If you have an elemental gem, use it to conjure a storm in VC")
@app_commands.describe(vc_to_whirl = "which VC will become the new grounds of oklahoma?")
async def whirlwind_command(interaction: discord.Interaction, vc_to_whirl: discord.VoiceChannel):    
    await unleash_whirlwind(interaction, vc_to_whirl)

@bot.tree.command(name="landmine", description="If you have one, stealthily plant a landmine on a VC...")
@app_commands.describe(vc_to_plant = "which VC should be planted?")
async def landmine_command(interaction: discord.Interaction, vc_to_plant: discord.VoiceChannel):    
    await plant_landmine(interaction, vc_to_plant)

@bot.tree.command(name="blind_fire", description="If you have a bullet, close your eyes and aim at VC.")
@app_commands.describe(vc = "which VC will become the new grounds of oklahoma?")
async def blind_fire_command(interaction: discord.Interaction, vc: discord.VoiceChannel):    
    await blind_fire(interaction, vc)

@bot.tree.command(name="missile_target", description="Tracks user actions, if they're in or join a VC, kaboom.")
@app_commands.describe(person_to_target = "to whom should we lay waste?")
async def missile_target_command(interaction: discord.Interaction, person_to_target: discord.Member):    
    await missile_target(interaction, person_to_target)

@bot.tree.command(name="emergency_evac", description="If you have a flare, evacuates all users in your VC to the selected destination.")
@app_commands.describe(evac_destination = "where we dropping, boys?")
async def emergency_evac_command(interaction: discord.Interaction, evac_destination: discord.VoiceChannel):    
    await emergency_evac(interaction, evac_destination)

@bot.tree.command(name="shotgun_blast", description="If you have shells, blasts a shotgun into VC. Like /shoot, but more powerful and random.")
@app_commands.describe(vc_to_blast = "where we dropping, boys?")
async def shotgun_blast_command(interaction: discord.Interaction, vc_to_blast: discord.VoiceChannel):    
    await shotgun_blast(interaction, vc_to_blast)

@bot.tree.command(name="jammer_deploy", description="If you have a signal jammer, jams a user of your choice for 12 seconds.")
@app_commands.describe(jam_target = "who are you jamming?")
async def jammer_deploy_command(interaction: discord.Interaction, jam_target: discord.Member):    
    await jam_user(interaction, jam_target)

@bot.tree.command(name="flashbang", description="If you have one, renders a user unable to hear for 15 seconds.")
@app_commands.describe(flashbang_target = "who are you flashbanging?")
async def flashbang_command(interaction: discord.Interaction, flashbang_target: discord.Member):    
    await throw_flashbang(interaction, flashbang_target)

@bot.tree.command(name="emp", description="If you have one, renders a VC mute for 20 seconds.")
@app_commands.describe(emp_target = "which VC are you EMPing?")
async def emp_command(interaction: discord.Interaction, emp_target: discord.VoiceChannel):    
    await emp_vc(interaction, emp_target)

@bot.tree.command(name="warp_cast", description="If you have a warp staff, casts a teleportation spell on the unlucky victim.")
@app_commands.describe(warp_target = "who's not making it home unscathed and victorious?")
async def warp_command(interaction: discord.Interaction, warp_target: discord.Member):    
    await warp_cast(interaction, warp_target)




##########################################################################################
#                      Youtube and Queue Commands (yt-commands.py)                       #
##########################################################################################



@bot.tree.command(name="yt-play", description="play any youtube video's audio")
@app_commands.describe(video="Please enter a valid YouTube video title or provide a valid URL")
async def youtube_play_command(interaction: discord.Interaction, video: str):
    await youtube_play(interaction, video)

@bot.tree.command(name="clear_queue", description="clears the current video queue in the server")
async def clear_queue_command(interaction: discord.Interaction):
    await clear_queue(interaction)

@bot.tree.command(name="view_queue", description="check what videos are queued up to play")
async def view_queue_command(interaction: discord.Interaction):
    await send_view_queue_command(interaction)

@bot.tree.command(name="toggle_loop", description="will loop or stop looping the youtube video currently playing or next to play")
async def toggle_loop_command(interaction: discord.Interaction):
    await toggle_loop(interaction)

@bot.tree.command(name="remove_from_queue", description="Remove a song from the queue")
async def remove_from_queue_command(interaction: discord.Interaction):
    await remove_video_from_queue(interaction)

@bot.tree.command(name="skip_to", description="skips to a specific song in the queue")
async def skip_to_command(interaction: discord.Interaction):
    await skip_queue_to(interaction)



##########################################################################################
#                             AI Commands (ai_commands.py)                               #
##########################################################################################



@bot.tree.command(name="talk", description="have santiago talk to you in vc")
@app_commands.describe(user_message="what do you want to say to santiago?")
async def talk_command(interaction: discord.Interaction, user_message: str):
    await generate_text_and_audio(interaction, user_message)

@bot.tree.command(name="gpt_model", description="switch the chat model between 'gpt-3.5' and 'gpt-4'")
@app_commands.choices(model=[app_commands.Choice(name="gpt-4o", value="gpt-4o"), app_commands.Choice(name="gpt-4o-mini", value="gpt-4o-mini")])
async def set_gpt_model_command(interaction: discord.Interaction, model: str):
    await set_gpt_model_manually(interaction, model)

@bot.tree.command(name="narrate", description="make santiago narrate something in vc in a custom voice")
@app_commands.describe(what_to_say = "What should I say?")
@app_commands.choices(voice=[app_commands.Choice(name="braydon", value=VOICE_MAP["braydon"]), app_commands.Choice(name="wil", value=VOICE_MAP["wil"]),
                             app_commands.Choice(name="cyclops", value=VOICE_MAP["cyclops"]), app_commands.Choice(name="scorch (titanfall)", value=VOICE_MAP["scorch"]),
                             app_commands.Choice(name="vinny mario", value=VOICE_MAP["vinny mario"]), app_commands.Choice(name="phone guy", value=VOICE_MAP["phone guy"]),
                             app_commands.Choice(name="josh", value=VOICE_MAP["josh"]), app_commands.Choice(name="akechi", value=VOICE_MAP["akechi"]),])
async def narrate_command(interaction: discord.Interaction, voice: str, what_to_say: str):
    await narrate(interaction, what_to_say, voice)

@bot.tree.command(name="toggle_chat_replies", description="turns santiago's ai responses in chat on or off")
async def toggle_chat_replies_command(interaction: discord.Interaction):   
    await toggle_ai_chat_replies(interaction)

@bot.tree.command(name="record_and_respond", description="listens to your voice and responds to you")
@app_commands.describe(how_long = "How many seconds (between 3-20) would you like to talk to me?")
async def respond_to_user_voice_command(interaction: discord.Interaction, how_long: app_commands.Range[int, 3, 30]):   
    await record_user_voice_and_respond(interaction, how_long)

@bot.tree.command(name="fast_record_and_respond", description="listens to your voice and responds to you, defaults for 10 seconds")
async def fast_respond_to_user_voice_command(interaction: discord.Interaction):   
    await record_user_voice_and_respond(interaction, 10)

@bot.tree.command(name="transcribe", description="transcribes your voice into text")
@app_commands.describe(how_long = "How many seconds (between 3-20) would you like to speak?")
async def transcribe_command(interaction: discord.Interaction, how_long: app_commands.Range[int, 3, 30]):   
    await transcribe(interaction, how_long)

@bot.tree.command(name="wipe_memory", description="wipes santiago's memory for the server")
async def wipe_memory_command(interaction: discord.Interaction):   
    await wipe_memory(interaction)
    
@bot.tree.command(name="reset_to_server_default", description="sets all variable settings to their default")
async def reset_to_server_default_command(interaction: discord.Interaction):   
    await reset_to_server_default(interaction)






#guess what this does.
bot.run(BOT_TOKEN)

