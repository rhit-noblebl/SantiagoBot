import sqlite3
import discord
import json
import asyncio

from src.config.main_config import bot
from src.config.database_config import DATABASE_PATH

from src.utils.generic_utils import get_volume_multiplier, increment_amount_shot


async def join_call(channel: discord.VoiceChannel):
    conn = sqlite3.connect(DATABASE_PATH)
    cursor = conn.cursor()

    cursor.execute("SELECT voice_client_info FROM voice_clients WHERE guild_id = ?", (channel.guild.id,))
    result = cursor.fetchone()
    vc_info = None
    vc = None
    
    if result:
        vc_info = json.loads(result[0])
        vc = discord.utils.get(bot.voice_clients, guild=channel.guild)
    
    if vc is None or not vc.is_connected():
        vc = await channel.connect()
        voice_client_info = {'channel_id': vc.channel.id}
        cursor.execute('''
            INSERT INTO voice_clients (guild_id, voice_client_info)
            VALUES (?, ?)
            ON CONFLICT(guild_id) DO UPDATE SET voice_client_info=excluded.voice_client_info
        ''', (channel.guild.id, json.dumps(voice_client_info)))
        conn.commit()
    elif vc.channel != channel:
        await vc.move_to(channel)
    
    conn.close()
    return vc


async def join_and_play_sound(channel, audio_source, base_volume):
    vc = await join_call(channel)
    if vc.is_playing():
        vc.stop()
    vc.play(discord.FFmpegPCMAudio(executable="C:/ffmpeg/bin/ffmpeg.exe", source=audio_source, options=f"-filter:a \"volume={base_volume * get_volume_multiplier(channel.guild.id)}\""))
    return vc


# this was a little weird to make as a general function, but it is needed in two functions so ¯\_(ツ)_/¯. 
# basically, it sends the clowns and plays the clown file
async def impart_clown_judgement(interaction: discord.Interaction, person_to_clown: discord.Member):
    clown_vc = person_to_clown.voice.channel

    if clown_vc is not None:
            vc = await join_and_play_sound(clown_vc, "src/data/sound_files/clown.mp3", 0.35)
            await interaction.channel.send(f"looks like someone in VC is a clown!\n\nchat, laugh at {person_to_clown.mention}")   
            clown_gifs = [
                "https://media1.tenor.com/m/mOZucMZ9ZygAAAAd/clown-mcdonald.gif",
                "https://media1.tenor.com/m/IDyfUSzUxRkAAAAC/mcdonalds-ronald-mcdonald.gif",
                "https://media1.tenor.com/m/gj4q_xk08gMAAAAC/mcdonalds-ronald-mcdonald.gif",
                "https://media1.tenor.com/m/g288q_b6udIAAAAC/ronald-point.gif",
                "https://media1.tenor.com/m/ES3ljWtpeTsAAAAC/ronald.gif",
                "https://media1.tenor.com/m/3DSsnoS8FgMAAAAC/clown-mcdonalds.gif"
            ]

            for gif in clown_gifs:
                if not vc.is_playing():
                    break
                await interaction.channel.send(gif)
                await asyncio.sleep(2)
                if not vc.is_playing():
                    break
                await interaction.channel.send(person_to_clown.mention)
                await asyncio.sleep(1)

async def flashbang_user(victim):
    await join_and_play_sound(victim.voice.channel, "src/data/sound_files/flashbang.mp3", 0.5)
    await asyncio.sleep(1.2)
    await deafen_user(victim)
    await asyncio.sleep(12)
    await undeafen_user(victim)


async def shoot_and_play_gunshot(victim):
    await join_and_play_sound(victim.voice.channel, "src/data/sound_files/gunshot.mp3", 5)
    await asyncio.sleep(.2)
    await victim.move_to(None)
    await increment_amount_shot(victim.id)


async def mute_user(victim: discord.Member):
    await victim.edit(mute=True)


async def deafen_user(victim: discord.Member):
    await victim.edit(deafen=True)


async def unmute_user(victim: discord.Member):
    await victim.edit(mute=False)


async def undeafen_user(victim: discord.Member):
    await victim.edit(deafen=False)


