import sqlite3

from src.config.database_config import DATABASE_PATH



def truncate_message(message, max_length=2000):
    """
    Truncate the message to a maximum length and append ellipsis if needed.
    
    Parameters:
    - message (str): The message to be truncated.
    - max_length (int): The maximum allowed length for the message.
    
    Returns:
    - str: The truncated message with an ellipsis if it was too long.
    """
    if len(message) > max_length:
        return message[:max_length - 3] + "..."
    return message


def upsert_guild_settings(guild_id, volume_multiplier=1.0, chat_replies_enabled=True, loop_queue_enabled=False, gpt_model="gpt-4o-mini"):
    conn = sqlite3.connect(DATABASE_PATH)
    cursor = conn.cursor()

    cursor.execute('''
        INSERT INTO guild_settings (guild_id, volume_multiplier, chat_replies_enabled, loop_queue_enabled, gpt_model)
        VALUES (?, ?, ?, ?, ?)
        ON CONFLICT(guild_id) DO UPDATE SET
            volume_multiplier=excluded.volume_multiplier,
            chat_replies_enabled=excluded.chat_replies_enabled,
            loop_queue_enabled=excluded.loop_queue_enabled,
            gpt_model=excluded.gpt_model
    ''', (guild_id, volume_multiplier, chat_replies_enabled, loop_queue_enabled, gpt_model))

    conn.commit()
    conn.close()


def get_looping_enabled(guild_id):
    return get_guild_settings(guild_id)['loop_queue_enabled']

def get_volume_multiplier(guild_id):
    return get_guild_settings(guild_id)['volume_multiplier']

def get_chat_replies_enabled(guild_id):
    return get_guild_settings(guild_id)['chat_replies_enabled']

def get_gpt_model(guild_id):
    return get_guild_settings(guild_id)['gpt_model']

def set_volume_multiplier(guild_id, volume_multiplier):
    conn = sqlite3.connect(DATABASE_PATH)
    cursor = conn.cursor()

    cursor.execute('''
        INSERT INTO guild_settings (guild_id, volume_multiplier)
        VALUES (?, ?)
        ON CONFLICT(guild_id) DO UPDATE SET
            volume_multiplier=excluded.volume_multiplier
    ''', (guild_id, volume_multiplier))

    conn.commit()
    conn.close()

def set_chat_replies_enabled(guild_id, chat_replies_enabled):
    conn = sqlite3.connect(DATABASE_PATH)
    cursor = conn.cursor()

    cursor.execute('''
        INSERT INTO guild_settings (guild_id, chat_replies_enabled)
        VALUES (?, ?)
        ON CONFLICT(guild_id) DO UPDATE SET
            chat_replies_enabled=excluded.chat_replies_enabled
    ''', (guild_id, chat_replies_enabled))

    conn.commit()
    conn.close()

def set_looping_enabled(guild_id, loop_queue_enabled):
    conn = sqlite3.connect(DATABASE_PATH)
    cursor = conn.cursor()

    cursor.execute('''
        INSERT INTO guild_settings (guild_id, loop_queue_enabled)
        VALUES (?, ?)
        ON CONFLICT(guild_id) DO UPDATE SET
            loop_queue_enabled=excluded.loop_queue_enabled
    ''', (guild_id, loop_queue_enabled))

    conn.commit()
    conn.close()

def set_gpt_model(guild_id, gpt_model):
    conn = sqlite3.connect(DATABASE_PATH)
    cursor = conn.cursor()

    cursor.execute('''
        INSERT INTO guild_settings (guild_id, gpt_model)
        VALUES (?, ?)
        ON CONFLICT(guild_id) DO UPDATE SET
            gpt_model=excluded.gpt_model
    ''', (guild_id, gpt_model))

    conn.commit()
    conn.close()

def get_guild_settings(guild_id):
    conn = sqlite3.connect(DATABASE_PATH)
    cursor = conn.cursor()

    cursor.execute('''
        SELECT volume_multiplier, chat_replies_enabled, loop_queue_enabled, gpt_model
        FROM guild_settings
        WHERE guild_id = ?
    ''', (guild_id,))
    
    result = cursor.fetchone()
    conn.close()

    if result:
        return {
            'volume_multiplier': result[0],
            'chat_replies_enabled': result[1],
            'loop_queue_enabled': result[2],
            'gpt_model': result[3]
        }
    else:
        # Return default values if no settings are found
        return {
            'volume_multiplier': 1.0,
            'chat_replies_enabled': True,
            'loop_queue_enabled': False,
            'gpt_model': 'gpt-4o-mini'
        }
    
def capitalize_item_name(name):
    return ' '.join(word.capitalize() for word in name.split())

def get_users_in_guild(guild_id, db_path=DATABASE_PATH):
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()

    # Fetch users associated with the given guild
    cursor.execute('''
        SELECT users.user_id, users.user_name, users.currency
        FROM users
        INNER JOIN user_guilds ON users.user_id = user_guilds.user_id
        WHERE user_guilds.guild_id = ?
    ''', (guild_id,))

    results = cursor.fetchall()
    conn.close()

    user_list = []
    for row in results:
        user_id, user_name, currency = row
        user_list.append({
            "user_id": user_id,
            "user_name": user_name,
            "currency": currency
        })

    return user_list



##########################################################################################
#                                    Stat Commands                                       #
##########################################################################################


async def increment_amount_gambled(user_id):
    conn = sqlite3.connect(DATABASE_PATH)
    cursor = conn.cursor()

    cursor.execute('''
        UPDATE user_stats
        SET amount_gambled = amount_gambled + 1
        WHERE user_id = ?
    ''', (user_id,))

    conn.commit()
    conn.close()

async def increment_amount_shot(user_id):
    conn = sqlite3.connect(DATABASE_PATH)
    cursor = conn.cursor()

    cursor.execute('''
        UPDATE user_stats
        SET amount_shot = amount_shot + 1
        WHERE user_id = ?
    ''', (user_id,))

    conn.commit()
    conn.close()
    
async def increment_amount_exploded(user_id):
    conn = sqlite3.connect(DATABASE_PATH)
    cursor = conn.cursor()

    cursor.execute('''
        UPDATE user_stats
        SET amount_exploded = amount_exploded + 1
        WHERE user_id = ?
    ''', (user_id,))

    conn.commit()
    conn.close()

async def increment_slash_commands_used(user_id):
    conn = sqlite3.connect(DATABASE_PATH)
    cursor = conn.cursor()

    cursor.execute('''
        UPDATE user_stats
        SET slash_commands_used = slash_commands_used + 1
        WHERE user_id = ?
    ''', (user_id,))

    conn.commit()
    conn.close()