import discord
import yt_dlp
import random
import asyncio
import re
import io

from youtubesearchpython import VideosSearch
from pathlib import Path

from src.config import get_volume_multiplier, video_queue, loop_current_video, volume_multiplier, bot
from src.data.reactions_lists import PLAY_QUIP_TEMPLATES, QUEUE_QUIP_TEMPLATES
from src.commands.vc_commands import join_call, toggle_pause_state, stop_sound, leave_call, VolumePromptModal
from src.commands.ai_commands import transcribe_file

# extension of discord's view so that you can view the current queue
class QueueView(discord.ui.View):
                
    @discord.ui.button(label="Pause/Resume", style=discord.ButtonStyle.blurple, row=0)
    async def play_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        await toggle_pause_state(interaction)


    @discord.ui.button(label="Toggle Loop", style=discord.ButtonStyle.blurple, row=0)
    async def toggle_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        await toggle_loop(interaction)


    @discord.ui.button(label="Skip Current Video", style=discord.ButtonStyle.green, row=1)
    async def stop_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        await stop_sound(interaction)


    @discord.ui.button(label="Skip To Position", style=discord.ButtonStyle.green, row=1)
    async def skip_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        await skip_queue_to(interaction)


    @discord.ui.button(label="Remove A Video From Queue", style=discord.ButtonStyle.red, row=2)
    async def remove_video_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        await remove_video_from_queue(interaction)
    

    @discord.ui.button(label="Clear Queue", style=discord.ButtonStyle.red, row=2)
    async def clear_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        await clear_queue(interaction)


    @discord.ui.button(label="Set Volume Multiplier", style=discord.ButtonStyle.gray, row=3)
    async def enter_number_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_modal(VolumePromptModal())


    @discord.ui.button(label="Leave Call", style=discord.ButtonStyle.gray, row=3)
    async def leave_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        await leave_call(interaction)
        await interaction.message.edit(view=None) 


# extension of discord's view so that you can see the items in queue to remove them
class QueueRemovalView(discord.ui.View):
    
    def __init__(self, queue):
        super().__init__()
        self.queue = queue
        self.add_buttons()

    def add_buttons(self):
        for i, video in enumerate(self.queue[1:], 1):
            label = f"{video[1]} by {video[2]}"
            if len(label) > 80:
                label = label[:77] + '...'

            button = discord.ui.Button(label=label, custom_id=str(i))
            button.callback = self.on_button_click  # Assign the function reference here
            self.add_item(button)

    async def on_button_click(self, interaction: discord.Interaction):
        position = int(interaction.data['custom_id'])
        popped_video = self.queue.pop(position) 
        await interaction.response.send_message(f"just a heads up guys, {interaction.user.mention} just removed {popped_video[1]} by {popped_video[2]} from the queue")


# perhaps a little lazy here, but i wanted to experiment. does the above but you can skip to them instead
class QueueSkipView(QueueRemovalView):
    
    async def on_button_click(self, interaction: discord.Interaction):
        position = int(interaction.data['custom_id'])
        del self.queue[position - 1]
        current_video = self.queue[0]
        await stop_sound(interaction)
        await interaction.channel.send(f"we're skipping ahead a bit. {interaction.user.mention} just skipped the queue to {current_video[1]} by {current_video[2]}")




# oh boy. this is the big boy. the function that started it all and inspired me to build this damn bot in the first place.
# the largest code by far of everything here, and has like 3 helpers associated with it. hope no part of this breaks or you're
# in for a nightmare of a debugging session. 
async def youtube_play(interaction: discord.Interaction, video: str):

    if interaction.guild.id not in video_queue:
        video_queue[interaction.guild.id] = []

    await interaction.response.defer() 
    
    voice_state = interaction.user.voice
    if voice_state is None:
        await interaction.followup.send("get in a call first, then we can play a video for people (or yourself)", ephemeral=True)
        return

    url = video
    vc = await join_call(interaction)
        
    ydl_opts = {
        'format': 'bestaudio/best',
        'verbose': True,
        'nocheckcertificate': True
    }

    if not url.startswith("https://www.youtube.com/watch?v="):
        videosSearch = VideosSearch(url, limit = 1)
        search_result = videosSearch.result()
        if 'result' in search_result and len(search_result['result']) > 0:
            video_info = search_result['result'][0]
        url = video_info.get('link', '')

    try:
        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            info_dict = ydl.extract_info(url, download=False)
            audio_url = info_dict['url']
            title = info_dict.get('title', 'Unknown Title')
            uploader = info_dict.get('uploader', 'Unknown Uploader')
            print(audio_url)

            video_queue[interaction.guild.id].append((audio_url, title, uploader))

            if vc.is_playing():
                queue_quips = [template.format(mention=interaction.user.mention, title=title, uploader=uploader) for template in QUEUE_QUIP_TEMPLATES]
                await interaction.followup.send(random.choice(queue_quips))
            else:
                play_quips = [template.format(mention=interaction.user.mention, title=title, uploader=uploader) for template in PLAY_QUIP_TEMPLATES]
                await interaction.followup.send(random.choice(play_quips))
                await play_next(interaction.guild.id, vc, audio_url, interaction)
            
            await send_view_queue(interaction)

    except Exception as e:
        await interaction.followup.send(f"I'm not gonna suger coat it\n\nError: {str(e)}")
        print(f"Error: {str(e)}")

# plays next video from queue
async def play_next(guild_id, vc, audio_url, interaction):

    ffmpeg_options = {
        'before_options': '-reconnect 1 -reconnect_streamed 1 -reconnect_delay_max 5',
        'options': f'-vn -filter:a "volume={0.175*await get_volume_multiplier()}"'
    }

    # necessary to stop it from conflicting with other, non-youtube sound files 
    async def delayed_check_queue():
        if(not loop_current_video):
            video_queue[guild_id].pop(0)
        await asyncio.sleep(1)
        await check_queue(guild_id, vc, interaction)

    vc.play(discord.FFmpegPCMAudio(audio_url, **ffmpeg_options), after=lambda e: bot.loop.create_task(delayed_check_queue()))


# checks next video on the queue and plays it
async def check_queue(guild_id, vc, interaction):
    while vc.is_playing() or vc.is_paused():
        await asyncio.sleep(1)

    if video_queue[guild_id]:
        next_url = video_queue[guild_id][0][0]
        await play_next(guild_id, vc, next_url, interaction)
    else:
        video_queue[guild_id] = []


async def clear_queue(interaction: discord.Interaction):
    bot_voice_channel = interaction.guild.voice_client.channel if interaction.guild.voice_client else None
    if not bot_voice_channel:
        await interaction.response.send_message("brother and/or sister, im not even in a voice channel. calm your dick and/or tits", ephemeral=True)
        return
    elif not interaction.user.voice or interaction.user.voice.channel != bot_voice_channel:
        await interaction.response.send_message("to all my homies in VC, I just want to let you know that this bozo right here just tried to clear your queue. but dont worry, i gotchu")
        return
    
    if interaction.guild.id not in video_queue or not video_queue[interaction.guild.id]:
        await interaction.response.send_message(f"Buddy, are you feeling okay...? There isn't any queue to clear...", ephemeral=True)
    else:
        video_queue[interaction.guild.id].clear()
        await interaction.response.send_message(f"I hope y'all weren't planning on listening to any of that... {interaction.user.mention} just cleared the queue.")
       

async def toggle_loop(interaction:discord.Interaction):

    bot_voice_client = discord.utils.get(bot.voice_clients, guild=interaction.guild)
    if bot_voice_client and interaction.user.voice:
        if bot_voice_client.channel == interaction.user.voice.channel:
            global loop_current_video
            loop_current_video = not loop_current_video
            if loop_current_video:
                await interaction.response.send_message("https://media.tenor.com/hdEL0uNj1Z4AAAAM/diavolo-requiem.gif")
            else:
                await interaction.response.send_message("I'M FREE! FREE AT LAST!")
        else: 
            await interaction.response.send_message("we arent in the same call. im not going to let you sabotage the queue.", ephemeral=True)
    else: 
            await interaction.response.send_message("one of us isnt in a vc. fix that.", ephemeral=True)


async def skip_queue_to(interaction: discord.Interaction):
    if interaction.guild.id in video_queue and video_queue[interaction.guild.id]:
        view = QueueSkipView(queue=video_queue[interaction.guild.id])
        await interaction.response.send_message("Select a song to skip to:\n", ephemeral=True, view=view)
    else:
        await interaction.response.send_message("the queue is empty", ephemeral=True)


async def remove_video_from_queue(interaction: discord.Interaction):
    if interaction.guild.id in video_queue and video_queue[interaction.guild.id]:
        view = QueueRemovalView(queue=video_queue[interaction.guild.id])
        await interaction.response.send_message("Select a song to remove:\n", ephemeral=True, view=view)
    else:
        await interaction.response.send_message("the queue is empty", ephemeral=True)


async def send_view_queue(interaction: discord.Interaction):

    queue_embed = discord.Embed()
    queue_embed.title = f"Santiago's {interaction.guild.name} Queue\n\u200b"
    if loop_current_video:
        queue_embed.set_author(name="-----------CURRENTLY LOOPING-----------")
    else:
        queue_embed.set_author(name="----------------------------------------------")
    queue_embed.set_thumbnail(url="https://i.kym-cdn.com/entries/icons/facebook/000/043/184/burning_piano.jpg")
    queue_embed.color = discord.Colour.brand_green()

    current_video = video_queue[interaction.guild.id][0]

    current_video_value_field = f"**{current_video[1]}**\nby {current_video[2]}\n" 
    if len(video_queue[interaction.guild.id]) > 1:
        current_video_value_field += "-----------------------|      **UPCOMING**      |-----------------------"
    else:
        current_video_value_field += "-------------------------------------------------------------\n"

    queue_embed.add_field(name="Currently Playing:", value=current_video_value_field, inline=False)

    for i, video in enumerate(video_queue[interaction.guild.id][1:7], 1):
        queue_embed.add_field(name=f"**{i}:**", value=f"**{video[1]}**\nby {video[2]}\n\u200b" + "\u200b", inline=True)

    if len(video_queue[interaction.guild.id]) > 7:
        queue_embed.set_footer(text=f"Plus {len(video_queue[interaction.guild.id]) - 7} more...")

    queue_view = QueueView()

    await interaction.channel.send(embed=queue_embed, view=queue_view)


async def transcribe_yt_audio(message: discord.Message):
    if "yttranscribe" in message.content.lower():
        youtube_url_pattern = re.compile(
            r'(https?://)?(www\.)?(youtube\.com|youtu\.be)/(watch\?v=)?([a-zA-Z0-9_-]{11})'
        )
        match = youtube_url_pattern.search(message.content)
        
        if match:
            youtube_url = match.group(0)
            output_path = Path(__file__).parent / "sound_files" / "youtube_video.mp3"

            if output_path.exists():
                output_path.unlink()

            ydl_opts = {
                'format': 'bestaudio/best',
                'verbose': True,
                'nocheckcertificate': True,
                'noplaylist': True,
                'outtmpl': str(output_path)
            }

            try:
                with yt_dlp.YoutubeDL(ydl_opts) as ydl:
                    info_dict = ydl.extract_info(youtube_url, download=True)
                    title = info_dict.get('title', 'Unknown Title')
                    uploader = info_dict.get('uploader', 'Unknown Uploader')

                transcription = await transcribe_file(output_path)
                transcription_file = io.StringIO(transcription)
                transcription_file.seek(0)  # Rewind the file pointer to the beginning

                # Create a Discord file attachment
                txt_file = discord.File(fp=transcription_file, filename="transcription.txt")

                await message.reply(f"Here is the transcription of the video '{title}' by '{uploader}':", file=txt_file)
               
            except Exception as e:
                await message.reply(f"I'm not gonna suger coat it\n\nError: {str(e)}")
                print(f"Error: {str(e)}")

            finally:
                if output_path.exists():
                    output_path.unlink()

        else:
            await message.reply("enter a valid youtube url, and i will transcribe the whole video for you.\n\n(NOTE FROM BRAYDON: "
                                "please don't make it long. seriously, it costs a lot to generate even a 5 minute video. try to keep "
                                "it short and only make it a long one if you really need the transcription. if you need it, go ahead "
                                "- by all means, i would love to help; however, if youre doing it for a meme or just to test the "
                                "command, only do it on a <4 minute video. please. thank you.)")
        return True

