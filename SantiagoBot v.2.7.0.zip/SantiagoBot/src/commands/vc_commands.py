import discord
import random
import asyncio
from src.config import bot, voice_clients, set_volume_multiplier, get_volume_multiplier
from src.data.reactions_lists import STOP_QUIP_TEMPLATES, PAUSE_QUIP_TEMPLATES, RESUME_QUIP_TEMPLATES
from src.data.gif_and_image_lists import GIGACHAD_GIFS


class VolumePromptModal(discord.ui.Modal, title="Set a multiplier for Santiago's volume"):
    
    number = discord.ui.TextInput(label="Volume", placeholder="Enter a number between 0.01 and 20. 1 is default.", min_length=1, max_length=5)
    async def on_submit(self, interaction: discord.Interaction):
        try:
            number = float(self.number.value)
            if 0.01 <= number <= 20:
                await set_volume_multiplier(number)
                await interaction.response.send_message(f"big heads up to my homies in VC: {interaction.user.mention} just set the volume multiplier to {await get_volume_multiplier()}")
            else:
                await interaction.response.send_message("read the number range my guy and/or gal", ephemeral=True)
        except ValueError:
            await interaction.response.send_message("you shouldnt get this error. if you did, it means either i broke or you were screwing around. read the limits", ephemeral=True)


async def join_and_play_sound(guild, user_voice_channel, bot_voice_channel, audio_source, base_volume):
    vc = await join_and_stop_playing(guild, user_voice_channel, bot_voice_channel)
    vc.play(discord.FFmpegPCMAudio(executable="C:/ffmpeg/bin/ffmpeg.exe", source=audio_source, options=f"-filter:a \"volume={base_volume* await get_volume_multiplier()}\""))
    return vc
    

async def join_and_stop_playing(guild, user_voice_channel, bot_voice_channel):
    vc = voice_clients.get(guild)
    if vc is None and bot_voice_channel is not None:
        vc = bot_voice_channel
    if vc is None or not vc.is_connected():
        vc = await user_voice_channel.connect()
        voice_clients[guild] = vc
    elif vc.channel != user_voice_channel:
        await vc.move_to(user_voice_channel)
    if vc.is_playing():
        vc.stop()
    return vc


async def join_call(interaction: discord.Interaction):
    user_voice_channel = interaction.user.voice.channel
    bot_voice_client = discord.utils.get(bot.voice_clients, guild=interaction.guild)
    if user_voice_channel is not None:
        vc = voice_clients.get(interaction.guild.id)
        if vc is None and bot_voice_client is not None:
            vc = bot_voice_client
        if vc is None or not vc.is_connected():
            vc = await user_voice_channel.connect()
            voice_clients[interaction.guild.id] = vc
        elif vc.channel != user_voice_channel:
            await vc.move_to(user_voice_channel)
        return vc
    else:
        await interaction.channel.send(f"{interaction.user.mention}, i can't join if you ain't in a call")


async def leave_call(interaction: discord.Interaction):
    bot_voice_client = discord.utils.get(bot.voice_clients, guild=interaction.guild)
    if bot_voice_client is None:
        await interaction.response.send_message("are you stupid")
    else:
        voice_state = interaction.user.voice
        if voice_state is not None:
            if voice_state.channel != bot_voice_client.channel:
                await interaction.response.send_message("listen pal, i know youre jealous that im not in your channel, but i cant just leave here... that is, unless you used /join_call... then, well... i might be swayed ;)", ephemeral=True)
            else:
                await interaction.response.send_message("bye")
                await bot_voice_client.disconnect()
        else:
            await interaction.response.send_message("hold up buddy, i aint gonna let some non-caller tell me what to do... if you want me to leave, tell that to my face. join my call, then maybe we'll talk", ephemeral=True)


async def stop_sound(interaction: discord.Interaction):
    stop_quips = [template.format(stopper=interaction.user.mention) for template in STOP_QUIP_TEMPLATES]

    bot_voice_channel = discord.utils.get(bot.voice_clients, guild=interaction.guild)
    if bot_voice_channel is None:
        await interaction.response.send_message("are you stupid", ephemeral=True)
    else:
        if not bot_voice_channel.is_playing():
            await interaction.response.send_message("nothing is playing. check your ears, you might have tinnitus", ephemeral=True)
        else:
            voice_state = interaction.user.voice
            if voice_state is None:
                await interaction.response.send_message("bruh you aren't even in a vc", ephemeral=True)
            elif voice_state.channel != bot_voice_channel.channel:
                await interaction.response.send_message("you're just jealous this vc has better music than yours", ephemeral=True)
            else:
                bot_voice_channel.stop()
                await interaction.response.send_message(random.choice(stop_quips))


async def toggle_pause_state(interaction: discord.Interaction):
    user_voice_channel = interaction.user.voice.channel
    bot_voice_client = discord.utils.get(bot.voice_clients, guild=interaction.guild)
    vc = voice_clients.get(interaction.guild.id)
    if vc is None and bot_voice_client is not None:
        await interaction.response.send_message("imma be real with you chief, i have no idea how this error is even possible. like i legitimately have no clue how or why the code would literally ever reach here ever. alas. seriously, ask braydon about this and tell him the details because it is really fucking weird if you got this")
        return
    elif vc is None or not vc.is_connected():
        await interaction.response.send_message("brother or sister in christ, i'm not capable of pausing or playing that youtube video you've got queued up in the background... or whatever sound you're hearing. whatever you're hearing, you're not hearing it in call, that's for sure. get in call.", ephemeral=True)
        return
    elif vc.channel != user_voice_channel:
        await interaction.response.send_message("yeah, very funny. i'm not letting you pause or resume a sound i may or may not be playing from outside the call im actually in", ephemeral=True)
        return
    
    if vc.is_playing():
        vc.pause()
        pause_quips = [template.format(pauser=interaction.user.mention) for template in PAUSE_QUIP_TEMPLATES]
        await interaction.response.send_message(random.choice(pause_quips))    
    elif vc.is_paused():
        vc.resume()
        resume_quips = [template.format(resumer=interaction.user.mention) for template in RESUME_QUIP_TEMPLATES]
        await interaction.response.send_message(random.choice(resume_quips))

    else:
        await interaction.response.send_message("im sorry. im not capable of pausing the voices in your head. good luck.")


async def play_oblivion_music(interaction: discord.Interaction):

    voice_state = interaction.user.voice
    if voice_state is None:
        await interaction.response.send_message("the only oblivion moment is you for not being in call", ephemeral=True)
        return

    user_voice_channel = interaction.user.voice.channel
    bot_voice_client = discord.utils.get(bot.voice_clients, guild=interaction.guild)
    if user_voice_channel is not None:
        await join_and_play_sound(interaction.guild.id, user_voice_channel, bot_voice_client, "src/sound_files/oblivion.mp3", 0.35)
        await interaction.response.send_message(f"oblivion", ephemeral=True)
    else:
        await interaction.response.send_message(f"you're not in a voice channel. get in there", ephemeral=True)


async def play_ltg_speech(interaction: discord.Interaction, person_to_ltg: discord.Member):
    
    if(person_to_ltg == bot.user):
        await interaction.response.defer()
        await interaction.followup.send(f"{interaction.user.mention} thinks they're pretty funny")
        for k in range(5):
          await interaction.followup.send("https://media.tenor.com/C8MpzwDxl40AAAAM/ltg-low-tier-god.gif")

    
    if(person_to_ltg == interaction.user):
        await interaction.response.defer()
        await interaction.response.send_message(f"are you feeling okay? please consider calling 1-800-273-8255. help is always available.", ephemeral=True)
        return

    
    voice_state = person_to_ltg.voice
    if voice_state is None:
        await interaction.response.send_message("someone in __vc.__ not the aether", ephemeral=True)
        return
    
    
    else:
        user_voice_channel = person_to_ltg.voice.channel
        bot_voice_client = discord.utils.get(bot.voice_clients, guild=interaction.guild)
        if user_voice_channel is not None:
            vc = await join_and_play_sound(interaction.guild.id, user_voice_channel, bot_voice_client, "src/sound_files/ltgspeech.mp3", 0.4)
            channel = interaction.channel
            await interaction.response.send_message("give it a sec...", ephemeral=True)
            await asyncio.sleep(34)
            if vc.is_playing():
                await channel.send(f"{person_to_ltg.mention}")
                await channel.send(f"https://media.tenor.com/C8MpzwDxl40AAAAM/ltg-low-tier-god.gif") 
        else:
            await interaction.response.send_message("this error should literally never be reached. if it was, yell for braydon", ephemeral=True)


async def play_clown_sound(interaction: discord.Interaction, person_to_clown: discord.Member):
    
    await interaction.response.defer(ephemeral=True)

    if(person_to_clown == bot.user):
        await interaction.followup.send(f"oh yeah?")
        await asyncio.sleep(1)
        for k in range(5):
          await interaction.followup.send("https://media.tenor.com/C8MpzwDxl40AAAAM/ltg-low-tier-god.gif")
        return
    
    if(person_to_clown == interaction.user):
        await interaction.followup.send(f"no. i just feel bad for you", ephemeral=True)
        return

    voice_state = person_to_clown.voice
    if voice_state is None:
        await interaction.followup.send("the only clown here is you for not reading the 3rd through 5th words of this command's description", ephemeral=True)
        return
    
    else:
        user_voice_channel = person_to_clown.voice.channel
        bot_voice_client = discord.utils.get(bot.voice_clients, guild=interaction.guild)
        await interaction.followup.send("gotcha. here's where the fun begins...", ephemeral=True)
        await impart_clown_judgement(person_to_clown, user_voice_channel, bot_voice_client, interaction.channel, interaction.guild.id)


async def play_gigachad_music(interaction: discord.Interaction, person_to_giga: discord.Member):

    if(person_to_giga.id == 948588784893714462):
        await interaction.response.send_message(f"{interaction.user.mention} thinks they're pretty funny... and they're right!")
        await interaction.channel.send("https://tenor.com/view/kys-keep-yourself-safe-low-tier-god-gif-24664025")
        return
    
    voice_state = person_to_giga.voice
    if voice_state is None:
        await interaction.response.send_message("its very nice you like them so much you think they deserve a gigachad, but they should be in call. theyre not in call", ephemeral=True)
        return
    
    else:
        user_voice_channel = person_to_giga.voice.channel
        bot_voice_client = discord.utils.get(bot.voice_clients, guild=interaction.guild)
        if user_voice_channel is not None:
            vc = await join_and_stop_playing(interaction.guild.id, user_voice_channel, bot_voice_client)
            channel = interaction.channel

            if(person_to_giga == interaction.user):
                await interaction.response.send_message("nice try buddy. ive got a better music choice for you instead.", ephemeral=True)
                await asyncio.sleep(1)
                await impart_clown_judgement(person_to_giga, user_voice_channel, bot_voice_client, interaction.channel, interaction.guild.id)
                
            else:
                vc.play(discord.FFmpegPCMAudio(executable="C:/ffmpeg/bin/ffmpeg.exe", source="src/sound_files/gigachad.mp3", options=f"-filter:a \"volume={0.5*await get_volume_multiplier()}\""))
                await interaction.response.send_message(f"{person_to_giga.mention}")
                await channel.send(random.choice(GIGACHAD_GIFS)) 

        else:
            await interaction.response.send_message("this error should literally never be reached. if it was, yell for braydon")


# this was a little weird to make as a general function, but it is needed in two functions so ¯\_(ツ)_/¯. 
# basically, it sends the clowns and plays the clown file
async def impart_clown_judgement(person_to_clown, user_voice_channel, bot_voice_client, interaction_channel, interaction_guild_id):

    if user_voice_channel is not None:
            vc = await join_and_play_sound(interaction_guild_id, user_voice_channel, bot_voice_client, "src/sound_files/clown.mp3", 0.5)
            await interaction_channel.send(f"looks like someone in VC is a clown!\n\nchat, laugh at {person_to_clown.mention}")   
            clown_gifs = [
                "https://media1.tenor.com/m/mOZucMZ9ZygAAAAd/clown-mcdonald.gif",
                "https://media1.tenor.com/m/IDyfUSzUxRkAAAAC/mcdonalds-ronald-mcdonald.gif",
                "https://media1.tenor.com/m/gj4q_xk08gMAAAAC/mcdonalds-ronald-mcdonald.gif",
                "https://media1.tenor.com/m/g288q_b6udIAAAAC/ronald-point.gif",
                "https://media1.tenor.com/m/ES3ljWtpeTsAAAAC/ronald.gif",
                "https://media1.tenor.com/m/3DSsnoS8FgMAAAAC/clown-mcdonalds.gif"
            ]

            for gif in clown_gifs:
                if not vc.is_playing():
                    break
                await interaction_channel.send(gif)
                await asyncio.sleep(2)
                if not vc.is_playing():
                    break
                await interaction_channel.send(person_to_clown.mention)
                await asyncio.sleep(1)
