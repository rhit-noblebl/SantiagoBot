KILL_MESSAGES = [
  "damn.",
  "ez",
  "skill issue",
  "They will not be missed.",
  "It was a misinput, misinput... Calm Down! YOU CALM THE FUCK DOWN! IT WAS A MISINPUT!",
  "Bonafied, Monafied!",
  "\"He'S tUnNeLlInG mE!11!!!!11\"",
  "Your life is nothing. You serve *ZERO* purpose. You should kill yourself... *NOW*.",
  "That's gonna leave a mark!",
  "ant colony ant colony ant colony"
]

SUICIDE_MESSAGES = [
  "Are you okay buddy...?",
  "Do you need a hug...?",
  "Are you alright...?",
  "...",
  "LTG strikes again..."
]

QUEUE_QUIP_TEMPLATES = [
    "I hope you guys are prepared. {mention} just added `{title}` by `{uploader}` to the queue.",
    "Oh boy. Here we go again. {mention} just added `{title}` by `{uploader}` to the queue.",
    "la la la... wait what...? OH HOLY SHIT {mention} JUST ADDED `{title}` BY `{uploader}` TO THE QUEUE!!",
    "i hate this video too\n\n{mention} just added `{title}` by `{uploader}` to the queue.",
    "more pain\n\n{mention} just added `{title}` by `{uploader}` to the queue.",
    "Now I am become Tempo... queue\n\n{mention} just added `{title}` by `{uploader}` to the queue."
]

PLAY_QUIP_TEMPLATES = [
    "Alright, everyone shut the hell up. {mention} wants to play `{title}` by `{uploader}`.",
    "i hate this video\n\nPlaying `{title}` by `{uploader}`",
    "Now playing: `{title}` by `{uploader}`.",
    "Oh damn, it's `{title}` by `{uploader}`! Nice pick, {mention}!",
    "Regretfully, I have to play `{title}` by `{uploader}`. Don't blame me, {mention} requested it.",
    "Now I am become Tony... Youtube\n\nPlaying: `{title}` by `{uploader}`.",
    "i am rythm reborn\n\nPlaying: `{title}` by `{uploader}`."
]

STOP_QUIP_TEMPLATES = [
    "{stopper} stopped the current sound",
    "{stopper} was tired of hearing those horrid sounds",
    "I *wanted* to keep playing, but *someone* (cough cough {stopper}) wanted me to stop",
    "awww, you're no fun",
    "you just don't like me, is that it?",
    "no, YOU shut up",
    "Now I am become Spotify... stop"
]

PAUSE_QUIP_TEMPLATES = [
    "thank god",
    "la la la- wait what? dude... {pauser} just ruined the vibes, man...",
    "hold up. {pauser} wants to talk for a minute.",
    "don't you worry folks, we'll have it back up and running in no time!",
    "Now I am become YouTube... pause",
    "let's keep it this way, shall we?",
    "{pauser}, let me be the first to say that i wholeheartedly support your decision to pause this.",
    "gotcha. i'll hold off on the tunes/earrape."
]

RESUME_QUIP_TEMPLATES = [
    "please no",
    "... wha?... OH LET'S GO, WE'RE BACK IN ACTION BABY!",
    "{resumer}, why must you continue to put me through this hell...",
    "i hope you guys didn't have that paused for a reason, because {resumer} wants it back",
    "the time for talking is over. the time for playing... has just begun.",
    "Now I am become Soundcloud... resume",
    "let the madness continue!"
]

PLAY_QUIP_TEMPLATES = [
    "Alright, everyone shut the hell up. {mention} wants to play `{title}` by `{uploader}`.",
    "i hate this video\n\nPlaying `{title}` by `{uploader}`",
    "Now playing: `{title}` by `{uploader}`.",
    "Oh damn, it's `{title}` by `{uploader}`! Nice pick, {mention}!",
    "Regretfully, I have to play `{title}` by `{uploader}`. Don't blame me, {mention} requested it.",
    "Now I am become Tony... Youtube\n\nPlaying: `{title}` by `{uploader}`.",
    "i am rythm reborn\n\nPlaying: `{title}` by `{uploader}`."
]

KILL_EXCLAMATION_TEMPLATES = [ 
    "{killer} killed {killed}!",
    "{killer} slayed {killed}!",
    "{killer} butchered {killed}!",
    "{killed} has fallen at the hands of {killer}!",
    "{killed} had a massive skill issue fighting {killer}!",
    "{killed} was killed by {killer} whilst trying to escape skill issue",
    "{killer} had it out for {killed}!"
]

INSULT_TEMPLATES = [
    "{insultee}, you're a god damn idiot", 
    "fuck you {insultee}", 
    "hey {insultee} i just wanna let you know {insulter} thinks ur stupid",
    "{insultee} gets no bitches",
    "{insultee} has a tiny penis",
    "Guys wait, the dumbass wants to speak! Go ahead {insultee}, we're listening :)",
    "sorry {insulter}, my lawyer has advised me not to say that to {insultee} on a public forum",
    "{insultee} probably runs noed",
    "{insultee} your life literally... is as valuable as a summer ant",
    "I'm just gonna stomp {insultee}, they're gonna keep coming back, I'm gonna seal up all my cracks, they're gonna keep coming back. Why?",
    "{insultee} keeps smellin the syrup. You worthless bitchass best friend",
    "{insultee} gonna stay on my dick until they die.",
    "{insultee}, you serve no purpose in life. Your purpose in life is to be on my server sucking on my dick daily. Your purpose in life is to be in that chat blowing a dick daily.",
    "{insultee} your life is nothing.",
    "{insultee} you serve zero purpose.",
    "{insultee} you should kill yourself NOW and give somebody else a piece of that oxygen... and ozone layer that's covered up so that we can all breathe inside this blue trash bubble",
    "{insultee} what are you here for? To worship me? Kill yourself. I mean that, with a 100%, with a 1000%.",
    "{insultee} baby killer baby killer",
    "awwww, hi {insultee}! guys look, it's a little baby Dweet! :)",
    "Just so everyone is aware, {insulter} is far superior to {insultee}"
]

