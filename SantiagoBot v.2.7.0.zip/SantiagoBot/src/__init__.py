# teammates!? friends!? to hell with that! why am I inferior to you!? i was extremely particular about 
# my life... my grades... my public image... so someone would want me around! i am an ace detective! a celebrity! 
# 
# akechi kun
#  
# but you... you're just some criminal trash living in an attic!? so how!? how does someone like you have things 
# i don't!? how can such a worthless piece of trash be more special than me!? 





# i just have this file here because python gets mad if you dont have it. it gave me a real headache trying to figure
# it out and man. im glad its over. who knows, maybe in the future, ill actually need to use this file

