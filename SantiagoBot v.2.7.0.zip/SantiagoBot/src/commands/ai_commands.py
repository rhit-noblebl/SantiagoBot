import discord
import asyncio

from discord.ext import voice_recv
from elevenlabs import Voice, VoiceSettings, save
from pydub import AudioSegment

from src.config import MAX_HISTORY_LENGTH, ai_message_history, OpenAIClient, ElevenLabsClient, bot
from src.commands.vc_commands import join_and_play_sound
from src.data.ai_prompts import *


current_model = "gpt-4o-mini"
can_talk = True

#call this to generate text based on the last message sent, passing in who wrote it for startup_prompt context
async def generate_text(user):
    startup_prompt = SANTIAGO_STARTUP_PROMPT

    if user.id == 426867397400592424:
        startup_prompt = FATHER_PROMPT
    elif user.id == 736888501026422855:
        startup_prompt = BOT_HATE_PROMPT

    # very important line, feeds it the context of the interaction with the proper format
    full_context = [{"role": "system", "content": startup_prompt}] + [{"role": "user", "content": f"{msg['content']}"} for msg in ai_message_history[-MAX_HISTORY_LENGTH:]] 
    
    ## use this if you need to debug the context being passed into him

    # print("PASSED CONTEXT: \n")
    # print(full_context)
    # print("\n\n")
    
    ## use this if you need to debug his stored message history

    # print("MESSAGE HISTORY: \n")
    # print(ai_message_history)
    # print("\n\n")

    response = OpenAIClient.chat.completions.create(
        model=current_model,
        messages=full_context,
        stream=False
    )

    generated_message = truncate_message(response.choices[0].message.content)
    return generated_message

#helper
def truncate_message(message, limit=2000):
    return message if len(message) <= limit else message[:limit-3] + "..."


#generates audio based on the passed prompt
async def generate_audio(prompt, voice):
    speech_file_path = "src/sound_files/speech.mp3"

    response = ElevenLabsClient.generate(
        text=prompt,
        voice=Voice(
            voice_id=voice,
            settings=VoiceSettings(stability=0.71, similarity_boost=0.5, style=0.0, use_speaker_boost=True),
            model="eleven_multilingual_v1"
        )
    )

    # saves the speech to the mp3
    save(response, speech_file_path)


    # --IMPORTANT--
    # this is OPEN AI voice synthesis if ElevenLabs stops working for whatever reason
    #
    # voice_response = OpenAIClient.audio.speech.create(
    #     model="tts-1",
    #     voice="onyx",
    #     input=prompt
    # )
    #
    # voice_response.stream_to_file(speech_file_path)


async def generate_text_and_audio(interaction: discord.Interaction, user_message: str):
    ai_message_history.append({"role": "user", "content": str(interaction.user.display_name) + ": " + user_message})
    await interaction.response.defer() 

    voice_state = interaction.user.voice
    if voice_state is None:
        await interaction.followup.send("to use this command, get into a call. alternatively, if you just want to talk to me outside of vc, put 'santiago' somewhere in your message.", ephemeral=True)
        return

    user_voice_channel = interaction.user.voice.channel
    bot_voice_client = discord.utils.get(bot.voice_clients, guild=interaction.guild)
    if user_voice_channel is not None:
        

        #generates the text response
        text_response = await generate_text(interaction.user)

        #generates the audio file
        await generate_audio(text_response, VOICE_MAP["braydon"])

        #joins call
        await join_and_play_sound(interaction.guild.id, user_voice_channel, bot_voice_client, "src/sound_files/speech.mp3", 2)
        await interaction.followup.send(text_response)

        #append both the users input and ai response to the history
        ai_message_history.append({"role": "assistant", "content": text_response})
    else:
        await interaction.followup.send(f"you're not in a valid voice channel.", ephemeral=True)


async def set_gpt_model(interaction: discord.Interaction, model: str):
    current_model = model
    if current_model == "gpt-4o-mini":
        await interaction.response.send_message("i are no longer brain")
    elif current_model == "gpt-4o":
        await interaction.response.send_message("brain")


async def toggle_ai_chat_replies(interaction: discord.Interaction):
    global can_talk
    if can_talk:
        await interaction.response.send_message("stop blabbering. its really annoying.")
    else:
        await interaction.response.send_message("...can i come out of the quiet corner now? :(")
    can_talk = not can_talk


async def speak(interaction: discord.Interaction, text_prompt: str, voice: str):

    await interaction.response.defer() 

    user_voice_channel = interaction.user.voice.channel
    bot_voice_client = discord.utils.get(bot.voice_clients, guild=interaction.guild)
    if user_voice_channel is not None:
        
        #generates the audio file
        await generate_audio(text_prompt, voice)

        #joins call
        await join_and_play_sound(interaction.guild.id, user_voice_channel, bot_voice_client, "src/sound_files/speech.mp3", 2)
        await interaction.followup.send(text_prompt)

    else:
        await interaction.followup.send(f"you're not in a valid voice channel.", ephemeral=True)


# called in on_message in main.py, this does what it says on the tin
async def ai_message_logging_and_response(message: discord.Message):
    if message.content:
        if message.author == bot.user:
            ai_message_history.append({"role": "assistant", "content": message.content})
        else: 
            ai_message_history.append({"role": "user", "content": str(message.author.display_name) + ": " + message.content})

    if len(ai_message_history) > MAX_HISTORY_LENGTH:
        ai_message_history.pop(0)

    if message.author == bot.user:
        return
    
    global can_talk
    if can_talk:
        if message.content.lower() == "santiago":
            await message.reply("if the word 'santiago' is present in any message you send, ill talk to you")
            return True
        elif "santiago" in message.content.lower() or message.author.bot:
            response = await generate_text(message.author)
            await message.reply(response)
            return True
    


# this is the code that writes noises in VC to the user_speech.mp3 sound file
# important thing to note: this uses a different vc.connect than the base one, so it's important to disconnect it at the end. otherwise,
# it breaks other commands. keep that in mind when designing or editing this thing. 
async def record_user_voice(interaction: discord.Interaction, seconds: int):

    if not interaction.user.voice:
        await interaction.response.send_message("i can't record you if you're not in a vc.")
        return

    vc = interaction.guild.voice_client
    if vc:
        await vc.disconnect(force=True)

    audio_data = bytearray()

    def callback(user, packet: voice_recv.VoiceData):
        if packet.pcm:  # If PCM data is available, use it
            audio_data.extend(packet.pcm)
        else:  # Otherwise, use Opus data
            audio_data.extend(packet.opus)  # Correctly access the raw Opus audio data


    # Connect to the voice channel
    vc = await interaction.user.voice.channel.connect(cls=voice_recv.VoiceRecvClient)

    # Start listening and recording
    vc.listen(voice_recv.BasicSink(callback))

    # Record for however many seconds
    await asyncio.sleep(seconds)

    # Convert and save the audio data as an MP3 file
    audio_segment = AudioSegment(
        data=bytes(audio_data),
        sample_width=2,  # Assuming 16-bit samples
        frame_rate=100000,  # Standard Discord voice channel sample rate
        channels=1  # Mono audio
    )

    user_speech_file_path = "src/sound_files/user_speech.mp3"
    audio_segment.export(user_speech_file_path, format="mp3")  # Export directly to MP3 file

    await vc.disconnect(force=True)


async def record_user_voice_and_respond(interaction: discord.Interaction, seconds: int):

    await interaction.response.defer()
    await record_user_voice(interaction, seconds)

    user_speech_file_path = "src/sound_files/user_speech.mp3"
    audio_file = open(user_speech_file_path, "rb")
    transcript = OpenAIClient.audio.transcriptions.create(
        model="whisper-1",
        file=audio_file
    )

    print(transcript.text)

    ai_message_history.append({"role": "user", "content": str(interaction.user.display_name) + ": " + transcript.text})

    voice_state = interaction.user.voice
    if voice_state is None:
        await interaction.followup.send("to use this command, get into a call. alternatively, if you just want to talk to me outside of vc, put 'santiago' somewhere in your message.", ephemeral=True)
        return

    user_voice_channel = interaction.user.voice.channel
    bot_voice_client = discord.utils.get(bot.voice_clients, guild=interaction.guild)
    if user_voice_channel is not None:
        
        #generates the text response
        text_response = await generate_text(interaction.user)

        #generates the audio file
        await generate_audio(text_response, VOICE_MAP["braydon"])

        await join_and_play_sound(interaction.guild.id, user_voice_channel, bot_voice_client, "src/sound_files/speech.mp3", 2)
        await interaction.followup.send(text_response)
        
        ai_message_history.append({"role": "assistant", "content": text_response})
    else:
        await interaction.followup.send(f"you're not in a valid voice channel.", ephemeral=True)


async def transcribe(interaction: discord.Interaction, seconds: int):
    await interaction.response.defer()

    await record_user_voice(interaction, seconds)

    user_speech_file_path = "src/sound_files/user_speech.mp3"
    audio_file = open(user_speech_file_path, "rb")
    transcript = OpenAIClient.audio.transcriptions.create(
        model="whisper-1",
        file=audio_file
    )

    ai_message_history.append({"role": "user", "content": str(interaction.user.display_name) + ": " + transcript.text + " What did I just say, Santiago?"})
    ai_message_history.append({"role": "assistant", "content": "you just said: " + transcript.text})

    await interaction.followup.send("you just said: \n\n" + transcript.text)


async def transcribe_file(file_path):
    transcript = OpenAIClient.audio.transcriptions.create(
        model="whisper-1",
        file=file_path
    )

    final_transcription = await format_transcription(transcript.text, 80)

    return final_transcription

async def format_transcription(text, line_length):
    lines = [text[i:i + line_length] for i in range(0, len(text), line_length)]
    return "\n".join(lines)
