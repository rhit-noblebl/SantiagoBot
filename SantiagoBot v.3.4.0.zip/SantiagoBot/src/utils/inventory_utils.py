import sqlite3

from src.config.main_config import bot
from src.config.database_config import DATABASE_PATH


class Item:
    items = {
        "bullets": {
            "name": "Bullets",
            "description": "How they settled things in the West. Grants one use of /shoot or /blind_firing.",
            "value": 1000,
        },
        "nukes": {
            "name": "Nukes",
            "description": "Now you are become death. Grants one use of /nuke.",
            "value": 12500
        },
        "gold": {
            "name": "Gold",
            "description": "Surprisingly not the primary currency in the Santiago-verse. Used in crafting, or sells for 500 SB.",
            "value": 588
        },
        "elemental gems": {
            "name": "Elemental Gems",
            "description": "Crystals capable of conjuring storms. Grants one use of /whirlwind",
            "value": 8000
        },
        "landmines": {
            "name": "Landmines",
            "description": "Shoddy landmines used for guarding text channels, lasts 2 hours. Grants one use of /landmine",
            "value": 500
        },
        "iron": {
            "name": "Iron",
            "description": "Material commonly used in a variety of applications. Used in crafting, or sells for 100 SB.",
            "value": 118
        },
        "diamonds": {
            "name": "Diamonds",
            "description": "Gems lacking any elemental power, but still gems nevertheless. Used in crafting, or sells for 5000 SB.",
            "value": 5882
        },
        "heat-seeking missiles": {
            "name": "Heat-Seeking Missiles",
            "description": "Will track down and hunt any signs of life for 6 hours. Grants one use of /missile_target.",
            "value": 2500
        },
        "flares": {
            "name": "Flares",
            "description": "Special flares used for emergencies to notify choppers for an evacuation. Grants one use of /emergency_evac",
            "value": 4000
        },
        "shotgun shells": {
            "name": "Shotgun Shells",
            "description": "Way deadlier than they appear in video games. Grants one use of /shotgun_blast",
            "value": 2250
        },
        "gunpowder": {
            "name": "Gunpowder",
            "description": "Present in a variety of ballistics and explosives. Used primarily for crafting but can be sold.",
            "value": 29
        },
        "pixie dust": {
            "name": "Pixie Dust",
            "description": "Like gunpowder, but sparkly. Used primarily for crafting but can be sold.",
            "value": 59
        },
        "signal jammers": {
            "name": "Signal Jammers",
            "description": "Used to prevent your adversary's communication. Grants one use of /jammer_deploy.",
            "value": 2750
        },
        "flashbangs": {
            "name": "Flashbangs",
            "description": "Blinds or deafens your target. Unfortunately, Discord can't produce blinding light. Grants one use of /flashbang.",
            "value": 3000
        },
        "EMPs": {
            "name": "EMPs",
            "description": "Electro-Magnetic Pulse. Will fry any VC it touches. Grants one use of /emp.",
            "value": 20000
        },
        "warp staffs": {
            "name": "Warp Staffs",
            "description": "Used defensively, there is no better tool. Used offensively, good luck escaping that one... Grants one use of /warp_cast.",
            "value": 3500
        },
    }

    crafting_recipes = {
            "landmines": {
                "materials": {"iron": 1, "gunpowder": 2},
                "currency": 50,
            },
            "bullets": {
                "materials": {"iron": 1, "gunpowder": 3},
                "currency": 100,
            },
            "shotgun shells": {
                "materials": {"bullets": 1, "iron": 1, "gunpowder": 2},
                "currency": 100,
            },
            "heat-seeking missiles": {
                "materials": {"gold": 1, "iron": 3, "gunpowder": 3},
                "currency": 200,
            },
            "signal jammers": {
                "materials": {"gold": 2, "iron": 2, "pixie dust": 2},
                "currency": 150,
            },
            "flashbangs": {
                "materials": {"gold": 2, "iron": 2, "gunpowder": 2},
                "currency": 150,
            },
            "warp staffs": {
                "materials": {"gold": 2, "pixie dust": 5},
                "currency": 175,
            },
            "flares": {
                "materials": {"gold": 2, "iron": 4},
                "currency": 200,
            },
            "elemental gems": {
                "materials": {"diamonds": 1, "pixie dust": 10},
                "currency": 500,
            },
            "nukes": {
                "materials": {"diamonds": 1, "flashbangs": 2, "gunpowder": 5},
                "currency": 1000,
            },
            "EMPs": {
                "materials": {"diamonds": 2, "signal jammers": 2, "pixie dust": 5},
                "currency": 2500,
            },
    }

    @classmethod
    def get_description(cls, item_key):
        item = cls.items.get(item_key)
        if item:
            return item["description"]
        return "Item not found."
    
    @classmethod
    def get_name(cls, item_key):
        item = cls.items.get(item_key)
        if item:
            return item["name"]
        return "Item not found."
    
    @classmethod
    def get_value(cls, item_key):
        item = cls.items.get(item_key)
        if item:
            return item["value"]
        return "Item not found."
    
    @classmethod
    def get_recipe(cls, item_key):
        return cls.crafting_recipes.get(item_key, None)
    
    
    BULLET = "bullets"
    NUKE = "nukes"
    IRON = "iron"
    GOLD = "gold"
    DIAMOND = "diamonds"
    ELEMENTAL_GEM = "elemental gems"
    LANDMINE = "landmines"
    HEAT_SEEKING_MISSILE = "heat-seeking missiles"
    FLARE = "flares"
    SHOTGUN_SHELL = "shotgun shells"
    GUNPOWDER = "gunpowder"
    SIGNAL_JAMMER = "signal jammers"
    FLASHBANG = "flashbangs"
    EMP = "EMPs"
    WARP_STAFF = "warp staffs"
    PIXIE_DUST = "pixie dust"





# getting and setting user specific currency

async def get_user_currency(user_id):
    conn = sqlite3.connect(DATABASE_PATH)
    cursor = conn.cursor()

    
    cursor.execute('''
    SELECT currency FROM users WHERE id = ?
    ''', (user_id,))
    result = cursor.fetchone()
    
    conn.close()
    
    return result[0] if result else 0

async def set_user_currency(user_id, amount):
    conn = sqlite3.connect(DATABASE_PATH)
    cursor = conn.cursor()
    
    
    cursor.execute('''
    UPDATE users SET currency = ? WHERE id = ?
    ''', (amount, user_id))
    
    conn.commit()
    conn.close()

async def update_user_currency(user_id, amount):
    conn = sqlite3.connect(DATABASE_PATH)
    cursor = conn.cursor()
    
    
    cursor.execute('''
    UPDATE users SET currency = currency + ? WHERE id = ?
    ''', (amount, user_id))
    
    conn.commit()
    conn.close()



# sets and gets items from a player's inventory

async def update_item_amount(user_id, item_name, quantity):
    conn = sqlite3.connect(DATABASE_PATH)
    cursor = conn.cursor()
    
    
    # Check current quantity
    cursor.execute('''
    SELECT quantity FROM inventory WHERE user_id = ? AND item_name = ?
    ''', (user_id, item_name))
    result = cursor.fetchone()
    
    if result:
        current_quantity = result[0]
        new_quantity = current_quantity + quantity
        
        # Prevent negative quantities
        if new_quantity < 0:
            new_quantity = 0
        
        cursor.execute('''
        UPDATE inventory SET quantity = ? WHERE user_id = ? AND item_name = ?
        ''', (new_quantity, user_id, item_name))
    else:
        cursor.execute('''
        INSERT INTO inventory (user_id, item_name, quantity) VALUES (?, ?, ?)
        ''', (user_id, item_name, quantity))
    
    conn.commit()
    conn.close()

async def get_item_amount(user_id, item_name):
    conn = sqlite3.connect(DATABASE_PATH)
    cursor = conn.cursor()

    
    cursor.execute('''
    SELECT quantity FROM inventory WHERE user_id = ? AND item_name = ?
    ''', (user_id, item_name))
    result = cursor.fetchone()
    
    conn.close()
    
    if result:
        quantity = result[0]
    else:
        quantity = 0
    
    return quantity
        
async def set_item_amount(user_id, item_name, quantity):
    conn = sqlite3.connect(DATABASE_PATH)
    cursor = conn.cursor()
    
    try:
        
        # Ensure the quantity is not negative
        if quantity < 0:
            quantity = 0
        
        # Check if the item already exists
        cursor.execute('''
        SELECT quantity FROM inventory WHERE user_id = ? AND item_name = ?
        ''', (user_id, item_name))
        result = cursor.fetchone()
        
        if result:
            # Update existing item quantity
            cursor.execute('''
            UPDATE inventory SET quantity = ? WHERE user_id = ? AND item_name = ?
            ''', (quantity, user_id, item_name))
        else:
            # Insert new item with specified quantity
            cursor.execute('''
            INSERT INTO inventory (user_id, item_name, quantity) VALUES (?, ?, ?)
            ''', (user_id, item_name, quantity))
        
        conn.commit()
    except sqlite3.Error as e:
        print(f"An error occurred: {e}")
    finally:
        conn.close()


def remove_deprecated_item(item_name):
    conn = sqlite3.connect(DATABASE_PATH)
    cursor = conn.cursor()

    try:
        # Delete the deprecated item from the inventory table
        cursor.execute('''
        DELETE FROM inventory WHERE item_name = ?
        ''', (item_name,))
        
        conn.commit()
        print(f"The item '{item_name}' has been removed from the inventory.")
    except sqlite3.Error as e:
        print(f"An error occurred: {e}")
    finally:
        conn.close()


# check if user exists

def user_exists(user_id):
    conn = sqlite3.connect(DATABASE_PATH)
    cursor = conn.cursor()
    
    cursor.execute('''
    SELECT 1 FROM users WHERE id = ?
    ''', (user_id,))
    result = cursor.fetchone()
    
    conn.close()
    
    return result is not None

