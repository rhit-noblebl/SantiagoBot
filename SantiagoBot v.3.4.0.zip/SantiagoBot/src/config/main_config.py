import discord
import os

from discord.ext import commands
from openai import OpenAI
from elevenlabs.client import ElevenLabs


# api keys and bot token
BOT_TOKEN = os.getenv("BOT_TOKEN")
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
ELEVENLABS_API_KEY = os.getenv("ELEVENLABS_API_KEY")

# discord bot (and it's cogs) and openai/elevenlabs client initialization
bot = commands.Bot(command_prefix='s ', intents=discord.Intents.all())
OpenAIClient = OpenAI(api_key=OPENAI_API_KEY)
ElevenLabsClient = ElevenLabs(api_key=ELEVENLABS_API_KEY)
