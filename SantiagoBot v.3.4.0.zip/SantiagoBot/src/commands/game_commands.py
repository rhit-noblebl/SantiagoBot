import discord
import random
import asyncio

from src.config.logging_config import log_work
from src.data.reactions_lists import WORK_DIALOGUE_TEMPLATES
from src.utils.inventory_utils import *
from src.utils.generic_utils import capitalize_item_name

async def work(ctx):
    user_id = ctx.author.id

    conn = sqlite3.connect(DATABASE_PATH)
    cursor = conn.cursor()

    # Update the amount_worked field for the specified user
    cursor.execute('''
        UPDATE user_stats
        SET amount_worked = amount_worked + 1
        WHERE user_id = ?
    ''', (user_id,))

    conn.commit()
    conn.close()

    await update_user_currency(user_id, 5)


async def view_currency(ctx):
    user_id = ctx.author.id
    balance = await get_user_currency(user_id)
    if balance == 1:
        await ctx.send(f'{ctx.author.mention}, you currently have {balance} **Santiago Buck**. for the love of god, use it wisely')
    elif balance >= 0:
        await ctx.send(f'{ctx.author.mention}, you currently have {balance} **Santiago Bucks!**')
    else:
        await ctx.send(f'{ctx.author.mention}, you are currently **in debt!** You owe {abs(balance)} **Santiago Bucks!**')


async def view_inventory(ctx):
    conn = sqlite3.connect(DATABASE_PATH)
    cursor = conn.cursor()
    
    # Retrieve user inventory
    cursor.execute('''
    SELECT item_name, quantity FROM inventory WHERE user_id = ?
    ''', (ctx.author.id,))
    items = cursor.fetchall()
    
    # Retrieve user currency
    cursor.execute('''
    SELECT currency FROM users WHERE id = ?
    ''', (ctx.author.id,))
    currency = cursor.fetchone()
    currency = currency[0] if currency else 0

    
    inv_embed = discord.Embed(color=discord.Colour.dark_blue())
    
    inv_embed.set_thumbnail(url="https://i.imgflip.com/2/7c0e8u.jpg")
    inv_embed.set_author(name=f"{ctx.author.display_name}'s Santiago Inventory", icon_url=ctx.author.display_avatar)
    inv_embed.title = f"-------------------------------------------------------"

    if items:
        for item, quantity in items:
            if quantity > 0:
                
                # Capitalize the item name
                formatted_name = Item.get_name(item)
                description = Item.get_description(item)

                inv_embed.add_field(name=f"{formatted_name}: {quantity}", value=description)
    else:
        inv_embed.add_field(name=f"Your inventory is currenly empty!", value="To fill it up with some items, use 's work' to get money to buy them. Who knows, you might even get a random drop...")
    inv_embed.add_field(name=f"-------------------------------------------------------------------", value=f"**Santiago Bucks:** {currency}", inline=False)
    inv_embed.set_footer(text=f"This is your inventory. Collected or bought items will go in here. Many of these items are used for fun commands you can use, mostly for VC. Use /buy_item or /sell_item if you would like to buy or sell them, and use /craft_item to craft.") 
    
    conn.close()
    
    await ctx.send(embed=inv_embed)


async def view_stats(ctx):
    conn = sqlite3.connect(DATABASE_PATH)
    cursor = conn.cursor()
    
    # Query to get users and their currency for the specified guild
    cursor.execute('''
        SELECT slash_commands_used, amount_worked, amount_gambled, amount_shot, amount_exploded
        FROM user_stats
        WHERE user_id = ?
    ''', (ctx.message.author.id,))
    
    # Fetch all results
    stats = cursor.fetchone()
    
    conn.close()

    stats_embed = discord.Embed(color=discord.Colour.brand_green())
    stats_embed.title = f"------------{ctx.author.display_name}'s Santiago Stats------------"

    stats_embed.add_field(name="Slash commands used:", value=stats[0], inline=False)
    stats_embed.add_field(name="Amount of times worked:", value=stats[1], inline=False)
    stats_embed.add_field(name="Amount of times gambled:", value=stats[2], inline=False)
    stats_embed.add_field(name="Amount of times shot:", value=stats[3], inline=False)
    stats_embed.add_field(name="Amount of times exploded:", value=stats[4], inline=False)


    await ctx.channel.send(embed=stats_embed)


async def view_leaderboard(ctx):

    conn = sqlite3.connect(DATABASE_PATH)
    cursor = conn.cursor()
    
    # Query to get users and their currency for the specified guild
    cursor.execute('''
        SELECT u.id, u.user_name, u.currency
        FROM users u
        JOIN user_guilds gu ON u.id = gu.user_id
        WHERE gu.guild_id = ?
        ORDER BY u.currency DESC
    ''', (ctx.message.guild.id,))
    
    # Fetch all results
    users = cursor.fetchall()
    
    conn.close()

    leaderboard_embed = discord.Embed(color=discord.Colour.brand_green())
    leaderboard_embed.title = "-----------Santiago Leaderboard-----------"

    ctx_user_name = "not found"
    ctx_user_currency = 0
    ctx_user_lb_position = 0
    for i, user in enumerate(users, 1):
        if user[0] == ctx.author.id:
            ctx_user_name = user[1]
            ctx_user_currency = user[2]
            ctx_user_lb_position = i
        if i < 6:
            if user[0] == ctx.author.id:
                leaderboard_embed.add_field(name=f"{i}. {user[1]} <---- THAT'S YOU!", value=f"...with {user[2]} SB!", inline=False)
            else:
                leaderboard_embed.add_field(name=f"{i}. {user[1]}", value=f"...with {user[2]} SB!", inline=False)


    leaderboard_embed.add_field(name="---------------------------------------------------", value="Your server rank:", inline=False)
    leaderboard_embed.add_field(name=f"{ctx_user_lb_position}. {ctx_user_name}", value=f"...with {ctx_user_currency} SB!", inline=False)

    await ctx.channel.send(embed=leaderboard_embed)



async def game_events_check_and_log(message: discord.Message):

    awards_list = []

    excluded_strings = ["s work", "s w", "s import", "s export", "s inv"]
    if not message.author.bot and message.content.lower() not in excluded_strings:
        await update_user_currency(message.author.id, 1)        

    elif message.content.lower() == "s w" or message.content.lower() == "s work":
        if random.randint(1, 15) == 1:
            work_dialogue = [template.format(worker=message.author.display_name, currency=await get_user_currency(message.author.id)) for template in WORK_DIALOGUE_TEMPLATES]
            response = random.choice(work_dialogue)
            await message.channel.send(response)

            if response == "tell you what pal, here's 50 extra Santiago Bucks. on the house.":
                await update_user_currency(message.author.id, 50)
                awards_list.append("10 Extra SB")
            elif response == "alright, i fell bad with you 's work'ing with barely anything to show for it. take some **Iron**, on me. free of charge.":
                await update_item_amount(message.author.id, Item.IRON, 1)
                awards_list.append("Iron")

            await asyncio.sleep(10)

        #############################
        #       Random Drops        #
        #############################

        if random.randint(1, 50) == 1:
            await message.channel.send(f"hey {message.author.mention}, this looks like gunpowder! we might be able to use this. \n\nyou acquired some **Gunpowder**. it just got added to your inventory")
            await update_item_amount(message.author.id, Item.GUNPOWDER, 1)
            awards_list.append("Gunpowder")

        if random.randint(1, 75) == 1:
            await message.channel.send(f"{message.author.mention}, i smell something magical... oh!... i caught a pixie! can't wait to put it in the blender back home. \n\nyou acquired some **Pixie Dust**! it just got added to your inventory")
            await update_item_amount(message.author.id, Item.PIXIE_DUST, 1)
            awards_list.append("Pixie Dust")

        if random.randint(1, 100) == 1:
            await message.channel.send(f"stop for a sec, {message.author.mention}. we might be able to sell this. \n\nyou unearthed some **Iron**. it just got added to your inventory")
            await update_item_amount(message.author.id, Item.IRON, 1)
            awards_list.append("Iron")

        if random.randint(1, 250) == 1:
            await message.channel.send(f"woah {message.author.mention}, it's so nice-looking! let's dig it up! \n\nyou unearthed some **Gold**! it just got added to your inventory")
            await update_item_amount(message.author.id, Item.GOLD, 1)
            awards_list.append("Gold")

        if random.randint(1, 500) == 1:
            await message.channel.send(f"huh...? what's this? i wonder who left this here... {message.author.mention}, i don't think we should linger here for long... \n\na **Bullet** just got added to your inventory")
            await update_item_amount(message.author.id, Item.BULLET, 1)
            awards_list.append("Bullet")
        
        if random.randint(1, 500) == 1:
            await message.channel.send(f"*look out {message.author.mention}!* ...oh, phew. deactivated. maybe it'll come in handy? \n\na **Landmine** just got added to your inventory")
            await update_item_amount(message.author.id, Item.LANDMINE, 1)
            awards_list.append("Landmine")
        
        if random.randint(1, 1750) == 1:
            await message.channel.send(f"oh? red and cylindrical... must be a shotgun shell. {message.author.mention}, you hold it. \n\na **Shotgun Shell** just got added to your inventory")
            await update_item_amount(message.author.id, Item.SHOTGUN_SHELL, 1)
            awards_list.append("Shotgun Shell")

        if random.randint(1, 2000) == 1:
            await message.channel.send(f"**stop, stop, stop!** {message.author.mention}, check it out! think of what we could do with this!? \n\nyou unearthed a **Diamond**! it just got added to your inventory")
            await update_item_amount(message.author.id, Item.DIAMOND, 1)
            awards_list.append("Diamond")

        if random.randint(1, 2500) == 1:
            await message.channel.send(f"wait what's this sheet of paper...? 'launch codes'...? 'input target...?' next time we're at a terminal, we should try this {message.author.mention}. \n\nyou unlocked a **Heat-seeking Missile**! it just got added to your inventory")
            await update_item_amount(message.author.id, Item.HEAT_SEEKING_MISSILE, 1)
            awards_list.append("Heat-seeking Missile")

        if random.randint(1, 3000) == 1:
            await message.channel.send(f"something hurting my brain... ah, it must have been this. {message.author.mention}, get me away from it - i don't like this one bit... \n\nyou found a **Signal Jammer**! it just got added to your inventory")
            await update_item_amount(message.author.id, Item.SIGNAL_JAMMER, 1)
            awards_list.append("Signal Jammer")

        if random.randint(1, 3000) == 1:
            await message.channel.send(f"my, my, a flashbang! {message.author.mention}, am i... *STUNNING*** today, or not? heh. \n\nyou found a **Flashbang**! it just got added to your inventory")
            await update_item_amount(message.author.id, Item.FLASHBANG, 1)
            awards_list.append("Flashbang")

        if random.randint(1, 3250) == 1:
            await message.channel.send(f"something smells like wizard around here. oh, must be that dead wizard. but hey {message.author.mention}, his staff is still intact! maybe with this, we can make it home victor!\n\nyou found a **Warp Staff**! it just got added to your inventory")
            await update_item_amount(message.author.id, Item.WARP_STAFF, 1)
            awards_list.append("Warp Staff")

        if random.randint(1, 3500) == 1:
            await message.channel.send(f"woah, check this out! this is one of those flares they used in the great Santiago War of '04! {message.author.mention}, save this in case of emergencies. \n\na **Flare** just got added to your inventory")
            await update_item_amount(message.author.id, Item.FLARE, 1)
            awards_list.append("Flare")

        if random.randint(1, 6000) == 1:
            await message.channel.send(f"i fell something enchanted in the air... ah! {message.author.mention}, look! a magical gem! \n\nyou just found an **Elemental Gem**! it just got added to your inventory")
            await update_item_amount(message.author.id, Item.ELEMENTAL_GEM, 1)
            awards_list.append("Tornado Gem")

        if random.randint(1, 7500) == 1:
            await message.channel.send(f"what the...?! how the hell does someone even leave something like this?! {message.author.mention}, don't breathe on it too hard... let's be ***very*** careful with this... \n\nyou unearthed a **Nuke**! it just got added to your inventory")
            await update_item_amount(message.author.id, Item.NUKE, 1)
            awards_list.append("Nuke")

        if random.randint(1, 9000) == 1:
            await message.channel.send(f"well i'll be damned. a genuine, honest to god EMP. {message.author.mention}, if this goes off, it'll fry the nearest city! let's take it back. \n\nyou unearthed a **EMP**! it just got added to your inventory")
            await update_item_amount(message.author.id, Item.EMP, 1)
            awards_list.append("EMP")

        await log_work(message, awards_list)


async def crafting_table(ctx):
    embed = discord.Embed(
        title="Crafting List",
        description="Here are the items you can craft along with their required materials and currency.",
        color=discord.Color.dark_blue()
    )

    # Add each item to the embed
    for item_name, details in Item.crafting_recipes.items():
        materials = details.get("materials", {})
        material_str = '\n'.join(f"{qty} {Item.get_name(mat)}" for mat, qty in materials.items())
        currency = details.get("currency", 0)
        
        embed.add_field(
            name=f"--{Item.get_name(item_name)}--",
            value=f"```{material_str}\n{currency} SB```"
        )

    await ctx.send(embed=embed)